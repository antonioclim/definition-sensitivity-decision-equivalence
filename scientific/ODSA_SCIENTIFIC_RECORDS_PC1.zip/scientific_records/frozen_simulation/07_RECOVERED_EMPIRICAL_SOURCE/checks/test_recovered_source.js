const fs = require('fs');
const vm = require('vm');
const crypto = require('crypto');
const html = fs.readFileSync(__dirname + '/../historical_source/weighted_sensitivity.html','utf8');
const prefix = html.split('<script>')[1].split('document.getElementById("freezeShort")')[0];
const cases = [];
for (const weights of [[5,5,5,5,5],[50,20,10,10,10],[5,15,25,35,45],[45,35,25,15,5]]) {
 for (const unresolved of [0,1,3,10,30]) cases.push({weights,unresolved});
}
const appendix = `
const tests = ${JSON.stringify(cases)};
let assertionCount=0;
function check(ok,msg){assertionCount++;if(!ok)throw new Error(msg);}
check(selfTest(),'bundled self-test');
for(const c of tests){
 const counts=c.weights, D=counts.reduce((a,b)=>a+b,0), U=c.unresolved;
 const st={mappedN:D,validWeightN:D,weightSum:D,unresolvedWeightSum:U,stateCounts:counts,stateWeights:counts};
 const primary=buildStratumResult('Synthetic',st), sens=buildSensitivityResult('Synthetic',st,primary);
 const feasible=[];
 for(let a=0;a<=U;a++)for(let b=0;b<=U-a;b++)for(let cc=0;cc<=U-a-b;cc++)for(let d=0;d<=U-a-b-cc;d++){
  const alloc=[a,b,cc,d,U-a-b-cc-d];
  const rates=DEFINITION_ORDER.map(key=>DEFINITIONS[key].states.reduce((s,i)=>s+counts[i]+alloc[i],0)/(D+U));
  feasible.push(rates);
 }
 for(let j=0;j<3;j++){
  const vals=feasible.map(r=>r[j]), bound=sens.definitions[DEFINITION_ORDER[j]];
  check(Math.abs(Math.min(...vals)-bound.lower)<1e-12,'sharp marginal lower');
  check(Math.abs(Math.max(...vals)-bound.upper)<1e-12,'sharp marginal upper');
 }
 for(const [a,b] of [[0,1],[1,2],[0,2]]){
  const added=DEFINITIONS[DEFINITION_ORDER[b]].states.filter(s=>!DEFINITIONS[DEFINITION_ORDER[a]].states.includes(s));
  const K=added.reduce((s,i)=>s+counts[i],0);
  const gaps=feasible.map(r=>r[b]-r[a]);
  check(Math.abs(Math.min(...gaps)-K/(D+U))<1e-12,'sharp coherent gap lower');
  check(Math.abs(Math.max(...gaps)-(K+U)/(D+U))<1e-12,'sharp coherent gap upper');
  check(Math.min(...gaps)>0,'coherent strict positive gap');
 }
}
console.log(JSON.stringify({runtime:process.version,source_sha256:${JSON.stringify(crypto.createHash('sha256').update(html).digest('hex'))},bundled_self_test:'PASS',synthetic_cases:tests.length,assertions:assertionCount,scope:'Pure source JavaScript functions extracted before DOM bindings; Node.js execution; no browser acceptance and no World Bank microdata replay'},null,2));
`;
vm.runInThisContext(prefix+appendix,{filename:'wb_source_functions_test.js'});
