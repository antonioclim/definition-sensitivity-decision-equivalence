#!/usr/bin/env python3
"""Recheck hardened WB aggregates; never claims source-data reproduction."""
import argparse,hashlib,json,math
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument("--out",type=Path,help="Optional JSON evidence path outside the package")
args=parser.parse_args()
r=json.loads((ROOT/'public_aggregates/WORLD_BANK_PUBLIC_RESULT_SUMMARY.json').read_text())
m=json.loads((ROOT/'public_aggregates/WORLD_BANK_PUBLIC_WEIGHTED_MISSINGNESS_SUMMARY.json').read_text())
checks=[]
def check(name,actual,expected,scope='recomputed_from_published_aggregates'):
 ok=actual==expected if not isinstance(expected,float) else math.isclose(actual,expected,abs_tol=1e-12,rel_tol=1e-12)
 checks.append(dict(name=name,actual=actual,expected=expected,passed=ok,scope=scope))
p=r['analysis_population'];check('mapped_plus_unresolved',p['mapped_common_denominator']+p['unresolved_total_rows'],p['total_rows'])
check('unresolved_share',p['unresolved_total_rows']/p['total_rows'],p['unresolved_share'])
check('cross_summary_population_consistency',m['analysis_scope']['total_rows'],p['total_rows'])
check('country_count',p['documented_reporting_countries'],15,'stored_summary_checked_against_primary_catalogue')
check('stratum_count',p['analytical_source_strata'],16,'stored_summary_and_frozen_map_not_source_replay')
for key,d in r['ordering_diagnostics']['weighted'].items():
 check(key+'_pair_total',math.comb(d['comparable_strata'],2),d['total_pairs'])
 check(key+'_partition',d['concordant_pairs']+d['tie_changes']+d['strict_reversals'],d['total_pairs'])
 check(key+'_reversal_share',d['strict_reversals']/d['total_pairs'],d['strict_reversal_share'])
for key,d in m['interval_ordering_determinacy'].items():
 check(key+'_interval_pair_total',math.comb(d['eligible_strata'],2),d['total_pairs'])
 check(key+'_determinate_share',d['determinate_pairs']/d['total_pairs'],d['determinate_share'])
 check(key+'_interval_partition',d['determinate_pairs']+d['overlapping_pairs'],d['total_pairs'])
for key,d in m['robust_separation'].items():
 check(key+'_marginal_robust_share',d['robust_separation_strata']/d['eligible_common_strata'],d['robust_share'])
for key,d in m['cross_stratum_weighted_bounds'].items():
 orig=r['cross_stratum_synthesis']['weighted']['definitions'][key]
 check(key+'_complete_case_median',d['complete_case']['median'],orig['median'],'agreement_between_stored_summaries')
 check(key+'_median_order',d['lower']['median']<=d['complete_case']['median']<=d['upper']['median'],True,'aggregate_order_consistency_not_source_replay')
 for q in ['lower','complete_case','upper','width']:
  x=d[q];check(key+'_'+q+'_quantile_order',x['minimum']<=x['q1']<=x['median']<=x['q3']<=x['maximum'],True,'aggregate_order_consistency_not_source_replay')
new_inference=[]
rmax=m['unresolved_weight_share_across_source_strata']['maximum']
for key,d in r['cross_stratum_synthesis']['weighted']['contrasts'].items():
 # For coherent assignments within one stratum, delta_g=Kadded_g/D_g.
 # Published minimum(delta_g)>0 proves Kadded_g>0 throughout admitted n.
 # Conditional algebraic inference; does not independently re-estimate data.
 new_inference.append(dict(contrast=key,published_n=d['n'],published_complete_case_contrast_min=d['minimum'],
  conditional_joint_strict_order_count=d['n'] if d['minimum']>0 else None,
  conservative_uniform_joint_gap_lower=d['minimum']*(1-rmax),
  status='derived_from_published_summaries_not_empirically_recomputed',
  assumptions=['same positive-weight denominator','same unresolved rows','nested positive state sets','coherent assignments to registered states, including a negative state','published contrast minima correct']))
out={'status':'PASS' if all(c['passed'] for c in checks) else 'FAIL','checks':checks,'conditional_joint_inferences':new_inference,
'headlines':{k:{'median_pct':100*v['median'],'n':v['n']} for k,v in r['cross_stratum_synthesis']['weighted']['definitions'].items()},
'limits':['No row-level mapping or weight replay','No independent recomputation of stratum medians, strict reversal numerators or separation numerators','Algebraic joint-order inference is audit evidence derived from stored aggregates, not a source-data replay or a replacement of the manuscript counts'],
'input_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((ROOT/'public_aggregates').iterdir())}}
if args.out:
 args.out.parent.mkdir(parents=True,exist_ok=True)
 args.out.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'status':out['status'],'checks':len(checks),'conditional_joint_inferences':new_inference},indent=2))
raise SystemExit(0 if out['status']=='PASS' else 1)
