Recovered World Bank source and bounded verification — TASM R2
11 November 2026

Purpose
This folder supplies the recovered historical JavaScript implementation of the
production-planning state mapping, complete-case summaries and weighted
unresolved-row sensitivity. The historical source, four protocol/configuration
files and two cross-stratum-only aggregate summaries are preserved byte for
byte. Their provenance is documented in PROVENANCE.json. No microdata or
private source-level result report is supplied.

What recovery establishes
The code computes within-stratum positive-weight rates, then ordinary medians
and quartiles across eligible strata. Composition numbers are component-wise
medians, not the composition of one median stratum. Pairwise reversal shares
are unweighted fractions of eligible pairs of weighted stratum rates.
METHOD_REGISTER_R2.json records the exact interpretation and its limits.

What was executed in R2
The extracted pure JavaScript functions passed the source self-test and 301
assertions across 20 synthetic assignment cases. The aggregate checker passed
44 arithmetic/consistency checks. The evidence directory records the actual
runtime, source hash, results and limits. These tests neither rerun the World
Bank microdata nor test the browser interface. The ordinary source-data
transformation path and the historical aggregate fingerprint require the
authorised original CSV to be checked end to end.

The historical HTML is a provenance copy, not a newly certified public report
generator. Its interface and historical audit messages are preserved. It can
generate source-stratum sensitivity output; that output is private and is not
part of this public supplement. Recovery does not turn an old status label into
current approval, certify the provider's disclosure requirements or establish
the upstream construction/eligibility of the ib9b variables.

Bounded commands (run from this folder)
PowerShell 5.1:
  node ".\checks\test_recovered_source.js"
  py -3 ".\checks\verify_recovered_aggregates.py" --out "$env:TEMP\TASM_WB_aggregate_checks_R2.json"

POSIX:
  node checks/test_recovered_source.js
  python3 checks/verify_recovered_aggregates.py --out /tmp/TASM_WB_aggregate_checks_R2.json

Node.js is used only for the optional recovered-source checks. The Python
checker uses the standard library. Neither command accepts or processes
microdata. The Python checker writes only when --out is supplied; choose an
output path outside this versioned package to preserve its manifest.

The aggregate checker also displays conditional algebraic consequences of
positive stored contrast minima. Those are deductions from stored summaries,
not new empirical estimates; they do not replace the three historical marginal
separation counts in Table 4. The full simulation tables and original full-run
convergence validator were not recovered by this empirical source recovery.
