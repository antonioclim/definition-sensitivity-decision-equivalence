#!/usr/bin/env python3
"""R5 artwork preparation from immutable R4 vector sources.

Figure 1 is copied byte-for-byte. Figures 2 and 4 are rendered directly from
their original vector SVGs. Figure 3 is rendered from its original SVG after
the sole authorised edit: translating legend_1 upwards by 50 SVG points.
No raster source is enlarged. The original TIFFs supply only target dimensions,
DPI, comparison colours and provenance; output pixels come from vector sources.

Dependencies: Python 3.12, Pillow, numpy and Inkscape CLI.
Run from the project workspace (or provide --r4-dir and --work-dir).
"""
from __future__ import annotations

import argparse
import gc
import hashlib
import json
import platform
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from fractions import Fraction
from pathlib import Path
import xml.etree.ElementTree as ET

import numpy as np
from PIL import Image, __version__ as pillow_version

# These are controlled, previously inspected local figures, up to 161.5 Mpx.
Image.MAX_IMAGE_PIXELS = 200_000_000

SPECS = [
    (1, '04_Figure_1_ODSA_Framework.tif', 'Figure_1_ODSA_Economic_Decision_Architecture',
     'b32de82e8ec14f8531ceff034fdba9fdae876cf696045f43c00d5619ad88c191', []),
    (2, '05_Figure_2_Diagnostic_Nonredundancy.tif', 'Figure_2_Diagnostic_Nonredundancy',
     '8c266753d588a029d3b19a5520a47a398717df49deb5f6aa62fb572f563ea2e2',
     ['#477CB3', '#D2BE3A', '#59C2E8', '#EF6673', '#228C35']),
    (3, '06_Figure_3_Reference_Cell_Diagnostics.tif', 'Figure_3_Reference_Cell_Diagnostics',
     '1edecab9fb701513f07757c9a9c55c664df554f24ad86e0bce6f0f838ba07862',
     ['#477CB3', '#D2BE3A', '#59C2E8', '#EF6673', '#228C35']),
    (4, '07_Figure_4_Unresolved_State_Determinacy.tif', 'Figure_4_Unresolved_State_Determinacy',
     'c9d84732e4714e6e25dddb4fe489cc2c55a6dda079bdef3f03e5519cc6d4f360',
     ['#477CB3', '#D2BE3A', '#EF6673']),
]
ARTWORK_URL = ('https://authorservices.taylorandfrancis.com/wp-content/uploads/'
               '2021/08/Submission-of-electronic-artwork-guide.pdf')


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def dump(path: Path, value) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def metadata(path: Path) -> dict:
    with Image.open(path) as im:
        dpi = im.info.get('dpi')
        assert dpi and len(dpi) == 2
        d = tuple(Fraction(str(x)) for x in dpi)
        inches = [Fraction(n) / den for n, den in zip(im.size, d)]
        return {
            'path': str(path), 'sha256': sha256(path), 'bytes': path.stat().st_size,
            'pixels': list(im.size), 'dpi': [float(x) for x in d], 'mode': im.mode,
            'compression': im.info.get('compression'),
            'tiff_compression_tag': int(im.tag_v2[259]),
            'bits_per_sample': list(im.tag_v2[258]),
            'samples_per_pixel': int(im.tag_v2[277]),
            'photometric_interpretation': int(im.tag_v2[262]),
            'resolution_unit': int(im.tag_v2[296]),
            'physical_inches_exact': [str(x) for x in inches],
            'physical_mm': [round(float(x * Fraction(254, 10)), 6) for x in inches],
        }


def palette_counts(im: Image.Image, palette: list[str]) -> dict:
    # Deterministic sampling is sufficient for large, flat-filled bars/markers.
    a = np.asarray(im)[::16, ::16, :]
    result = {}
    for colour in palette:
        rgb = tuple(int(colour[i:i+2], 16) for i in (1, 3, 5))
        result[colour] = int(np.all(a == rgb, axis=-1).sum())
    return result


def normalise_white_canvas(im: Image.Image, target: tuple[int, int]) -> tuple[Image.Image, dict]:
    """Preserve 1:1 vector scale; adjust only proven-white right/bottom margin."""
    sw, sh = im.size
    tw, th = target
    dx, dy = tw - sw, th - sh
    assert abs(dx) <= 12 and abs(dy) <= 12, ('Unexpected vector bounding-box difference', im.size, target)
    crops = []
    if sw > tw:
        band = im.crop((tw, 0, sw, sh))
        extrema = band.getextrema()
        assert extrema == ((255, 255),) * 3, ('Non-white right edge would be cropped', extrema)
        crops.append({'side': 'right', 'pixels': sw-tw, 'all_pixels_pure_white': True})
        band.close()
    if sh > th:
        band = im.crop((0, th, sw, sh))
        extrema = band.getextrema()
        assert extrema == ((255, 255),) * 3, ('Non-white bottom edge would be cropped', extrema)
        crops.append({'side': 'bottom', 'pixels': sh-th, 'all_pixels_pure_white': True})
        band.close()
    canvas = Image.new('RGB', target, 'white')
    # Pillow paste clips outside pixels; no resize operation occurs.
    canvas.paste(im, (0, 0))
    return canvas, {
        'natural_vector_render_pixels': [sw, sh], 'target_pixels': [tw, th],
        'right_margin_delta_pixels': dx, 'bottom_margin_delta_pixels': dy,
        'cropped_bands': crops, 'added_pixels_rgb': [255, 255, 255],
        'content_scale_factor': 1, 'content_origin_translation_pixels': [0, 0],
        'raster_resampling': False,
    }


def edit_legend(source: Path, dest: Path) -> dict:
    before = source.read_bytes()
    original = b'<g id="legend_1">'
    replacement = b'<g id="legend_1" transform="translate(0,-50)">'
    assert before.count(original) == 1
    after = before.replace(original, replacement, 1)
    assert after.replace(replacement, original, 1) == before
    dest.write_bytes(after)
    root_before, root_after = ET.fromstring(before), ET.fromstring(after)
    elements_before, elements_after = list(root_before.iter()), list(root_after.iter())
    assert len(elements_before) == len(elements_after)
    changes = []
    for i, (a, b) in enumerate(zip(elements_before, elements_after)):
        assert (a.tag, a.text, a.tail) == (b.tag, b.text, b.tail)
        if a.attrib != b.attrib:
            changes.append({'node_index': i, 'id': a.get('id'), 'before': a.attrib, 'after': b.attrib})
    assert len(changes) == 1 and changes[0]['id'] == 'legend_1'
    text_before = [''.join(e.itertext()) for e in elements_before if e.tag.endswith('}text')]
    text_after = [''.join(e.itertext()) for e in elements_after if e.tag.endswith('}text')]
    assert text_before == text_after
    return {
        'source': str(source), 'source_sha256': sha256(source),
        'derivative': str(dest), 'derivative_sha256': sha256(dest),
        'authorised_change': 'Move only the panel B legend upwards into the empty inter-row space.',
        'svg_group': 'legend_1', 'translation_svg_points': [0, -50],
        'translation_mm': [0, round(-50 * 25.4 / 72, 9)],
        'changed_nodes': changes, 'node_count_before': len(elements_before),
        'node_count_after': len(elements_after), 'text_elements_identical': True,
        'text_element_count': len(text_before), 'all_text_values': text_before,
        'all_other_node_attributes_identical': True,
        'all_path_coordinates_data_markers_axes_ticks_labels_colours_unchanged': True,
        'original_svg_recovered_byte_for_byte_by_removing_single_transform': True,
        'data_marker_rows_svg_y': [60.842108, 163.103183, 265.364258],
        'legend_marker_y_before': [247.207553, 261.885678],
        'legend_marker_y_after': [197.207553, 211.885678],
        'legend_text_baselines_y_before': [249.832553, 264.510678],
        'legend_text_baselines_y_after': [199.832553, 214.510678],
        'canvas_unchanged': {k: root_before.get(k) for k in ('width', 'height', 'viewBox')},
    }


def svg_details(path: Path) -> dict:
    root = ET.parse(path).getroot()
    images = [e for e in root.iter() if e.tag.endswith('}image')]
    assert not images, 'Raster images are not permitted in these vector source figures.'
    texts = [e for e in root.iter() if e.tag.endswith('}text')]
    return {
        'canvas': {k: root.get(k) for k in ('width', 'height', 'viewBox')},
        'embedded_raster_image_count': 0,
        'text_element_count': len(texts),
        'text_values': [''.join(e.itertext()) for e in texts],
        'font_styles': sorted({e.get('style', '') for e in texts}),
    }


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--r4-dir', type=Path, default=Path(
        'output/tasm_corrected_r4_20261111/TASM_269811381_CORRECTED_R4_20261111'))
    ap.add_argument('--work-dir', type=Path, default=Path('tmp/tasm_r5_20261111/figures'))
    args = ap.parse_args()
    r4, work = args.r4_dir.resolve(), args.work_dir.resolve()
    assert r4 != work and r4 not in work.parents
    final, previews, derivatives, renders = (work / x for x in ('final', 'previews', 'derivatives', 'render_work'))
    for d in (final, previews, derivatives, renders):
        d.mkdir(parents=True, exist_ok=True)
    provenance = json.loads((work / 'SOURCE_VECTOR_PROVENANCE_R5.json').read_text())
    source_records = []
    for entry in provenance['files']:
        local = work / 'sources' / Path(entry['local_source']).relative_to('tmp/tasm_r5_20261111/figures/sources')
        assert sha256(local) == entry['sha256'], ('Changed original source', local)
        source_records.append({'path': str(local), 'sha256': entry['sha256']})
    s2 = r4 / '01_UPLOAD_SET/09_Supplementary_Material_S2.zip'
    s2_before = sha256(s2)
    assert s2_before == '76a3b9213916c59e11f00d93b9f38e032969d83520bd2fc24494d8d286d20d40'
    inkscape = shutil.which('inkscape')
    assert inkscape, 'Inkscape CLI is required for the authorised Figure 3 SVG edit.'
    inkscape_version = subprocess.check_output([inkscape, '--version'], text=True).strip()
    font_match = subprocess.check_output(['fc-match', '-f', '%{family}\n%{file}\n', 'DejaVu Sans'], text=True).strip()
    assert 'DejaVu Sans' in font_match
    stem3 = SPECS[2][2]
    svg3 = work / 'sources/SVG' / (stem3 + '.svg')
    edited3 = derivatives / (stem3 + '_R5_legend_fixed.svg')
    legend_ledger = edit_legend(svg3, edited3)
    dump(work / 'FIGURE_3_LEGEND_CHANGE_LEDGER_R5.json', legend_ledger)
    records = []
    for number, name, stem, expected, palette in SPECS:
        old = r4 / '01_UPLOAD_SET' / name
        assert sha256(old) == expected, ('Changed original TIFF', old)
        original_meta = metadata(old)
        out = final / name
        record = {'figure': number, 'classification': 'line_art_diagram_or_graph', 'original': original_meta}
        if number == 1:
            shutil.copyfile(old, out)
            assert sha256(out) == expected
            record.update({'conversion': 'byte_identical_copy_existing_1200_dpi', 'content_unchanged': True})
        else:
            target = tuple(int(Fraction(n) * 1200 / Fraction(str(d)))
                           for n, d in zip(original_meta['pixels'], original_meta['dpi']))
            assert all(Fraction(n) * 1200 / Fraction(str(d)) == t
                       for n, d, t in zip(original_meta['pixels'], original_meta['dpi'], target))
            svg = edited3 if number == 3 else work / 'sources/SVG' / (stem + '.svg')
            png = renders / (stem + '_1200dpi.png')
            cmd = [inkscape, str(svg), '--export-area-page', '--export-type=png',
                   '--export-dpi=1200', '--export-background=#ffffff', '--export-background-opacity=1',
                   '--export-filename=' + str(png)]
            result = subprocess.run(cmd, text=True, capture_output=True, check=True)
            with Image.open(png) as temp:
                rendered = temp.convert('RGB')
            conversion = ('direct_rasterisation_from_original_svg_with_single_legend_transform'
                          if number == 3 else 'direct_rasterisation_from_byte_identical_original_svg')
            record.update({'conversion': conversion,
                           'vector_source': str(svg), 'vector_source_sha256': sha256(svg),
                           'renderer': inkscape_version, 'render_command': cmd,
                           'renderer_stdout': result.stdout, 'renderer_stderr': result.stderr,
                           'vector_inspection': svg_details(svg)})
            if number == 3:
                record['legend_change_ledger'] = 'FIGURE_3_LEGEND_CHANGE_LEDGER_R5.json'
            canvas, adjustment = normalise_white_canvas(rendered, target)
            rendered.close()
            record['canvas_adjustment'] = adjustment
            canvas.save(out, format='TIFF', compression='tiff_lzw', dpi=(1200, 1200))
            record['palette_sample_final'] = palette_counts(canvas, palette)
            assert all(record['palette_sample_final'].values()), 'Missing intended final palette colour'
            canvas.close()
            with Image.open(old) as original:
                record['palette_sample_original'] = palette_counts(original, palette)
            assert all(record['palette_sample_original'].values()), 'Missing intended baseline palette colour'
            record['flat_fill_palette_rgb_unchanged'] = True
        final_meta = metadata(out)
        assert final_meta['mode'] == 'RGB'
        assert final_meta['dpi'] == [1200.0, 1200.0]
        assert final_meta['compression'] == 'tiff_lzw'
        assert final_meta['tiff_compression_tag'] == 5
        assert final_meta['bits_per_sample'] == [8, 8, 8]
        assert final_meta['resolution_unit'] == 2
        assert final_meta['physical_inches_exact'] == original_meta['physical_inches_exact']
        record['final'] = final_meta
        record['physical_dimensions_exactly_preserved'] = True
        record['raster_upsampling_used'] = False
        with Image.open(out) as im:
            preview = im.copy()
            preview.thumbnail((1800, 1800), Image.Resampling.LANCZOS)
            preview.save(previews / f'R5_Figure_{number}.png')
            preview.close()
            if number == 3:
                # Native-resolution detail around the corrected legend and lowest data row.
                scale = 1200 / 72
                crop = im.crop(tuple(round(v * scale) for v in (720, 180, 880, 280)))
                crop.save(previews / 'R5_Figure_3_panel_B_detail_native.png')
                crop.close()
        assert sha256(old) == expected
        records.append(record)
        print(json.dumps({'figure': number, 'pixels': final_meta['pixels'], 'sha256': final_meta['sha256'],
                          'bytes': final_meta['bytes'], 'status': 'PASS'}, ensure_ascii=False), flush=True)
        gc.collect()
    for entry in source_records:
        assert sha256(Path(entry['path'])) == entry['sha256']
    assert sha256(s2) == s2_before
    manifest = {
        'phase': 'R5', 'created_utc': datetime.now(timezone.utc).isoformat(),
        'purpose': 'Alignment with the publisher general line-art recommendation, not certified TASM acceptance.',
        'official_artwork_url': ARTWORK_URL, 'recommendation_pdf_page': 3,
        'line_art_recommendation_dpi': 1200, 'figures': records,
        'source_vector_provenance': 'SOURCE_VECTOR_PROVENANCE_R5.json',
        'source_files_reverified_unchanged': source_records,
        'r4_s2_sha256_before': s2_before, 'r4_s2_sha256_after': sha256(s2),
        'all_original_tiffs_unchanged': True, 'scientific_data_recomputed': False,
        'script': str(Path(__file__).resolve()), 'script_sha256': sha256(Path(__file__)),
        'software': {'python': sys.version, 'platform': platform.platform(), 'pillow': pillow_version,
                     'inkscape': inkscape_version, 'font_match': font_match},
        'raster_comparison_limit': 'Raster antialiasing and font rendering differ by renderer. Pixel identity with the R4 600 dpi TIFFs is neither expected nor asserted.',
        'visual_qa': 'Record actual human/model image inspections separately; metadata checks do not establish visual QA.',
    }
    dump(work / 'FIGURE_EXPORT_MANIFEST_R5.json', manifest)


if __name__ == '__main__':
    main()
