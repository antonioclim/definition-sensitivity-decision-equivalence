R18 documentary projection of a retained historical record.
Original SHA-256: feaf2079ac05b7feed87411a8db542019796f7b062dfbe6ce1302fb60ccf0a1c
Numerical statements retained; obsolete administrative wording and runtime installation prefixes updated.

R5 CURRENT FIGURE SOURCES AND PRODUCTION RECORD

This folder contains the sources and final TIFFs for the four figures supplied with R5 on 11 November 2026. Figure 1 is unchanged. Figures 2–4 are exported from vector sources at 1,200 dpi. Figure 3 has one documented legend-group translation; data coordinates, text and colours are unchanged. No simulation, empirical analysis, analytical engine or frozen protocol was changed.

All 215 preceding R4 archive members are preserved with identical uncompressed content. The original R4 archive is retained separately. Previous manifests describe their historical scope; CURRENT_ADDITION_MANIFEST_SHA256.json identifies this R5 addition, while the external R5 release manifest identifies the complete new archive. Earlier vector/PDF/TIFF files remain historical records, not alternative current upload candidates. The final/ folder here matches the four TIFFs in the R5 upload set.

The export script records the executed Linux environment. Its --r4-dir argument requires the extracted original R4 package and --work-dir requires a working copy containing sources/. It is a reproducible production script, not evidence of native Windows execution. Exact archive paths and output hashes are in the manifests; rendering software can affect antialiasing.

The manuscript's existing statement that S2 supplies final figure sources remains applicable. This historical addition is not a public data repository or a DOI deposit.
