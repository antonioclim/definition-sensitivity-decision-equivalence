TASM 269811381 — R5 FIGURE EXPORT

Purpose

This directory records the R5 editorial artwork preparation. Figure 1 is an
unchanged copy of the R4 TIFF. Figures 2–4 are rendered at 1200 dpi from their
original SVG sources. The only graphic edit is a 50-point upward translation
of the panel B legend in Figure 3. Scientific data, labels, axes, scales and
colours are unchanged. Physical dimensions match the R4 TIFFs exactly.

This is alignment with the publisher's general artwork recommendation, not
certification of acceptance by Technology Analysis & Strategic Management.

Files

final/                 Four final TIFFs: RGB, 8 bits/channel, LZW, 1200 dpi.
sources/SVG/           Exact original SVGs from the R2 editable kit and R4 S2.
sources/PDF_VECTOR/    Exact original vector PDFs, retained as provenance.
sources/SOURCE_CODE/   Historical generator, retained unchanged; not rerun.
derivatives/           Figure 3 SVG with the sole authorised legend edit.
export_r5_figures.py   Executed rasterisation and integrity-checking script.
SOURCE_VECTOR_PROVENANCE_R5.json
FIGURE_EXPORT_MANIFEST_R5.json
FIGURE_3_LEGEND_CHANGE_LEDGER_R5.json
FIGURE_VISUAL_QA_R5.json
R4_DOCX_FIGURE_EMBEDDING_CHECK.json
RAPORT_FIGURI_R5_RO.txt

The sources/ directory contains historical originals. For the current Figure
3 appearance use derivatives/Figure_3_Reference_Cell_Diagnostics_R5_legend_fixed.svg.
The script recreates that derivative from the original SVG. Original PDFs and
the historical generator retain the old legend position by design; they are
not represented as the corrected R5 Figure 3 source.

Dependencies and tested environment

Executed and visually checked in Linux with Python 3.12, Pillow 13.0.0, numpy
and Inkscape 1.4 (e7c3feb100, 2024-10-09). The exact Python/platform versions
are in FIGURE_EXPORT_MANIFEST_R5.json. DejaVu Sans regular, Bold and Oblique
must be installed. The inkscape and fc-match executables must be on PATH.
No PDF editing, OCR, external network access or simulation rerun is required.

Windows execution and Windows portability have NOT been tested. These are
the commands used in the Linux environment, with path arguments exposed for
relocation. Font/rendering differences on another environment require visual
inspection of the regenerated output. Do not claim byte-identical TIFFs on a
different renderer/version without checking.

Required inputs and path arguments

--r4-dir identifies the complete, unchanged R4 package directory. Its
01_UPLOAD_SET must contain the original four TIFF files and
09_Supplementary_Material_S2.zip. The script verifies their fixed R4 hashes.
The original R4 package must be available separately; extracting this R5
figure directory alone is not sufficient for all baseline comparisons.

--work-dir identifies THIS figure directory after extraction or relocation.
It must contain SOURCE_VECTOR_PROVENANCE_R5.json and sources/ with the nine
immutable source files named in that manifest. The script writes derivatives/,
final/, previews/, render_work/ and its export/legend manifests here. A rerun
replaces generated files in --work-dir; it does not modify --r4-dir or sources/.
Do not put --work-dir inside the original --r4-dir.

Command from the original project workspace:

python tmp/tasm_r5_20261111/figures/export_r5_figures.py \
  --r4-dir output/tasm_corrected_r4_20261111/TASM_269811381_CORRECTED_R4_20261111 \
  --work-dir tmp/tasm_r5_20261111/figures

For a relocated package, replace both directory arguments with the actual
absolute paths and invoke the script from the relocated figure directory.
The script does not depend on a particular current working directory when
both path arguments are supplied as absolute paths.

Checks performed by the script

Source SHA-256, original TIFF SHA-256, unchanged R4 S2 SHA-256, zero embedded
raster images in the SVG sources, the sole authorised SVG attribute change,
identical text and all other SVG attributes, actual TIFF pixel dimensions,
1200 dpi tags, RGB and LZW encoding, exact rational equality of physical
dimensions, preservation of intended flat-fill RGB values and white-only
margin trimming. No final-image resize or upsampling is used. The possible
1–2-pixel margin adjustments and their white-pixel checks are recorded.

Visual QA is a separate operation. The delivered FIGURE_VISUAL_QA_R5.json
records actual inspection of the delivered hashes; rerunning the script does
not automatically create a new visual QA approval for newly generated hashes.

R4 DOCX manuscripts contain no embedded or linked figure images. No DOCX
image replacement is required for this figure update.

General publisher source

https://authorservices.taylorandfrancis.com/wp-content/uploads/2021/08/Submission-of-electronic-artwork-guide.pdf
Resolution table: PDF page 3. Current linked guide verified 11 November 2026.
