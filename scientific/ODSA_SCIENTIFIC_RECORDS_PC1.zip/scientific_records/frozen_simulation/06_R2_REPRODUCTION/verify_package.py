"""Read-only verification of the S2 payload and actual figure manifest."""
from pathlib import Path
import csv
import hashlib
import json
import re
import sys

ROOT = Path(__file__).resolve().parents[1]


def digest(path):
    sha = hashlib.sha256()
    with path.open('rb') as handle:
        for block in iter(lambda: handle.read(1024*1024), b''):
            sha.update(block)
    return sha.hexdigest()


def safe_path(root, relative):
    target = (root / relative).resolve()
    if root.resolve() not in target.parents:
        raise ValueError(f'Invalid manifest path: {relative}')
    return target


def main():
    failures = []
    actual = {p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*')
              if p.is_file() and not any(part in {'__pycache__', '.pytest_cache'} for part in p.parts)}
    with (ROOT / 'MANIFEST.csv').open(encoding='utf-8-sig', newline='') as handle:
        rows = list(csv.DictReader(handle))
    manifest_paths = [r['path'] for r in rows]
    expected_payload = actual - {'MANIFEST.csv', 'SHA256SUMS.txt'}
    if set(manifest_paths) != expected_payload or len(set(manifest_paths)) != len(manifest_paths):
        failures.append({'scope': 'MANIFEST.csv inventory', 'missing_entries': sorted(expected_payload-set(manifest_paths)),
                         'missing_files': sorted(set(manifest_paths)-expected_payload), 'duplicates': len(manifest_paths)-len(set(manifest_paths))})
    for row in rows:
        p = safe_path(ROOT, row['path'])
        if not p.is_file() or p.stat().st_size != int(row['bytes']) or digest(p) != row['sha256']:
            failures.append({'scope': 'MANIFEST.csv fingerprint', 'path': row['path']})
    sha_records = []
    for line in (ROOT / 'SHA256SUMS.txt').read_text(encoding='utf-8').splitlines():
        sha, path = line.split('  ', 1)
        sha_records.append(path)
        p = safe_path(ROOT, path)
        if not re.fullmatch('[0-9a-f]{64}', sha) or not p.is_file() or digest(p) != sha:
            failures.append({'scope': 'SHA256SUMS.txt fingerprint', 'path': path})
    if set(sha_records) != actual-{'SHA256SUMS.txt'} or len(sha_records) != len(set(sha_records)):
        failures.append({'scope': 'SHA256SUMS.txt inventory'})
    froot = ROOT / '05_FIGURE_REPRODUCTION'
    with (froot / 'SOURCE_DATA/EINT_R5_FIGURE_FILE_MANIFEST.csv').open(encoding='utf-8-sig', newline='') as handle:
        figures = list(csv.DictReader(handle))
    for row in figures:
        p = safe_path(froot, row['path'])
        if not p.is_file() or p.stat().st_size != int(row['bytes']) or digest(p) != row['sha256']:
            failures.append({'scope': 'figure manifest fingerprint', 'path': row['path']})
    indexed = [r['path'] for r in figures]
    figure_files = {p.relative_to(froot).as_posix() for folder in ('TIFF','PNG_QA','SVG','PDF_VECTOR','PPTX_EDITABLE')
                    for p in (froot/folder).glob('*') if p.is_file()}
    if set(indexed) != figure_files or len(indexed) != len(set(indexed)):
        failures.append({'scope': 'figure manifest inventory'})
    report = {'status': 'PASS' if not failures else 'FAIL', 'payload_files': len(expected_payload),
              'sha256_entries': len(sha_records), 'figure_files': len(figures), 'failures': failures,
              'scope': 'Package byte integrity only; this does not execute or validate the full simulation.'}
    print(json.dumps(report, indent=2))
    return int(bool(failures))


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (OSError, ValueError, KeyError) as error:
        print(f'ERROR: {error}', file=sys.stderr)
        raise SystemExit(1)
