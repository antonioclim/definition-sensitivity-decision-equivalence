"""Portable, bounded reproduction of the preserved S2 implementation.

Default: protocol validation only. There is deliberately no full-grid mode.
The tests/smoke/reference modes execute the supplied engine without editing it.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import os
from pathlib import Path
import subprocess
import sys
import time
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parents[1]
EXECUTABLE = ROOT / '03_EXECUTABLE'
PROTOCOL = ROOT / '02_FROZEN_PROTOCOL/eint_r2_decision_protocol.yml'
FREEZE = ROOT / '02_FROZEN_PROTOCOL/eint_r2_decision_protocol.freeze.json'
REFERENCE_NAMES = ('REFERENCE_RERUN_CELL_METRIC_SUMMARY.csv',
                   'REFERENCE_RERUN_STREAM_METRIC_SUMMARY.csv')
EXPECTED_PROTOCOL_SHA256 = '1d7361861b4eee84dda9313a52ca3a3643873744d933bcdd208dab795ec18e22'


def fingerprint(path: Path) -> tuple[int, str]:
    digest = hashlib.sha256()
    size = 0
    with path.open('rb') as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b''):
            digest.update(block)
            size += len(block)
    return size, digest.hexdigest()


def write_json(path: Path, value: dict) -> None:
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')


def validate_source() -> dict:
    if fingerprint(PROTOCOL)[1] != EXPECTED_PROTOCOL_SHA256:
        raise ValueError('The expected supplied protocol bytes have changed; bounded reproduction refused.')
    sys.path.insert(0, str(EXECUTABLE))
    from odsa_econ.protocol import load_protocol, validate_protocol, verify_freeze
    protocol = load_protocol(PROTOCOL)
    validation = validate_protocol(protocol)
    freeze = verify_freeze(PROTOCOL, FREEZE)
    if freeze.get('status') != 'PASS':
        raise ValueError('Frozen protocol verification did not pass.')
    return {'protocol': protocol, 'validation': validation, 'freeze': freeze}


def reserve_output(mode: str, requested: Path | None) -> Path:
    if requested is None:
        stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S_%fZ')
        requested = ROOT.parent / 'TASM_R2_RUNS' / f'{stamp}_{mode}'
    output = requested.expanduser().resolve()
    # Never write over or beneath a supplied source/results directory.
    if output == ROOT or ROOT in output.parents:
        raise ValueError('Use an output directory outside the supplied S2 folder.')
    if output.exists() and any(output.iterdir()):
        raise ValueError(f'Output directory is not empty: {output}')
    output.mkdir(parents=True, exist_ok=True)
    return output


def execute(command: list[str], output: Path, name: str) -> None:
    environment = os.environ.copy()
    environment['PYTHONDONTWRITEBYTECODE'] = '1'
    print('Running:', subprocess.list2cmdline(command), flush=True)
    started = time.monotonic()
    result = subprocess.run(command, cwd=EXECUTABLE, env=environment,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                            text=True, encoding='utf-8', errors='replace')
    (output / f'{name}.log').write_text(result.stdout, encoding='utf-8')
    write_json(output / f'{name}.json', {'exit_code': result.returncode,
               'elapsed_seconds': time.monotonic() - started,
               'command': command, 'cwd': str(EXECUTABLE),
               'native_platform': sys.platform, 'python': sys.version})
    print(result.stdout, end='', flush=True)
    if result.returncode:
        raise RuntimeError(f'{name} exited with status {result.returncode}; see {output}')


def compare_numeric_csv(actual: Path, expected: Path, tolerance: float = 1e-12) -> dict:
    # Identity/schema columns must match exactly. Only reported floating summaries
    # permit the documented tolerance; counts, rules and cell keys do not.
    floating = {'mean', 'sd', 'mcse', 'minimum', 'maximum'}
    with actual.open(encoding='utf-8-sig', newline='') as handle:
        left_reader = csv.DictReader(handle)
        left_fields, left = left_reader.fieldnames, list(left_reader)
    with expected.open(encoding='utf-8-sig', newline='') as handle:
        right_reader = csv.DictReader(handle)
        right_fields, right = right_reader.fieldnames, list(right_reader)
    same_structure = left_fields == right_fields and len(left) == len(right)
    changed_fields, different_rows, failures = 0, 0, []
    maximum = 0.0
    if same_structure:
        for index, (a, b) in enumerate(zip(left, right, strict=True), 1):
            row_changed = False
            for key in left_fields:
                if a[key] == b[key]:
                    continue
                row_changed = True
                changed_fields += 1
                valid = False
                if key in floating:
                    try:
                        av, bv = float(a[key]), float(b[key])
                        if math.isfinite(av) and math.isfinite(bv):
                            difference = abs(av - bv)
                            maximum = max(maximum, difference)
                            valid = difference <= tolerance
                    except (TypeError, ValueError):
                        pass
                if not valid and len(failures) < 20:
                    failures.append({'data_row': index, 'column': key,
                                     'actual': a[key], 'expected': b[key]})
            different_rows += int(row_changed)
    return {'status': 'PASS' if same_structure and not failures else 'DIFFERENCE',
            'actual_rows': len(left), 'expected_rows': len(right),
            'same_schema_and_row_count': same_structure,
            'rows_with_textual_differences': different_rows,
            'fields_with_textual_differences': changed_fields,
            'maximum_absolute_numeric_difference': maximum,
            'absolute_tolerance_for_floating_summary_columns': tolerance,
            'identity_and_count_columns_must_match_exactly': True,
            'first_mismatches_beyond_tolerance': failures}


def check_reference(output: Path) -> dict:
    historical = json.loads((ROOT / '04_AGGREGATE_RESULTS/Key_Findings.json').read_text(encoding='utf-8-sig'))
    comparisons = []
    numeric_comparisons = []
    for name in REFERENCE_NAMES:
        size, digest = fingerprint(output / name)
        expected = historical['reference_rerun']['files'][name]
        baseline = ROOT / '06_R2_REPRODUCTION/REFERENCE_AUDIT_20261111' / name
        if fingerprint(baseline) != (expected['bytes'], expected['sha256']):
            raise ValueError(f'Supplied prior-audit reference file has changed: {name}')
        numeric_comparisons.append({'file': name, **compare_numeric_csv(output / name, baseline)})
        comparisons.append({'file': name, 'actual_bytes': size, 'actual_sha256': digest,
                            'historical_bytes': expected['bytes'], 'historical_sha256': expected['sha256'],
                            'matches_historical_fingerprint': size == expected['bytes'] and digest == expected['sha256']})
    with (output / REFERENCE_NAMES[0]).open(encoding='utf-8-sig', newline='') as handle:
        rows = list(csv.DictReader(handle))
    with (output / REFERENCE_NAMES[1]).open(encoding='utf-8-sig', newline='') as handle:
        streams = list(csv.DictReader(handle))

    def select(metric: str, rule: str | None = None, parameter: str | None = None) -> dict:
        return {r['definition']: float(r['mean']) for r in rows
                if r['metric_name'] == metric and (rule is None or r['rule'] == rule)
                and (parameter is None or r['parameter'] == parameter)}

    observed = {'population_rates': select('population_mean'),
                'observed_rates': select('observed_mean'),
                'observed_mae': select('observed_mean_absolute_error'),
                'observed_strict_reversal': select('observed_strict_reversal_share'),
                'highest_top3_churn': select('observed_top_k_churn', 'top_k_highest', '3'),
                'determinate_share': select('determinate_share')}
    headline = []
    for metric, values in historical['reference_cell'].items():
        for definition, expected in values.items():
            actual = observed[metric][definition]
            headline.append({'metric': metric, 'definition': definition,
                             'historical': expected, 'recomputed': actual,
                             'absolute_difference': abs(actual - expected),
                             'matches_at_1e_12': abs(actual - expected) <= 1e-12})
    undefined = sum(float(r['n_undefined']) > 0 for r in rows + streams)
    cells = sorted({r['cell_id'] for r in rows + streams})
    passed = (len(rows) == 3988 and len(streams) == 6328 and len(headline) == 18
              and undefined == 0 and cells == ['cell_0051']
              and all(c['status'] == 'PASS' for c in numeric_comparisons)
              and all(c['matches_at_1e_12'] for c in headline))
    return {'status': 'PASS' if passed else 'DIFFERENCE',
            'scope': 'One frozen reference cell only. This is not the historical full-grid validator.',
            'reference_cells_in_output': cells, 'pooled_and_deterministic_rows': len(rows),
            'stream_rows': len(streams), 'nonzero_undefined_metric_rows': undefined,
            'historical_byte_fingerprints_match': all(c['matches_historical_fingerprint'] for c in comparisons),
            'file_hash_comparisons': comparisons, 'numeric_csv_comparisons': numeric_comparisons,
            'headline_metric_comparisons': headline,
            'full_270_cell_run_executed': False}


def run_reference(output: Path, source: dict) -> None:
    from odsa_econ.protocol import expand_full_grid
    from odsa_econ.engine import run_cell, write_csv
    protocol = source['protocol']
    specification = protocol['execution']['reference_cell']
    cells = [c for c in expand_full_grid(protocol)
             if all(c.get(k) == value for k, value in specification.items())]
    streams = int(protocol['execution']['full_stream_count'])
    replications = int(protocol['execution']['full_replications_per_stream'])
    if len(cells) != 1 or cells[0]['cell_id'] != 'cell_0051' or (streams, replications) != (4, 1000):
        raise ValueError('Reference specification differs from the supplied 1 x 4 x 1000 bounded design.')
    cell = cells[0]
    print('Reference only: cell_0051; 4 streams x 1000 = 4000 replications.', flush=True)
    started = time.monotonic()
    rows, mechanics, stream_rows = run_cell(protocol, cell, stream_count=streams,
                                           replications_per_stream=replications,
                                           retain_replicate_summaries=False)
    if mechanics or len(rows) != 3988 or len(stream_rows) != 6328:
        raise RuntimeError('Unexpected reference output structure.')
    columns = {key: value for key, value in cell.items() if key != 'modules'}
    for name, content in zip(REFERENCE_NAMES, (rows, stream_rows), strict=True):
        write_csv(output / name, [{**columns, **row} for row in content])
    report = check_reference(output)
    report.update({'mode': 'reference', 'cells_executed': 1, 'stream_count': streams,
                   'replications_per_stream': replications, 'total_replications': 4000,
                   'elapsed_seconds': time.monotonic() - started,
                   'native_platform': sys.platform, 'python': sys.version,
                   'source_freeze_validation': source['freeze']})
    write_json(output / 'REFERENCE_REPRODUCTION_CHECK.json', report)
    print(json.dumps({k: report[k] for k in ('status', 'total_replications',
                      'pooled_and_deterministic_rows', 'stream_rows', 'elapsed_seconds')}, indent=2))
    if report['status'] != 'PASS':
        raise RuntimeError('Reference numeric outputs or headline metrics differ beyond tolerance; inspect the report.')


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--mode', choices=('validate', 'tests', 'smoke', 'reference', 'check-reference'), default='validate')
    parser.add_argument('--output-dir', type=Path, help='Empty destination outside the supplied S2 folder.')
    parser.add_argument('--reference-dir', type=Path, help='Existing reference outputs to check without simulation.')
    args = parser.parse_args()
    # Prevent Python caches from changing the supplied code tree.
    sys.dont_write_bytecode = True
    source = validate_source()
    if args.mode == 'check-reference':
        if args.reference_dir is None or args.output_dir is not None:
            parser.error('check-reference requires --reference-dir and does not accept --output-dir.')
        report = check_reference(args.reference_dir.expanduser().resolve())
        print(json.dumps(report, indent=2))
        return 0 if report['status'] == 'PASS' else 1
    if args.reference_dir is not None:
        parser.error('--reference-dir is only valid with --mode check-reference.')
    output = reserve_output(args.mode, args.output_dir)
    write_json(output / 'R2_SOURCE_VALIDATION.json', {'validation': source['validation'], 'freeze': source['freeze']})
    if args.mode == 'validate':
        print(json.dumps({'status': 'PASS', 'mode': 'validate', 'simulation_replications': 0,
                          'output_dir': str(output)}, indent=2))
    elif args.mode == 'tests':
        execute([sys.executable, '-B', '-m', 'pytest', '-q', '-p', 'no:cacheprovider',
                 '--junitxml=' + str(output / 'pytest_results.xml'), str(EXECUTABLE / 'tests')], output, 'pytest_execution')
    elif args.mode == 'smoke':
        execute([sys.executable, '-B', str(EXECUTABLE / 'run_protocol.py'),
                 '--protocol', str(PROTOCOL), '--freeze', str(FREEZE), '--output-dir', str(output),
                 '--mode', 'smoke', '--workers', '1'], output, 'smoke_execution')
        execute([sys.executable, '-B', str(EXECUTABLE / 'validate_outputs.py'), str(output)], output, 'smoke_validation')
        comparison = []
        for name in ('CELL_METRIC_SUMMARY.csv', 'STREAM_METRIC_SUMMARY.csv'):
            baseline = ROOT / '04_SMOKE_OUTPUTS_NOT_MANUSCRIPT_EVIDENCE' / name
            comparison.append({'file': name,
                               'byte_identical': fingerprint(output / name) == fingerprint(baseline),
                               **compare_numeric_csv(output / name, baseline)})
        write_json(output / 'R2_SMOKE_NUMERIC_COMPARISON.json', {'files': comparison,
                   'scope': 'Execution mechanics only; smoke output is not manuscript evidence.'})
        if any(item['status'] != 'PASS' for item in comparison):
            raise RuntimeError('Smoke numeric comparison differs beyond the stated tolerance.')
    else:
        run_reference(output, source)
    print('Saved:', output, flush=True)
    return 0


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (OSError, ValueError, RuntimeError) as error:
        print(f'ERROR: {error}', file=sys.stderr)
        raise SystemExit(1)
