"""R2-specific boundary and evidence checks; the historical 23 tests are separate."""
from pathlib import Path
import csv
import importlib.util
import json
import subprocess
import sys
import tempfile
import unittest

SCRIPT = Path(__file__).resolve().parents[1] / 'reproduce_bounded.py'
spec = importlib.util.spec_from_file_location('r2_runner', SCRIPT)
runner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)


class BoundedReproductionChecks(unittest.TestCase):
    def test_default_validates_without_simulating_from_path_with_spaces(self):
        with tempfile.TemporaryDirectory(prefix='TASM runner check ') as work:
            output = Path(work) / 'validation output with spaces'
            result = subprocess.run([sys.executable, '-B', str(SCRIPT), '--output-dir', str(output)],
                                    cwd=work, capture_output=True, text=True)
            self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
            self.assertIn('"simulation_replications": 0', result.stdout)
            self.assertEqual(sorted(p.name for p in output.iterdir()), ['R2_SOURCE_VALIDATION.json'])

    def test_full_mode_is_not_available(self):
        result = subprocess.run([sys.executable, '-B', str(SCRIPT), '--mode', 'full'],
                                capture_output=True, text=True)
        self.assertEqual(result.returncode, 2)
        self.assertIn('invalid choice', result.stderr)

    def test_sources_cannot_be_used_as_output(self):
        with self.assertRaisesRegex(ValueError, 'outside'):
            runner.reserve_output('reference', runner.ROOT / '04_AGGREGATE_RESULTS')

    def test_nonempty_output_is_preserved(self):
        with tempfile.TemporaryDirectory(prefix='TASM output ') as work:
            path = Path(work)
            sentinel = path / 'existing.txt'
            sentinel.write_text('keep this result', encoding='utf-8')
            with self.assertRaisesRegex(ValueError, 'not empty'):
                runner.reserve_output('smoke', path)
            self.assertEqual(sentinel.read_text(), 'keep this result')

    def test_numeric_tolerance_does_not_hide_identifiers_or_material_changes(self):
        with tempfile.TemporaryDirectory(prefix='TASM CSV comparison ') as work:
            expected, actual = Path(work)/'baseline.csv', Path(work)/'actual.csv'
            expected.write_text('cell_id,n_defined,mean,sd,mcse,minimum,maximum\ncell_0051,4000,0.5,0.1,0.01,0.1,0.9\n')
            cases = [
                ('cell_0051,4000,0.5000000000000001,0.1,0.01,0.1,0.9', 'PASS'),
                ('cell_0052,4000,0.5,0.1,0.01,0.1,0.9', 'DIFFERENCE'),
                ('cell_0051,4001,0.5,0.1,0.01,0.1,0.9', 'DIFFERENCE'),
                ('cell_0051,4000,0.501,0.1,0.01,0.1,0.9', 'DIFFERENCE'),
            ]
            header = expected.read_text().splitlines()[0]
            for row, status in cases:
                with self.subTest(row=row):
                    actual.write_text(header+'\n'+row+'\n')
                    self.assertEqual(runner.compare_numeric_csv(actual, expected)['status'], status)

    def test_prior_audit_reference_files_match_recorded_history(self):
        report = runner.check_reference(runner.ROOT / '06_R2_REPRODUCTION/REFERENCE_AUDIT_20261111')
        self.assertEqual(report['status'], 'PASS')
        self.assertTrue(report['historical_byte_fingerprints_match'])
        self.assertEqual(len(report['headline_metric_comparisons']), 18)
        self.assertFalse(report['full_270_cell_run_executed'])


if __name__ == '__main__':
    unittest.main()
