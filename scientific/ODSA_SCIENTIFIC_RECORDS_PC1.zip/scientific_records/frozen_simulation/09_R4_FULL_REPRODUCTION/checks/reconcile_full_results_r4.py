#!/usr/bin/env python3
"""Reconstruct retained scientific aggregates from completed frozen-run summaries.

New R4 verification code, not the historical postprocessor or convergence
validator. Uses the Python standard library, never imports the simulator and
never generates Monte Carlo replicates. Full mode refuses an incomplete run.
"""
from __future__ import annotations

import argparse
from array import array
from collections import Counter, defaultdict
import csv
import hashlib
import json
import math
from pathlib import Path
import statistics
import sys
import time

PINS = {
    '02_FROZEN_PROTOCOL/eint_r2_decision_protocol.yml': '1d7361861b4eee84dda9313a52ca3a3643873744d933bcdd208dab795ec18e22',
    '02_FROZEN_PROTOCOL/EINT_R2_FULL_GRID_REGISTRY.csv': '971b7f939058a985ddcbb855cbca550c25501fee003ce7a5bb92881e63675e88',
    '04_AGGREGATE_RESULTS/Key_Findings.json': '96d483f9a14ae1d132aa486adcc80d6def10a83c764da92cf931c8e77228b19e',
    '04_AGGREGATE_RESULTS/Deterministic_Ablation_Events.csv': '76eb80f073ec414b9012e62995cdb6571ff69ab38e79403c8274b7b1377fd6b3',
    '04_AGGREGATE_RESULTS/Scenario_Ordering_Summary.csv': '7ed8fd419f5140e8e66db75321b96e7c03f9b1ca103bfe3882919d7b22a81b62',
    '04_AGGREGATE_RESULTS/Top_K_Tie_Diagnostics.csv': '4d863d42627c3d7059748207d01759f666e5c5661af4fdccdde40a4c40c5b811',
    '05_FIGURE_REPRODUCTION/SOURCE_DATA/Figure_2_ablation_event_frequencies.csv': '4790a4afced7cd57c4eb6c40121ed8291cc92ed203046182bc72ccfcf2ad7327',
    '05_FIGURE_REPRODUCTION/SOURCE_DATA/Figure_3_panel_A_reference_rates_mae.csv': 'f7262ad9141f0f7503b837efe4a9ef1714431da98cbb6aab2da6257d3eec18ac',
    '05_FIGURE_REPRODUCTION/SOURCE_DATA/Figure_3_panel_B_reference_ordering.csv': 'fc74a987911aa021ea2bc3436b3b19af877d53708e338acf0d4f05b53066116a',
    '05_FIGURE_REPRODUCTION/SOURCE_DATA/Figure_3_panel_C_unmatched_objective.csv': 'ce883a4bf65b04a6cf1702d250bba12101ba36e0eeb8ba1b7736231aca9679ea',
    '05_FIGURE_REPRODUCTION/SOURCE_DATA/Figure_4_unresolved_determinacy.csv': '185c5ad05307ccfdfae01ba955b26f9d4bc3043a876ef3687919ed5576e049bd',
    '06_R2_REPRODUCTION/REFERENCE_AUDIT_20261111/REFERENCE_RERUN_CELL_METRIC_SUMMARY.csv': 'db9abc2a30136d9f82c4367a4b26def06b251d9e099061508beb0a4295783e20',
    '06_R2_REPRODUCTION/REFERENCE_AUDIT_20261111/REFERENCE_RERUN_STREAM_METRIC_SUMMARY.csv': 'af589451d8a2e5de15ef821456ea99020df5613574977abc1df526d15d622b66',
}
HISTORICAL_FULL = {
    'CELL_METRIC_SUMMARY.csv': 'eb494924681ecdd6f88425e387040cf70f5d5e108e6cc55904c514b4ee53bd69',
    'STREAM_METRIC_SUMMARY.csv': '3731d24bf8ca22db9a503672c8b09ec09b0657466e38982a1cab8cdeafa8aeaf',
}
FACTORS = ('scenario', 'separation_level', 'added_state_heterogeneity_level', 'unit_count',
           'base_sample_size', 'allocation_profile', 'weight_profile', 'misclassification_profile', 'unresolved_profile')
DGP = FACTORS[:4]
METRIC = ('metric_family', 'metric_name', 'definition', 'objective', 'rule', 'parameter', 'cost_profile')
NUMBERS = ('mean', 'sd', 'mcse', 'minimum', 'maximum')
REF = '06_R2_REPRODUCTION/REFERENCE_AUDIT_20261111'
LABELS = {'Integrated': 'integrated_planning', 'Specialised': 'specialised_planning', 'Digitally enabled': 'digitally_enabled_planning'}
CONTRASTS = {'Integrated → specialised': 'integrated_planning__to__specialised_planning',
             'Specialised → digitally enabled': 'specialised_planning__to__digitally_enabled_planning',
             'Integrated → digitally enabled': 'integrated_planning__to__digitally_enabled_planning'}
ABLATION_LABELS = {
    'Material level detected': 'generic_level_materiality_detected',
    'Semantic mismatch': 'semantic_mismatch_detected',
    'No strict reversal with semantic mismatch': 'rank_stability_with_semantic_mismatch',
    'Numerical difference but same action': 'decision_equivalence_despite_numerical_difference',
    'Material level change but same action': 'material_level_change_without_action_disagreement',
    'Rank reversal': 'rank_reversal_detected',
    'Action change below materiality threshold': 'action_disagreement_without_material_level_change',
}


class ReconciliationFailure(ValueError):
    pass


def require(condition, message):
    if not condition:
        raise ReconciliationFailure(message)


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def file_record(path):
    return {'file': str(path), 'bytes': path.stat().st_size, 'sha256': digest(path)}


def read_csv(path):
    with path.open(encoding='utf-8-sig', newline='') as handle:
        return list(csv.DictReader(handle))


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def metric_key(row):
    return tuple(row[k] for k in METRIC)


def summarise(values):
    require(bool(values), 'Cannot summarise an empty metric group.')
    return {'n': len(values), 'mean': statistics.fmean(values), 'median': statistics.median(values),
            'minimum': min(values), 'maximum': max(values)}


def numeric_compare(expected, actual, path, comparisons, tolerance=1e-12):
    """Compare structure exactly; numerical counts are exact, summary values tolerant."""
    if isinstance(expected, dict):
        require(isinstance(actual, dict) and set(expected) == set(actual), f'Dictionary keys differ: {path}')
        for key, value in expected.items():
            numeric_compare(value, actual[key], path + '/' + str(key), comparisons, tolerance)
    elif isinstance(expected, list):
        require(isinstance(actual, list) and len(expected) == len(actual), f'List lengths differ: {path}')
        for i, (left, right) in enumerate(zip(expected, actual)):
            numeric_compare(left, right, f'{path}/{i}', comparisons, tolerance)
    elif isinstance(expected, (int, float)) and not isinstance(expected, bool):
        require(isinstance(actual, (int, float)) and math.isfinite(actual), f'Invalid numeric value: {path}')
        tol = 0.0 if isinstance(expected, int) else tolerance
        difference = abs(actual - expected)
        comparisons.append({'path': path, 'historical': expected, 'reconstructed': actual,
                            'absolute_difference': difference, 'absolute_tolerance': tol,
                            'matches': difference <= tol})
    else:
        require(type(expected) is type(actual) and expected == actual, f'Text/value differs: {path}')


def aggregate_label(row):
    name = row['metric_name']
    if name == 'observed_cost_weighted_loss' and row['cost_profile'] == 'equal_costs':
        return 'equal_cost_action_loss'
    return {'observed_strict_reversal_share': 'reversal', 'observed_top_k_churn': 'top_k_churn',
            'observed_mean_absolute_error': 'mae', 'unresolved_record_share': 'unresolved',
            'determinate_share': 'determinate', 'threshold_ambiguous_share': 'threshold_ambiguity',
            'top_k_possible_excess': 'top_k_possible_excess'}.get(name)


def collect(cell_csv, registry, reference_rows, reference_only=False):
    """Keep compact selected metric arrays and 48 deterministic numeric baselines."""
    definitions = ('population_rates', 'observed_rates', 'observed_mae', 'observed_strict_reversal',
                   'highest_top3_churn', 'determinate_share')
    result = {'reference_cell': {k: {} for k in definitions}}
    groups = {k: defaultdict(lambda: array('d')) for k in ('sample_size', 'sample_size_reversal_by_scenario', 'weighting', 'observation', 'core_scenarios')}
    ablation = defaultdict(lambda: [0, 0])
    ordering, ties = defaultdict(lambda: array('d')), defaultdict(lambda: [0, 0])
    sample_ties = defaultdict(lambda: Counter())
    semantic, fig4, extracted = {}, {}, []
    reference_cell = next(r for r in registry if r['cell_id'] == 'cell_0051')
    selected_registry = [reference_cell] if reference_only else registry
    registry_index = {r['cell_id']: r for r in selected_registry}
    expected_ids = [r['cell_id'] for r in selected_registry]
    det_keys = {metric_key(r): i for i, r in enumerate(r for r in reference_rows if r['stream_id'] == 'deterministic')}
    require(len(det_keys) == 2406, 'Reference deterministic contract has wrong size.')
    populations, observed_ids = {}, []
    maximum_deterministic_repeat_difference = 0.0
    deterministic_repeat_numeric_comparisons = 0
    current_id = None
    rows_in_cell = 0
    total_rows = 0
    first_population = False
    with cell_csv.open(encoding='utf-8-sig', newline='') as handle:
        reader = csv.DictReader(handle)
        require(reader.fieldnames == list(reference_rows[0]), 'Cell CSV schema differs from pinned reference.')
        for row in reader:
            require(None not in row and all(v is not None for v in row.values()), 'Malformed CSV row.')
            cid = row['cell_id']
            if cid != current_id:
                if current_id is not None:
                    require(rows_in_cell == 3988, f'Incomplete cell {current_id}: {rows_in_cell} rows.')
                require(len(observed_ids) < len(expected_ids) and cid == expected_ids[len(observed_ids)], f'Unexpected/out-of-order cell {cid}.')
                observed_ids.append(cid)
                current_id, rows_in_cell = cid, 0
                cell = registry_index[cid]
                modules = set(cell['modules'].split(';'))
                dgp_key = tuple(cell[k] for k in DGP)
                first_population = dgp_key not in populations
                if first_population:
                    populations[dgp_key] = array('d', [math.nan]) * len(det_keys)
                population = populations[dgp_key]
            rows_in_cell += 1
            total_rows += 1
            require(rows_in_cell <= 3988, f'Too many rows in {cid}.')
            require(all(row[k] == cell[k] for k in FACTORS), f'Grid-factor mismatch in {cid}.')
            value = float(row['mean'])
            require(math.isfinite(value), f'Nonfinite mean in {cid}.')
            name, definition = row['metric_name'], row['definition']
            if cid == 'cell_0051':
                extracted.append(row)
                refname = {'population_mean': 'population_rates', 'observed_mean': 'observed_rates',
                           'observed_mean_absolute_error': 'observed_mae', 'observed_strict_reversal_share': 'observed_strict_reversal',
                           'determinate_share': 'determinate_share'}.get(name)
                if name == 'observed_top_k_churn' and row['rule'] == 'top_k_highest' and row['parameter'] == '3':
                    refname = 'highest_top3_churn'
                if refname:
                    require(definition not in result['reference_cell'][refname], f'Duplicate reference headline: {refname}/{definition}')
                    result['reference_cell'][refname][definition] = value
                if row['objective'] == 'dedicated_or_integrated_objective' and name in ('false_inclusion_mass', 'false_exclusion_mass'):
                    semantic[(definition, name)] = value
            if name == 'determinate_share' and all(cell[k] == reference_cell[k] for k in FACTORS if k != 'unresolved_profile'):
                fig4[(cell['unresolved_profile'], definition)] = value
            if row['stream_id'] == 'deterministic':
                key = metric_key(row)
                require(key in det_keys, f'Unexpected deterministic metric: {key}')
                position = det_keys[key]
                if first_population:
                    require(math.isnan(population[position]), f'Duplicate deterministic metric in {cid}.')
                    population[position] = value
                    if row['metric_family'] == 'ablation':
                        require(value in (0.0, 1.0), 'Nonbinary ablation event.')
                        ablation[name][0] += 1
                        ablation[name][1] += int(value)
                    if name in ('population_pairwise_disagreement_share', 'population_strict_reversal_share'):
                        ordering[(cell['scenario'], definition, name)].append(value)
                    if name in ('population_cross_definition_boundary_tie', 'population_objective_or_definition_boundary_tie'):
                        require(value in (0.0, 1.0), 'Nonbinary tie flag.')
                        ties[(cell['scenario'], name)][0] += 1
                        ties[(cell['scenario'], name)][1] += int(value)
                else:
                    require(math.isfinite(population[position]), f'Incomplete deterministic baseline: {cid}.')
                    diff = abs(value - population[position])
                    deterministic_repeat_numeric_comparisons += 1
                    maximum_deterministic_repeat_difference = max(maximum_deterministic_repeat_difference, diff)
                    require(diff <= 1e-12, f'Deterministic population differs across observation settings: {cid}/{key}')
                if 'sample_size' in modules:
                    if name == 'population_cross_definition_boundary_tie':
                        sample_ties[cell['base_sample_size']]['churn_cases'] += 1
                        sample_ties[cell['base_sample_size']]['churn_tied'] += int(value)
                    elif name == 'population_objective_or_definition_boundary_tie':
                        sample_ties[cell['base_sample_size']]['action_top_k_tied'] += int(value)
                continue
            require(row['stream_id'] == 'pooled', f'Unexpected stream in cell file: {row["stream_id"]}')
            label = aggregate_label(row)
            if label is None:
                continue
            if 'sample_size' in modules and label in {'equal_cost_action_loss', 'reversal', 'top_k_churn', 'mae'}:
                groups['sample_size'][str((int(cell['base_sample_size']), label))].append(value)
                if label == 'reversal':
                    groups['sample_size_reversal_by_scenario']['|'.join((cell['base_sample_size'], label, cell['scenario'], definition))].append(value)
                if label == 'equal_cost_action_loss':
                    sample_ties[cell['base_sample_size']]['action_loss_cases'] += 1
            if 'weighting' in modules and label in {'equal_cost_action_loss', 'reversal', 'top_k_churn', 'mae'}:
                groups['weighting'][cell['weight_profile'] + '|' + label].append(value)
            if 'observation' in modules:
                groups['observation']['|'.join((cell['misclassification_profile'], cell['unresolved_profile'], label))].append(value)
            if 'core' in modules and label in {'reversal', 'top_k_churn'}:
                groups['core_scenarios']['|'.join((cell['scenario'], 'observed_' + label, definition))].append(value)
    require(rows_in_cell == 3988 and observed_ids == expected_ids, 'Incomplete final cell/grid.')
    require(all(all(math.isfinite(v) for v in values) for values in populations.values()), 'Incomplete deterministic baselines.')
    if not reference_only:
        require(len(populations) == 48, 'The full design must contain 48 distinct deterministic populations.')
        result.update({section: {key: summarise(values) for key, values in sorted(items.items())} for section, items in groups.items()})
        result['ablation'] = [{'metric_name': key, 'prespecified_cases': n, 'event_count': events, 'event_fraction': events / n, 'mutually_exclusive': 'NO'} for key, (n, events) in sorted(ablation.items())]
        result['deterministic_scenario_ordering'] = [{'scenario': scenario, 'contrast': contrast, 'metric_name': metric, 'dgp_variants': len(values), 'mean': statistics.fmean(values), 'minimum': min(values), 'maximum': max(values)} for (scenario, contrast, metric), values in sorted(ordering.items())]
    diagnostics = {'cells_read': len(observed_ids), 'cell_ids': observed_ids, 'cell_rows_read': total_rows,
                   'distinct_deterministic_populations': len(populations),
                   'deterministic_repeat_numeric_comparisons': deterministic_repeat_numeric_comparisons,
                   'maximum_deterministic_repeat_difference': maximum_deterministic_repeat_difference,
                   'sample_size_tie_counts': {k: dict(v) for k, v in sorted(sample_ties.items())},
                   'memory_design': 'One CSV row at a time; compact selected aggregate arrays, 48 x 2406 deterministic doubles and the reference-cell rows. No full DataFrame.'}
    return result, diagnostics, extracted, semantic, fig4, ties


def compare_reference(actual_rows, expected_rows):
    require(len(actual_rows) == len(expected_rows), 'Reference table row count differs.')
    maximum, numeric_count, textual_differences = 0.0, 0, 0
    for i, (actual, expected) in enumerate(zip(actual_rows, expected_rows)):
        require(actual.keys() == expected.keys(), f'Reference table schema differs at row {i}.')
        for key, value in expected.items():
            if actual[key] != value:
                textual_differences += 1
            if key in NUMBERS:
                difference = abs(float(actual[key]) - float(value))
                require(math.isfinite(float(actual[key])) and difference <= 1e-12, f'Reference numeric mismatch at row {i}/{key}.')
                maximum = max(maximum, difference)
                numeric_count += 1
            else:
                require(actual[key] == value, f'Reference identity/count mismatch at row {i}/{key}.')
    return {'status': 'PASS', 'rows': len(actual_rows), 'numeric_fields_compared': numeric_count,
            'maximum_absolute_numeric_difference': maximum, 'textual_field_differences': textual_differences,
            'numeric_tolerance': 1e-12, 'identity_and_count_fields_exact': True}


def extract_stream_reference(path, expected_rows):
    rows, seen = [], False
    with path.open(encoding='utf-8-sig', newline='') as handle:
        reader = csv.DictReader(handle)
        require(reader.fieldnames == list(expected_rows[0]), 'Stream CSV schema differs from reference.')
        for row in reader:
            if row['cell_id'] == 'cell_0051':
                rows.append(row)
                seen = True
                require(len(rows) <= 6328, 'Too many reference stream rows.')
            elif seen:
                break
    require(len(rows) == 6328, 'Complete reference stream block not found.')
    return rows


def write_extract(path, rows):
    with path.open('w', encoding='utf-8-sig', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def audit(s2, run, output, reference_only=False):
    started = time.perf_counter()
    for relative, expected in PINS.items():
        require(digest(s2 / relative) == expected, 'Source fingerprint differs: ' + relative)
    historical = json.loads((s2 / '04_AGGREGATE_RESULTS/Key_Findings.json').read_text(encoding='utf-8-sig'))
    execution = None
    if not reference_only:
        execution_path = run / 'EXECUTION_SUMMARY.json'
        require(execution_path.is_file(), 'Full run has no final EXECUTION_SUMMARY.json; do not audit partial files.')
        execution = json.loads(execution_path.read_text(encoding='utf-8-sig'))
        for key, expected in {'status': 'PASS', 'mode': 'full', 'cell_count': 270, 'stream_count': 4,
                              'replications_per_stream': 1000, 'replications_per_cell': 4000,
                              'replicate_count': 1080000, 'summary_row_count': 1076760,
                              'stream_summary_row_count': 1708560}.items():
            require(execution.get(key) == expected, f'Incomplete/unexpected execution summary: {key}.')
    registry = read_csv(s2 / '02_FROZEN_PROTOCOL/EINT_R2_FULL_GRID_REGISTRY.csv')
    baseline_cell = read_csv(s2 / REF / 'REFERENCE_RERUN_CELL_METRIC_SUMMARY.csv')
    baseline_stream = read_csv(s2 / REF / 'REFERENCE_RERUN_STREAM_METRIC_SUMMARY.csv')
    cell, stream = run / 'CELL_METRIC_SUMMARY.csv', run / 'STREAM_METRIC_SUMMARY.csv'
    reconstructed, diagnostics, reference, semantic, fig4, ties = collect(cell, registry, baseline_cell, reference_only)
    comparisons = []
    for key, actual in reconstructed.items():
        numeric_compare(historical[key], actual, 'Key_Findings/' + key, comparisons)
    reference_stream = extract_stream_reference(stream, baseline_stream)
    table_comparisons = {'cell': compare_reference(reference, baseline_cell), 'stream': compare_reference(reference_stream, baseline_stream)}
    extracts = []
    for label, rows, expected in [('CELL', reference, PINS[REF + '/REFERENCE_RERUN_CELL_METRIC_SUMMARY.csv']), ('STREAM', reference_stream, PINS[REF + '/REFERENCE_RERUN_STREAM_METRIC_SUMMARY.csv'])]:
        path = output / ('R4_REFERENCE_EXTRACTED_' + label + '_METRIC_SUMMARY.csv')
        write_extract(path, rows)
        extracts.append({**file_record(path), 'historical_sha256': expected, 'historical_byte_identity': digest(path) == expected})
    figure_comparisons = []
    source_data = s2 / '05_FIGURE_REPRODUCTION/SOURCE_DATA'
    for row in read_csv(source_data / 'Figure_3_panel_A_reference_rates_mae.csv'):
        definition = LABELS[row['definition']]
        for column, key in [('population_rate', 'population_rates'), ('observed_mae', 'observed_mae')]:
            numeric_compare(float(row[column]), reconstructed['reference_cell'][key][definition], f'Figure3A/{definition}/{column}', figure_comparisons)
    for row in read_csv(source_data / 'Figure_3_panel_B_reference_ordering.csv'):
        contrast = CONTRASTS[row['contrast']]
        for column, key in [('strict_reversal_share', 'observed_strict_reversal'), ('highest_top3_churn', 'highest_top3_churn')]:
            numeric_compare(float(row[column]), reconstructed['reference_cell'][key][contrast], f'Figure3B/{contrast}/{column}', figure_comparisons, 5e-11)
    for row in read_csv(source_data / 'Figure_3_panel_C_unmatched_objective.csv'):
        definition = LABELS[row['definition']]
        kind = 'false_exclusion_mass' if row['mismatch_type'] == 'False exclusion' else 'false_inclusion_mass'
        numeric_compare(float(row['semantic_mismatch_mass']), semantic[(definition, kind)], f'Figure3C/{definition}', figure_comparisons, 5e-6)
    tie_comparisons = []
    if not reference_only:
        observed_ablation = {r['metric_name']: r for r in reconstructed['ablation']}
        for row in read_csv(s2 / '04_AGGREGATE_RESULTS/Deterministic_Ablation_Events.csv'):
            actual = observed_ablation[row['metric_name']]
            expected = {'metric_name': row['metric_name'], 'prespecified_cases': int(row['prespecified_cases']), 'event_count': int(row['event_count']), 'event_fraction': float(row['event_fraction']), 'mutually_exclusive': row['mutually_exclusive']}
            numeric_compare(expected, actual, 'Ablation_CSV/' + row['metric_name'], comparisons)
        ordering_index = {(r['scenario'], r['contrast'], r['metric_name']): r for r in reconstructed['deterministic_scenario_ordering']}
        for row in read_csv(s2 / '04_AGGREGATE_RESULTS/Scenario_Ordering_Summary.csv'):
            expected = {**row, 'dgp_variants': int(row['dgp_variants']), 'mean': float(row['mean']), 'minimum': float(row['minimum']), 'maximum': float(row['maximum'])}
            key = (row['scenario'], row['contrast'], row['metric_name'])
            numeric_compare(expected, ordering_index[key], 'Ordering_CSV/' + '|'.join(key), comparisons)
        for row in read_csv(s2 / '04_AGGREGATE_RESULTS/Top_K_Tie_Diagnostics.csv'):
            key = (row['scenario'], row['tie_metric'])
            n, events = ties[key]
            actual = {'prespecified_rows': n, 'tie_event_fraction': events / n}
            expected = {'prespecified_rows': int(row['prespecified_rows']), 'tie_event_fraction': float(row['tie_event_fraction'])}
            numeric_compare(expected, actual, 'Tie_CSV/' + '|'.join(key), tie_comparisons)
            require(row['point_top_k_main_text_eligibility'] == ('YES' if events == 0 else 'NO_WITHOUT_SET_VALUED_OR_TIE_CONDITIONED_INTERPRETATION'), 'Tie eligibility label differs.')
        for size, actual in diagnostics['sample_size_tie_counts'].items():
            numeric_compare({'churn_cases': 108, 'churn_tied': 48, 'action_top_k_tied': 168, 'action_loss_cases': 1152}, actual, 'R2_README_tie_counts/sample_size_' + size, tie_comparisons, 0)
        for row in read_csv(source_data / 'Figure_2_ablation_event_frequencies.csv'):
            actual = observed_ablation[ABLATION_LABELS[row['diagnostic']]]
            for column, key in [('events', 'event_count'), ('cases', 'prespecified_cases')]:
                numeric_compare(int(row[column]), actual[key], 'Figure2/' + row['diagnostic'] + '/' + column, figure_comparisons)
            numeric_compare(float(row['fraction']), actual['event_fraction'], 'Figure2/' + row['diagnostic'] + '/fraction', figure_comparisons, 5e-11)
        profiles = {'No unresolved': 'none', 'Independent ≈5% unresolved': 'state_independent_05', 'State-dependent unresolved': 'state_dependent_10'}
        for row in read_csv(source_data / 'Figure_4_unresolved_determinacy.csv'):
            key = (profiles[row['profile']], LABELS[row['definition']])
            numeric_compare(float(row['determinate_pair_share']), fig4[key], 'Figure4/' + '|'.join(key), figure_comparisons, 5e-11 if key[0] == 'none' else 5e-4)
    all_comparisons = comparisons + tie_comparisons + figure_comparisons
    failed = [r for r in all_comparisons if not r['matches']]
    inputs = []
    for path in (cell, stream):
        item = file_record(path)
        item['historical_sha256'] = HISTORICAL_FULL[path.name] if not reference_only else PINS[REF + '/REFERENCE_RERUN_' + path.name]
        item['historical_byte_identity'] = item['sha256'] == item['historical_sha256']
        inputs.append(item)
    elapsed = time.perf_counter() - started
    report = {'status': 'PASS' if not failed else 'FAIL', 'scope': 'reference' if reference_only else 'full',
              'date_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
              'checker': 'New independent R4 scientific aggregate reconciliation; not historical postprocessor.',
              'checker_sha256': digest(Path(__file__)), 'simulation_executed_by_checker': False,
              'native_platform': sys.platform, 'python': sys.version, 'elapsed_seconds': elapsed,
              'full_execution_summary_checked_before_csv_read': not reference_only,
              'execution_summary': execution, 'input_files': inputs, 'historical_source_hashes': PINS,
              'diagnostics': diagnostics,
              'scientific_aggregate_numeric_comparisons': len(comparisons),
              'tie_numeric_comparisons': len(tie_comparisons),
              'figure_numeric_comparisons': len(figure_comparisons),
              'total_numeric_comparisons': len(all_comparisons),
              'failed_comparisons': failed,
              'maximum_aggregate_absolute_difference': max((r['absolute_difference'] for r in comparisons), default=0),
              'reference_table_comparisons': table_comparisons, 'reference_extracts': extracts,
              'aggregate_comparisons': comparisons, 'tie_comparisons': tie_comparisons, 'figure_comparisons': figure_comparisons,
              'limits': [
                  'The checker does not execute the simulator and does not by itself establish that stored summaries arose from the stated replicates; execution provenance is retained separately.',
                  'These are numeric field comparisons, not independent scientific experiments or hypothesis tests.',
                  'The historical full CSVs are absent; their recorded SHA-256 values are compared separately from reconstructed aggregate agreement.',
                  'Only fields with an explicit source-to-summary mapping are reconstructed. Historical z_span, stream-index drift, rank-normalised split R-hat, ESS and replicate-level distributions are not reconstructed.',
                  'The deterministic ablation and ordering summaries use 48 unique (scenario,separation,heterogeneity,unit_count) populations, removing repeated observation settings.',
                  'Module summaries give each selected cell/metric row equal weight, preserving the historical synthetic-design aggregation; no real-world probabilities or causal effects are inferred.',
                  'Figure comparisons respect retained display rounding: 10 decimal places for fractions, five for semantic mismatch and three for unresolved Figure 4 values.',
              ]}
    save(output / 'R4_RECONSTRUCTED_AGGREGATES.json', {'scope': report['scope'], 'input_files': inputs, 'aggregates': reconstructed})
    save(output / 'R4_SCIENTIFIC_RECONCILIATION.json', report)
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--s2-root', type=Path, required=True)
    parser.add_argument('--run-dir', type=Path, required=True)
    parser.add_argument('--output-dir', type=Path, required=True)
    parser.add_argument('--reference-only', action='store_true', help='Development/independent reference check only; never certify a full grid.')
    args = parser.parse_args()
    s2, run, output = (p.resolve() for p in (args.s2_root, args.run_dir, args.output_dir))
    for source in (s2, run):
        if output == source or source in output.parents or output in source.parents:
            parser.error('Output must be outside and separate from input source trees.')
    if output.exists() and (not output.is_dir() or any(output.iterdir())):
        parser.error('Output must be a new or empty directory; no overwrite is performed.')
    output.mkdir(parents=True, exist_ok=True)
    try:
        report = audit(s2, run, output, args.reference_only)
    except (ReconciliationFailure, OSError, ValueError, KeyError, csv.Error) as error:
        report = {'status': 'FAIL', 'scope': 'reference' if args.reference_only else 'full',
                  'simulation_executed_by_checker': False, 'error_type': type(error).__name__, 'error': str(error)}
        save(output / 'R4_SCIENTIFIC_RECONCILIATION.json', report)
    print(json.dumps({k: report[k] for k in ('status', 'scope', 'total_numeric_comparisons', 'scientific_aggregate_numeric_comparisons', 'tie_numeric_comparisons', 'figure_numeric_comparisons', 'elapsed_seconds', 'maximum_aggregate_absolute_difference', 'error') if k in report}, indent=2))
    return 0 if report['status'] == 'PASS' else 1


if __name__ == '__main__':
    raise SystemExit(main())
