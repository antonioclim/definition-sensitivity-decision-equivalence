#!/usr/bin/env python3
"""Bounded checks of the new R4 reconciler; no simulations or full-run inputs."""
import argparse
import csv
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--s2-root', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    require_new = args.output.resolve()
    if require_new.exists():
        parser.error('Use a new output path.')
    script = Path(__file__).with_name('reconcile_full_results_r4.py')
    s2 = args.s2_root.resolve()
    ref = s2 / '06_R2_REPRODUCTION/REFERENCE_AUDIT_20261111'
    records = []
    with tempfile.TemporaryDirectory(prefix='TASM R4 reconciler ') as temp:
        root = Path(temp)
        fixture = root / 'reference input with spaces'
        fixture.mkdir()
        for label in ('CELL', 'STREAM'):
            shutil.copyfile(ref / f'REFERENCE_RERUN_{label}_METRIC_SUMMARY.csv', fixture / f'{label}_METRIC_SUMMARY.csv')
        def run(case, reference=True, out=None):
            output = out if out is not None else root / ('check ' + case)
            command = [sys.executable, '-B', str(script), '--s2-root', str(s2), '--run-dir', str(fixture), '--output-dir', str(output)]
            if reference:
                command.append('--reference-only')
            p = subprocess.run(command, capture_output=True, text=True)
            report_path = output / 'R4_SCIENTIFIC_RECONCILIATION.json'
            report = json.loads(report_path.read_text()) if report_path.is_file() else {}
            return p, report
        p, report = run('valid reference')
        assert p.returncode == 0 and report['status'] == 'PASS' and report['scope'] == 'reference', p.stdout + p.stderr
        assert report['total_numeric_comparisons'] == 33
        assert sum(r['rows'] for r in report['reference_table_comparisons'].values()) == 10316
        assert all(x['historical_byte_identity'] for x in report['reference_extracts'])
        records.append({'case': 'authentic_reference_paths_with_spaces', 'status': 'PASS', 'rows_compared': 10316, 'headline_and_figure_fields': 33, 'both_reference_extracts_byte_identical': True})
        p, report = run('reference cannot certify full', reference=False)
        assert p.returncode != 0 and 'no final EXECUTION_SUMMARY' in report['error']
        records.append({'case': 'reference_cannot_certify_full_without_final_execution_record', 'status': 'PASS', 'rejected_before_reading_csv': True})
        path = fixture / 'CELL_METRIC_SUMMARY.csv'
        original = path.read_bytes()
        with path.open(encoding='utf-8-sig', newline='') as handle:
            reader = csv.DictReader(handle)
            fieldnames, rows = reader.fieldnames, list(reader)
        altered = [dict(row) for row in rows]
        target = next(row for row in altered if row['metric_name'] == 'observed_mean_absolute_error')
        target['mean'] = str(float(target['mean']) + 0.001)
        def write(values):
            with path.open('w', encoding='utf-8-sig', newline='') as handle:
                writer = csv.DictWriter(handle, fieldnames=fieldnames)
                writer.writeheader()
                writer.writerows(values)
        write(altered)
        p, report = run('plausible scientific corruption')
        assert p.returncode != 0 and 'Reference numeric mismatch' in report['error']
        records.append({'case': 'plausible_mean_changed_by_0_001', 'status': 'PASS', 'detected': report['error']})
        write(rows[:-1])
        p, report = run('truncated reference')
        assert p.returncode != 0 and 'Incomplete final cell/grid' in report['error']
        records.append({'case': 'truncated_reference_cell', 'status': 'PASS', 'detected': report['error']})
        path.write_bytes(original)
        p, report = run('source output refused', out=fixture / 'invalid output')
        assert p.returncode == 2 and 'outside and separate' in p.stderr
        records.append({'case': 'output_inside_input_refused', 'status': 'PASS'})
    result = {'status': 'PASS', 'tests_passed': len(records), 'tests': records,
              'simulation_executed': False, 'full_run_csv_read': False,
              'native_platform': sys.platform, 'python': sys.version,
              'checker_sha256': digest(script), 'test_script_sha256': digest(Path(__file__)),
              'temporary_fixtures_deleted': True}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
