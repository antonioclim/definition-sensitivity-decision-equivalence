TASM 269811381 — independent scientific aggregate reconciliation, R4

PURPOSE

reconcile_full_results_r4.py is newly written verification software. It does
not import the simulation engine, modify input files or execute Monte Carlo
replications. It reconstructs the retained scientific summaries from a
completed full CELL_METRIC_SUMMARY.csv and compares the original reference
cell in both full CSVs with the hash-locked, previously retained reference.

The historical postprocessing/convergence-validator source has not been
recovered. This code therefore makes its own selection and aggregation rules
explicit. It does not claim that its implementation is the historical one.

INPUT AND COMPLETENESS CONTRACT

- The protocol, grid registry, Key_Findings.json, three historical aggregate
  CSVs, five scientific figure-input CSVs and both reference CSVs are pinned
  by SHA-256 in the checker.
- Full scope requires the final EXECUTION_SUMMARY.json with status PASS,
  mode full, 270 cells, four streams of 1,000 replications, 1,080,000 total
  replications and the expected summary-row counts. The check occurs before
  opening either full CSV, so the normal command refuses incomplete runs.
- The cell file must contain the 270 registered cells in registered order,
  each with exactly 3,988 rows and the recorded grid factors.
- This scientific comparator supplements the independent R3 structural and
  pooled/stream moment validator. It does not replace that all-row validator.
- A separate --reference-only development mode checks the bounded reference.
  Its output explicitly says scope=reference and cannot certify the full grid.

WHAT IS RECONSTRUCTED

1. The 18 reference headline values: population rates, observed rates, MAE,
   strict reversals, highest-top-three churn and strict-order determinacy.
2. All seven deterministic ablation events. Each distinct population is
   counted once, using (scenario, separation, added-state heterogeneity,
   unit_count). The 48 populations remove repeated sample/observation settings.
   Counts and denominators are exact; events remain non-mutually-exclusive.
3. The 36 deterministic scenario-ordering summaries across eight variants per
   scenario/contrast/metric, and the retained scenario-ordering CSV.
4. The complete Key_Findings sections for sample size, sample-size reversal
   by scenario/contrast, weighting, observation profiles and core scenarios.
   Module membership is read from the frozen registry, including cells that
   belong to more than one module. The registered module sizes are 30, 18,
   54 and 192 cells respectively.
5. Both historical population-boundary-tie diagnostics for each scenario,
   with exact denominators and the retained interpretation-eligibility label.
6. The R2 reporting counts of 48 tied churn cases among 108 and 168 tied
   top-k contributions within 1,152 equal-cost action-loss cases at each
   sample size. These do not filter or replace the historical point summaries.
7. The scientific figure-source values for Figures 2, 3A–C and 4, with their
   existing displayed precision retained.

AGGREGATION RULES

The checker gives equal weight to each selected pooled metric row within a
group, as implied by the registry, metric definitions and retained summaries.
It reports count, arithmetic mean, median, minimum and maximum. The mean uses
statistics.fmean and the median uses statistics.median independently of the
historical simulation aggregator.

Selection labels map to source metrics as follows:

equal_cost_action_loss -> observed_cost_weighted_loss, cost_profile=equal_costs
reversal               -> observed_strict_reversal_share
top_k_churn            -> observed_top_k_churn
mae                    -> observed_mean_absolute_error
unresolved             -> unresolved_record_share
determinate            -> determinate_share
threshold_ambiguity    -> threshold_ambiguous_share
top_k_possible_excess  -> top_k_possible_excess

Sample-size and weighting groups use the first four labels. Observation
groups use all eight. Core-scenario summaries use reversals and churn by
scenario and contrast. Deterministic population rows are handled separately
and checked for repeated-population consistency across observation settings.

These averages describe the fixed synthetic design. They are not empirical
probabilities, country rankings, causal effects or welfare estimates.

REFERENCE TABLE COMPARISON

The checker extracts cell_0051 from the completed full cell and stream files.
It compares every row and column with the two authentic R2 reference CSVs:
3,988 + 6,328 rows, or 10,316 rows in total. Identity, factor and count fields
must be textually identical. The five floating summary fields (mean, sd,
mcse, minimum, maximum) use the existing absolute tolerance of 1e-12.

The extracted CSVs are also written with the original UTF-8 BOM, schema and
CSV line-ending convention. Their SHA-256 comparisons are separate from
numeric agreement. A numeric PASS never implies byte identity.

TOLERANCES

Integer counts are exact. Unrounded retained aggregate values use an absolute
tolerance of 1e-12. Existing figure-input precision is respected rather than
silently changed:

- 5e-11 for Figure 2 fractions and Figure 3B values shown to ten decimals;
- 5e-6 for Figure 3C semantic masses shown to five decimals;
- 5e-11 for the Figure 4 no-unresolved row values;
- 5e-4 for the Figure 4 unresolved-profile values shown to three decimals.

Only the comparison uses these display tolerances. The figures, historical
data and manuscript numbers are not altered by this checker.

MEMORY AND OUTPUTS

The cell CSV is read one row at a time. Retained memory consists of compact
arrays of selected summaries, 48 x 2,406 deterministic doubles and one
reference cell. The full CSVs are not loaded into a DataFrame.

The output directory must be new or empty and separate from both S2 and the
input run directory. The command writes:

R4_SCIENTIFIC_RECONCILIATION.json
  PASS/FAIL, full/reference scope, file identities, comparisons and limits.
R4_RECONSTRUCTED_AGGREGATES.json
  Newly reconstructed derived summaries and input identities.
R4_REFERENCE_EXTRACTED_CELL_METRIC_SUMMARY.csv
R4_REFERENCE_EXTRACTED_STREAM_METRIC_SUMMARY.csv
  New extracts from the stated run, not an additional simulation.

The report records comparison counts, not counts of independent scientific
experiments. Historical binary identity is reported separately. A completed
process or a complete grid does not establish external validity.

NOT IDENTIFIED BY THESE SUMMARY FILES

The checker does not reconstruct the historical implementation of z_span or
stream-index drift. It does not obtain rank-normalised split R-hat, ESS,
autocorrelations, replicate quantiles or joint replicate outcomes. Those
claims require the relevant source and/or information not in these marginal
summary CSVs. The R3 moment diagnostic has its own explicit, narrower scope.

POWERSHELL 5.1 — OPTIONAL INDEPENDENT VERIFICATION

Edit $S2 to the existing extracted S2 R4 folder. No administrator access,
ExecutionPolicy change or package installation is needed by this checker.
Python 3.12 is the tested interpreter. These commands do not run simulations.

    $ErrorActionPreference = 'Stop'
    $S2 = 'C:\Research\TASM R4\Supplementary_Material_S2_Code_and_Aggregate_Results'
    $Check = Join-Path $S2 '09_R4_FULL_REPRODUCTION\checks\reconcile_full_results_r4.py'
    $Run = Join-Path $S2 '09_R4_FULL_REPRODUCTION\outputs'
    $Stamp = Get-Date -Format 'yyyyMMdd_HHmmss_fff'
    $Out = Join-Path $env:USERPROFILE ('TASM_R4_Reports\reconciliation_' + $Stamp)
    if (-not (Test-Path -LiteralPath $Check -PathType Leaf)) { throw 'R4 checker not found at the chosen S2 path.' }
    py -3.12 -B $Check --s2-root $S2 --run-dir $Run --output-dir $Out
    if ($LASTEXITCODE -ne 0) { throw 'Reconciliation failed; inspect its JSON report.' }

POSIX

    python3 -B '/path/S2/09_R4_FULL_REPRODUCTION/checks/reconcile_full_results_r4.py' \
      --s2-root '/path/S2' \
      --run-dir '/path/S2/09_R4_FULL_REPRODUCTION/outputs' \
      --output-dir '/new-output/R4_reconciliation'

The executed evidence accompanying the release states the actual runtime
and results. Prepared PowerShell commands are not native Windows acceptance.
