TASM 269811381 — exact historical empirical replay
R3, 11 November 2026

WHAT WAS EXECUTED

replay_historical_source.mjs executed the entire inline JavaScript recovered
in R2, including its original CSV parser and original file-processing handler.
The historical HTML was not changed. A minimal DOM adapter supplies the file
object and receives display operations. A transparent TextEncoder wrapper
observes the already-built aggregate payload at the existing fingerprint step;
the standard encoder returns the original bytes unchanged.

The replay uses the exact, already supplied harmonised World Bank CSV. It is
not a reconstruction of upstream survey recoding. It is also not acceptance
testing of the browser interface.

OBSERVED RESULT

Node.js v24.22.1 on Linux:
- All 14 original execution gates passed.
- The original aggregate fingerprint was reproduced exactly:
  b18fa495616d28bcb315634c6247e2c8c94aa10724759e82cabed19a03251fe0
- 400 leaves in the selected public aggregate blocks were identical.
- All 384 numeric comparisons were exact; maximum absolute difference 0.
- The observed execution took 1.222595 seconds, excluding source/input loading.
- The historical HTML and input CSV retained their original SHA-256 values.

The comparison covers the primary cross-stratum synthesis, ordering
diagnostics with rank arrays removed, weighting sensitivity, claim boundaries,
weighted marginal bounds, unresolved-weight-share summaries, robust separation
counts and interval-ordering determinacy. The separate post-hoc hostile-audit
sensitivities in the IM-R7B public summary are not recalculated by IM-R7C and
are explicitly outside this replay comparison.

FILES

R3_EMPIRICAL_REPLAY_EXACT.json: actual execution evidence.
R3_EMPIRICAL_REPLAY_QA.json: independent integrity/output checks.
R3_HEADER_CONTRACT.json: relevant header metadata only.
R3_UPSTREAM_PROVENANCE_AUDIT.json: upstream limits and official sources.
R3_EMPIRICAL_EVIDENCE_REPORT_RO.txt: explanatory report.
replay_historical_source.mjs: portable, dependency-free Node.js replay adapter.
07_RECOVERED_EMPIRICAL_SOURCE/: byte-identical copy of the 16-file R2 source
and public-aggregate bundle, included so the adapter can be run independently.

INPUT IDENTITY

CSV: fat0_raw_data_qje.csv
Bytes: 19,633,172
SHA-256: f61a2c6e09f4763818ae1d4db8b330e97bffd8bb0824c2d833b79d728152bd17
CRC-32: 4418a02b
Historical source SHA-256:
72f4dea52a586f8c59c5fc60fe9834154c1ba3065d517ada930d2c83593549c8

The CSV and its original archive are NOT part of the R3 deliverable. Use only
an authorised original local copy. The runner pins both source and data hashes;
it refuses a different input and does not modify source files.

OPTIONAL REPLAY COMMANDS

These examples are provided for an independent reproduction. R3 has already
executed the replay; the user is not asked to repeat it to validate this phase.
Node.js 24.22.1 is the tested runtime. No npm dependencies are required.

PowerShell 5.1 — edit the kit and CSV paths to existing local locations:

$ErrorActionPreference = 'Stop'
$Kit = 'C:\Research\TASM R3\empirical'
$SourceRoot = Join-Path $Kit '07_RECOVERED_EMPIRICAL_SOURCE'
$Runner = Join-Path $Kit 'replay_historical_source.mjs'
$Csv = 'F:\ResearchData\fat0_raw_data_qje.csv'
$Report = Join-Path $env:TEMP ('TASM_R3_EMPIRICAL_REPLAY_' + (Get-Date -Format 'yyyyMMdd_HHmmss') + '.json')
& node $Runner --source-root $SourceRoot --selftest
if ($LASTEXITCODE -ne 0) { throw 'Adapter self-test failed.' }
& node $Runner --source-root $SourceRoot --csv $Csv --out $Report
if ($LASTEXITCODE -ne 0) { throw 'Exact historical replay failed; inspect only the sanitised report.' }
Write-Host $Report

POSIX — edit the paths:

node '/path/TASM R3/empirical/replay_historical_source.mjs' \
  --source-root '/path/TASM R3/empirical/07_RECOVERED_EMPIRICAL_SOURCE' --selftest
node '/path/TASM R3/empirical/replay_historical_source.mjs' \
  --source-root '/path/TASM R3/empirical/07_RECOVERED_EMPIRICAL_SOURCE' \
  --csv '/authorised-data/fat0_raw_data_qje.csv' \
  --out '/new-output/TASM_R3_EMPIRICAL_REPLAY.json'

OUTPUT AND EVIDENCE BOUNDARY

The output contains identity checks, global counts already published, redacted
gate results and comparisons with the existing public aggregates. It contains
no input records, identifiers, source-stratum rates or exact source-level counts.
The full historical internal report is not written. Its gate evidence strings
are not exported because one includes a source-stratum minimum count.

The original source's historical gate labels are execution labels, not current
author approval, public-release approval or editorial acceptance. The source
runtime has no network, require or filesystem APIs. The outer runner reads only
the explicitly supplied input/source files and writes the sanitised report.

The replay does not establish upstream ib9b construction, the admissible state
set for every unresolved row, or the original download event date. These remain
distinct from reproducing the historical computation on the harmonised file.
