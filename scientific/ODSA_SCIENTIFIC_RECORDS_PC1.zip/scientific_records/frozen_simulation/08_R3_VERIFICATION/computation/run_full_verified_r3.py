#!/usr/bin/env python3
"""Prepare the frozen full run; execute ONLY with --authorise-full.

New orchestration for the 11 November 2026 revision. The historical simulator
and its original explicit full-execution gate remain unchanged.
"""
from __future__ import annotations
import argparse
import csv
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
import uuid

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("r3_validator", HERE / "validate_full_outputs_r3.py")
V = importlib.util.module_from_spec(spec)
spec.loader.exec_module(V)
SOURCE_HASHES = {
    "02_FROZEN_PROTOCOL/eint_r2_decision_protocol.yml": V.PROTOCOL_HASH,
    "03_EXECUTABLE/run_protocol.py": "c8112fe3ec00d4edebd1f4654a28df0e035239b38a42a6db3a300aff0a4a2719",
    "03_EXECUTABLE/preflight_full_run.py": "154ad5ca41cc2f04adb549dc83275f704eb744eec9a1f4b9b543390a2f7d1f84",
    "03_EXECUTABLE/odsa_econ/engine.py": "af71c42881dfc92ada61d33bc77a1c27d8b7f95e71f4fa74242ab2e9f9392e7d",
}
PROTECTED_RECORD_HASH = "6d6bdf786598f72cbda94e854dc19133cb67b016472c5a7dda238f09a64b95e9"


def verify_current_payload(root):
    protected_path = HERE / "R2_PROTECTED_SOURCE_HASHES.json"
    if V.digest(protected_path) != PROTECTED_RECORD_HASH:
        raise ValueError("The protected historical-source hash register differs.")
    protected = json.loads(protected_path.read_text(encoding="utf-8"))["files"]
    if len(protected) != 46:
        raise ValueError("Invalid protected historical-source register.")
    for relative, record in protected.items():
        path = (root / relative).resolve()
        if root not in path.parents or not path.is_file():
            raise ValueError(f"Protected source absent: {relative}")
        if path.stat().st_size != record["bytes"] or V.digest(path) != record["sha256"]:
            raise ValueError(f"Protected historical source differs: {relative}")
    manifest = root / "MANIFEST.csv"
    with manifest.open(encoding="utf-8-sig", newline="") as handle:
        rows = list(csv.DictReader(handle))
    if not rows or len({row["path"] for row in rows}) != len(rows):
        raise ValueError("Empty or duplicate current manifest inventory.")
    actual = {p.relative_to(root).as_posix() for p in root.rglob("*")
              if p.is_file() and not any(part in {"__pycache__", ".pytest_cache"} for part in p.parts)}
    if {row["path"] for row in rows} != actual - {"MANIFEST.csv", "SHA256SUMS.txt"}:
        raise ValueError("Current payload and manifest inventories differ.")
    for row in rows:
        path = (root / row["path"]).resolve()
        if root not in path.parents or not path.is_file():
            raise ValueError(f"Invalid or absent payload path: {row['path']}")
        if path.stat().st_size != int(row["bytes"]) or V.digest(path) != row["sha256"]:
            raise ValueError(f"Current payload fingerprint differs: {row['path']}")
    sha_rows = [line.split("  ", 1) for line in (root / "SHA256SUMS.txt").read_text(encoding="utf-8-sig").splitlines()]
    if len({p for h, p in sha_rows}) != len(sha_rows) or {p for h, p in sha_rows} != actual - {"SHA256SUMS.txt"}:
        raise ValueError("Current checksum inventory differs.")
    for expected, relative in sha_rows:
        path = (root / relative).resolve()
        if root not in path.parents or V.digest(path) != expected:
            raise ValueError(f"Current checksum differs: {relative}")
    return len(rows)


def last_complete_cell(path):
    if not path.is_file():
        return None
    with path.open("rb") as handle:
        size = handle.seek(0, 2)
        handle.seek(max(0, size - 8192))
        lines = handle.read().splitlines()
    for line in reversed(lines[:-1] if lines else []):
        parts = line.decode("utf-8", errors="ignore").split(",")
        if len(parts) >= 10 and parts[9].startswith("cell_"):
            return parts[9]
    return None


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--s2-root", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--minimum-free-gb", type=float, default=3.0)
    parser.add_argument("--authorise-full", action="store_true",
                        help="Explicit opt-in to the frozen 1,080,000-replication run. Omission performs preflight only.")
    args = parser.parse_args()
    root, output = args.s2_root.resolve(), args.output_dir.resolve()
    if output == root or root in output.parents or output in root.parents:
        parser.error("Output must be outside and separate from S2 sources.")
    if output.exists() and (not output.is_dir() or any(output.iterdir())):
        parser.error("Output must be absent or an empty directory; no resume/overwrite is performed.")
    if args.workers < 1 or args.workers > (os.cpu_count() or 1):
        parser.error("workers must be between 1 and the visible CPU count.")
    for relative, expected in SOURCE_HASHES.items():
        if V.digest(root / relative) != expected:
            parser.error(f"Historical source fingerprint differs: {relative}")
    payload_files_checked = verify_current_payload(root)
    V.load_contract(root)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ") + "_" + uuid.uuid4().hex[:8]
    audit_dir = output.parent / (output.name + "_R3_AUDIT") / stamp
    audit_dir.mkdir(parents=True)
    preflight = [sys.executable, "-B", str(root / "03_EXECUTABLE/preflight_full_run.py"),
                 "--protocol", str(root / "02_FROZEN_PROTOCOL/eint_r2_decision_protocol.yml"),
                 "--freeze", str(root / "02_FROZEN_PROTOCOL/eint_r2_decision_protocol.freeze.json"),
                 "--output-dir", str(output), "--workers", str(args.workers),
                 "--minimum-free-gb", str(args.minimum_free_gb),
                 "--report", str(audit_dir / "PREFLIGHT.json")]
    completed = subprocess.run(preflight, capture_output=True, text=True)
    save(audit_dir / "PREFLIGHT_EXECUTION.json", {
        "command": preflight, "exit_code": completed.returncode,
        "stdout": completed.stdout, "stderr": completed.stderr,
        "new_monte_carlo_replications": 0})
    if completed.returncode:
        print(completed.stdout + completed.stderr)
        return completed.returncode
    preparation = {"status": "PREFLIGHT_ONLY", "full_execution_performed": False,
                   "audit_directory": str(audit_dir), "output_directory": str(output),
                   "workers": args.workers, "protocol_sha256": V.PROTOCOL_HASH,
                   "current_payload_files_checked": payload_files_checked,
                   "protected_historical_files_checked": 46,
                   "source_hashes": SOURCE_HASHES,
                   "next_action": "Full execution is gated by --authorise-full; it must be supported by project authorisation."}
    save(audit_dir / "PREPARATION.json", preparation)
    if not args.authorise_full:
        print(json.dumps(preparation, indent=2))
        return 0
    command = [sys.executable, "-B", str(root / "03_EXECUTABLE/run_protocol.py"),
               "--protocol", str(root / "02_FROZEN_PROTOCOL/eint_r2_decision_protocol.yml"),
               "--freeze", str(root / "02_FROZEN_PROTOCOL/eint_r2_decision_protocol.freeze.json"),
               "--output-dir", str(output), "--mode", "full", "--authorise-full",
               "--workers", str(args.workers)]
    save(audit_dir / "FULL_COMMAND.json", {"command": command, "explicit_gate": True,
         "historical_engine_modified": False, "start_utc": datetime.now(timezone.utc).isoformat()})
    started = time.perf_counter()
    creation_flags = subprocess.CREATE_NEW_PROCESS_GROUP if os.name == "nt" else 0
    with (audit_dir / "FULL_CONSOLE.log").open("w", encoding="utf-8") as log:
        process = subprocess.Popen(command, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT,
                                   start_new_session=os.name != "nt", creationflags=creation_flags)
        try:
            while process.poll() is None:
                time.sleep(5)
                elapsed = time.perf_counter() - started
                progress = {"elapsed_seconds": round(elapsed, 1),
                            "last_written_cell": last_complete_cell(output / "CELL_METRIC_SUMMARY.csv"),
                            "bytes_written": sum(p.stat().st_size for p in output.glob("*SUMMARY.csv"))}
                print(json.dumps(progress), flush=True)
        except KeyboardInterrupt:
            if os.name == "nt":
                process.send_signal(signal.CTRL_BREAK_EVENT)
            else:
                os.killpg(process.pid, signal.SIGTERM)
            try:
                process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                if os.name == "nt":
                    subprocess.run(["taskkill", "/PID", str(process.pid), "/T", "/F"], capture_output=True)
                else:
                    os.killpg(process.pid, signal.SIGKILL)
                process.wait()
            save(audit_dir / "INTERRUPTED.json", {"status": "INCOMPLETE", "results_eligible": False,
                 "message": "Partial files retained for diagnosis; no automatic resume or overwrite."})
            return 130
    save(audit_dir / "FULL_PROCESS.json", {"exit_code": process.returncode,
         "elapsed_seconds": time.perf_counter() - started})
    if process.returncode:
        print(f"Full process failed. Inspect {audit_dir / 'FULL_CONSOLE.log'}", file=sys.stderr)
        return process.returncode
    try:
        validation = V.audit(root, output / "CELL_METRIC_SUMMARY.csv", output / "STREAM_METRIC_SUMMARY.csv",
                             "full", output / "EXECUTION_SUMMARY.json")
    except V.AuditFailure as error:
        save(audit_dir / "INDEPENDENT_FULL_VALIDATION.json", {
            "status": "FAIL", "failure": error.code, "context": error.context,
            "full_process_exit_code": process.returncode,
            "message": "Process completion is not successful scientific validation."})
        raise
    save(audit_dir / "INDEPENDENT_FULL_VALIDATION.json", validation)
    require_unchanged = verify_current_payload(root) == payload_files_checked
    if not require_unchanged:
        raise RuntimeError("Historical source changed while the job was running.")
    result = {"status": "FULL_EXECUTED_AND_INDEPENDENTLY_CHECKED",
              "audit_directory": str(audit_dir), "output_directory": str(output),
              "historical_source_preserved": True,
              "historical_byte_identity": all(r["historical_byte_identity"] for r in validation["file_hash_comparisons"]),
              "moment_diagnostic_threshold_exceedances": validation["moment_diagnostic"]["threshold_exceedances"],
              "limits": validation["limits"]}
    save(audit_dir / "RESULT.json", result)
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (V.AuditFailure, OSError, ValueError, KeyError) as error:
        print(f"ERROR: {error}", file=sys.stderr)
        raise SystemExit(1)
