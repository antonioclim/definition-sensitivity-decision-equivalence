#!/usr/bin/env python3
"""Independent R3 structural/moment audit; never executes the simulator.

This is newly written validation code, not the unrecovered historical validator.
Only the Python standard library is required. Files are read one cell at a time.
The immutable R2 reference supplies a hash-locked metric-identity contract.
"""
from __future__ import annotations

import argparse
from array import array
from collections import Counter, defaultdict
import csv
import hashlib
import itertools
import json
import math
from pathlib import Path
import re
import sys
import time

PROTOCOL_HASH = "1d7361861b4eee84dda9313a52ca3a3643873744d933bcdd208dab795ec18e22"
REGISTRY_HASH = "971b7f939058a985ddcbb855cbca550c25501fee003ce7a5bb92881e63675e88"
REFERENCE_HASHES = {
    "REFERENCE_RERUN_CELL_METRIC_SUMMARY.csv": "db9abc2a30136d9f82c4367a4b26def06b251d9e099061508beb0a4295783e20",
    "REFERENCE_RERUN_STREAM_METRIC_SUMMARY.csv": "af589451d8a2e5de15ef821456ea99020df5613574977abc1df526d15d622b66",
}
HISTORICAL_FULL_HASHES = {
    "CELL_METRIC_SUMMARY.csv": "eb494924681ecdd6f88425e387040cf70f5d5e108e6cc55904c514b4ee53bd69",
    "STREAM_METRIC_SUMMARY.csv": "3731d24bf8ca22db9a503672c8b09ec09b0657466e38982a1cab8cdeafa8aeaf",
}
FACTORS = ("scenario", "separation_level", "added_state_heterogeneity_level",
           "unit_count", "base_sample_size", "allocation_profile", "weight_profile",
           "misclassification_profile", "unresolved_profile")
METRIC = ("metric_family", "metric_name", "definition", "objective", "rule", "parameter", "cost_profile")
KEY = ("stream_id", "metric_scope") + METRIC
NUMBERS = ("mean", "sd", "mcse", "minimum", "maximum")
COLUMNS = list(FACTORS) + ["cell_id"] + list(KEY) + ["n_defined", "n_undefined"] + list(NUMBERS)
STREAM_IDS = ("stream_01", "stream_02", "stream_03", "stream_04")


class AuditFailure(ValueError):
    def __init__(self, code, **context):
        super().__init__(code)
        self.code = code
        self.context = context


def require(condition, code, **context):
    if not condition:
        raise AuditFailure(code, **context)


def digest(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def signature(row):
    return tuple(row[k] for k in KEY)


def metric_signature(row):
    return tuple(row[k] for k in METRIC)


def grouped_rows(path, maximum_rows):
    """Bound retained CSV records by one cell, including on malformed input."""
    with Path(path).open(encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        require(reader.fieldnames == COLUMNS, "schema_mismatch", path=str(path),
                observed=reader.fieldnames, expected=COLUMNS)
        for cell_id, group in itertools.groupby(reader, key=lambda r: r["cell_id"]):
            rows = []
            for row in group:
                require(None not in row and all(v is not None for v in row.values()),
                        "malformed_csv_record", cell_id=cell_id)
                rows.append(row)
                require(len(rows) <= maximum_rows, "too_many_rows_in_cell",
                        cell_id=cell_id, maximum_rows=maximum_rows)
            yield cell_id, rows


def numeric_row(row, expected_n, label):
    for col in ("n_defined", "n_undefined"):
        require(re.fullmatch(r"[0-9]+", row[col]) is not None,
                "invalid_count", cell_id=row["cell_id"], column=col, value=row[col])
    require(int(row["n_defined"]) == expected_n and int(row["n_undefined"]) == 0,
            "count_or_undefined_mismatch", cell_id=row["cell_id"], key=label,
            observed_defined=row["n_defined"], observed_undefined=row["n_undefined"],
            expected_defined=expected_n)
    try:
        values = {k: float(row[k]) for k in NUMBERS}
    except ValueError as error:
        raise AuditFailure("non_numeric_summary", cell_id=row["cell_id"], key=label) from error
    require(all(math.isfinite(v) for v in values.values()), "non_finite_summary",
            cell_id=row["cell_id"], key=label)
    require(values["sd"] >= 0 and values["mcse"] >= 0, "negative_sd_or_mcse",
            cell_id=row["cell_id"], key=label)
    require(values["minimum"] <= values["maximum"], "invalid_range",
            cell_id=row["cell_id"], key=label)
    require(values["minimum"] - 1e-12 <= values["mean"] <= values["maximum"] + 1e-12,
            "mean_outside_range", cell_id=row["cell_id"], key=label)
    require(abs(values["mcse"] - values["sd"] / math.sqrt(expected_n)) <= 1e-12,
            "mcse_sd_count_inconsistency", cell_id=row["cell_id"], key=label)
    if expected_n == 1:
        require(values["sd"] == values["mcse"] == 0
                and values["minimum"] == values["maximum"] == values["mean"],
                "deterministic_row_inconsistency", cell_id=row["cell_id"], key=label)
    return values


def validate_group(cell, rows, template_keys, kind):
    require(len(rows) == len(template_keys), "cell_row_count_mismatch", cell_id=cell["cell_id"],
            kind=kind, observed=len(rows), expected=len(template_keys))
    indexed = {}
    for row in rows:
        require(row["cell_id"] == cell["cell_id"], "cell_identity_mismatch")
        require(all(row[k] == cell[k] for k in FACTORS), "grid_factor_mismatch",
                cell_id=cell["cell_id"], kind=kind,
                mismatch={k: [cell[k], row[k]] for k in FACTORS if row[k] != cell[k]})
        key = signature(row)
        require(key not in indexed, "duplicate_metric_key", cell_id=cell["cell_id"], key=key)
        if kind == "cell":
            require((row["stream_id"], row["metric_scope"]) in {
                ("deterministic", "deterministic_population"), ("pooled", "stochastic_observed")},
                "invalid_scope_stream_pair", cell_id=cell["cell_id"], key=key)
            n = 1 if row["stream_id"] == "deterministic" else 4000
        else:
            require(row["stream_id"] in STREAM_IDS and row["metric_scope"] == "stochastic_observed",
                    "invalid_scope_stream_pair", cell_id=cell["cell_id"], key=key)
            n = 1000
        indexed[key] = (row, numeric_row(row, n, key))
    observed = set(indexed)
    require(observed == template_keys, "metric_identity_inventory_mismatch", cell_id=cell["cell_id"],
            kind=kind, missing=list(template_keys - observed)[:8], unexpected=list(observed - template_keys)[:8])
    return indexed


def quantiles(values):
    ordered = sorted(values)
    def q(p):
        h = (len(ordered) - 1) * p
        lo, hi = math.floor(h), math.ceil(h)
        return ordered[lo] + (h - lo) * (ordered[hi] - ordered[lo])
    return {"count": len(ordered), "median": q(.5), "p95": q(.95), "p99": q(.99),
            "p999": q(.999), "maximum": ordered[-1]} if ordered else {"count": 0}


def load_contract(root):
    p = root / "02_FROZEN_PROTOCOL/eint_r2_decision_protocol.yml"
    registry_path = root / "02_FROZEN_PROTOCOL/EINT_R2_FULL_GRID_REGISTRY.csv"
    require(digest(p) == PROTOCOL_HASH, "protocol_hash_mismatch")
    require(digest(registry_path) == REGISTRY_HASH, "registry_hash_mismatch")
    with registry_path.open(encoding="utf-8-sig", newline="") as handle:
        registry = list(csv.DictReader(handle))
    require(len(registry) == 270 and len({r["cell_id"] for r in registry}) == 270,
            "invalid_grid_registry")
    contract = {}
    reference_dir = root / "06_R2_REPRODUCTION/REFERENCE_AUDIT_20261111"
    for kind, name, expected_count in (
        ("cell", "REFERENCE_RERUN_CELL_METRIC_SUMMARY.csv", 3988),
        ("stream", "REFERENCE_RERUN_STREAM_METRIC_SUMMARY.csv", 6328),
    ):
        path = reference_dir / name
        require(digest(path) == REFERENCE_HASHES[name], "reference_contract_hash_mismatch", file=name)
        groups = list(grouped_rows(path, expected_count))
        require(len(groups) == 1 and groups[0][0] == "cell_0051", "invalid_reference_contract", kind=kind)
        rows = groups[0][1]
        keys = {signature(row) for row in rows}
        require(len(keys) == len(rows) == expected_count, "invalid_reference_key_contract", kind=kind)
        contract[kind] = keys
    return registry, contract


def audit(s2_root, cell_csv, stream_csv, scope="full", execution_summary=None):
    started = time.perf_counter()
    s2_root, cell_csv, stream_csv = map(lambda p: Path(p).resolve(), (s2_root, cell_csv, stream_csv))
    registry, contract = load_contract(s2_root)
    expected = registry if scope == "full" else [c for c in registry if c["cell_id"] == "cell_0051"]
    cell_groups = grouped_rows(cell_csv, 3988)
    stream_groups = grouped_rows(stream_csv, 6328)
    family_counts = Counter()
    maxima = dict.fromkeys(NUMBERS, 0.0)
    rhats = array("d")
    by_family = defaultdict(lambda: array("d"))
    diagnostic_exceedances = Counter()
    zero_with_drift = 0
    checked_keys = 0
    observed_cells = []
    for cell in expected:
        cell_group, stream_group = next(cell_groups, None), next(stream_groups, None)
        require(cell_group is not None and stream_group is not None, "missing_cell_block",
                expected_cell=cell["cell_id"])
        require(cell_group[0] == stream_group[0] == cell["cell_id"], "cell_order_or_identity_mismatch",
                expected_cell=cell["cell_id"], observed_cell=cell_group[0], observed_stream_cell=stream_group[0])
        pooled = validate_group(cell, cell_group[1], contract["cell"], "cell")
        streams = validate_group(cell, stream_group[1], contract["stream"], "stream")
        for key, (row, actual) in pooled.items():
            family_counts[row["metric_scope"] + "::" + row["metric_family"]] += 1
            if row["stream_id"] != "pooled":
                continue
            mkey = metric_signature(row)
            values = [streams[(sid, "stochastic_observed") + mkey][1] for sid in STREAM_IDS]
            means = [v["mean"] for v in values]
            mean = math.fsum(means) / 4
            # Independent algebra from sample moments, with equal n=1000 per stream.
            ss = math.fsum(999 * v["sd"] ** 2 + 1000 * (v["mean"] - mean) ** 2 for v in values)
            sd = math.sqrt(max(ss / 3999, 0.0))
            reconstructed = {"mean": mean, "sd": sd, "mcse": sd / math.sqrt(4000),
                             "minimum": min(v["minimum"] for v in values),
                             "maximum": max(v["maximum"] for v in values)}
            tolerances = {"mean": 1e-12, "sd": 1e-10, "mcse": 1e-12, "minimum": 0.0, "maximum": 0.0}
            for field, value in reconstructed.items():
                difference = abs(actual[field] - value)
                maxima[field] = max(maxima[field], difference)
                require(difference <= tolerances[field], "pooled_stream_reconciliation_failure",
                        cell_id=cell["cell_id"], key=mkey, column=field,
                        absolute_difference=difference, tolerance=tolerances[field])
            # Unsplit, unranked equal-stream moment diagnostic. No MCMC ESS claim.
            within = math.fsum(v["sd"] ** 2 for v in values) / 4
            between = 1000 * math.fsum((mu - mean) ** 2 for mu in means) / 3
            if within == 0:
                if between > 0:
                    zero_with_drift += 1
                    raise AuditFailure("zero_with_between_stream_drift", cell_id=cell["cell_id"], key=mkey)
                r = 1.0
            else:
                r = math.sqrt(((999 / 1000) * within + between / 1000) / within)
            require(math.isfinite(r), "non_finite_moment_diagnostic", cell_id=cell["cell_id"], key=mkey)
            rhats.append(r)
            by_family[row["metric_family"]].append(r)
            for threshold in (1.01, 1.05, 1.10):
                diagnostic_exceedances[str(threshold)] += int(r > threshold)
            checked_keys += 1
        observed_cells.append(cell["cell_id"])
    require(next(cell_groups, None) is None and next(stream_groups, None) is None,
            "unexpected_or_repeated_cell_block")
    require(checked_keys == len(expected) * 1582, "stochastic_key_count_mismatch")
    if execution_summary:
        execution = json.loads(Path(execution_summary).read_text(encoding="utf-8-sig"))
        require(scope == "full", "execution_summary_only_for_full_scope")
        for field, value in {"mode": "full", "cell_count": 270, "stream_count": 4,
                             "replications_per_stream": 1000, "replications_per_cell": 4000,
                             "replicate_count": 1080000, "summary_row_count": 1076760,
                             "stream_summary_row_count": 1708560}.items():
            require(execution.get(field) == value, "execution_summary_mismatch",
                    field=field, expected=value, actual=execution.get(field))
    hashes = []
    for actual_path, historical_name, reference_name in (
        (cell_csv, "CELL_METRIC_SUMMARY.csv", "REFERENCE_RERUN_CELL_METRIC_SUMMARY.csv"),
        (stream_csv, "STREAM_METRIC_SUMMARY.csv", "REFERENCE_RERUN_STREAM_METRIC_SUMMARY.csv"),
    ):
        actual_hash = digest(actual_path)
        expected_hash = HISTORICAL_FULL_HASHES[historical_name] if scope == "full" else REFERENCE_HASHES[reference_name]
        hashes.append({"file": str(actual_path), "bytes": actual_path.stat().st_size, "sha256": actual_hash,
                       "historical_sha256": expected_hash, "historical_byte_identity": actual_hash == expected_hash})
    return {
        "status": "PASS", "validator": "Independent R3 structural and moment validator, newly written",
        "scope": scope, "simulation_executed": False,
        "historical_validator_recovered": False, "native_platform": sys.platform,
        "python": sys.version, "elapsed_seconds": time.perf_counter() - started,
        "cells_checked": len(observed_cells), "cell_ids": observed_cells,
        "cell_rows_checked": len(expected) * 3988, "stream_rows_checked": len(expected) * 6328,
        "stochastic_keys_reconciled": checked_keys, "family_counts": dict(family_counts),
        "maximum_absolute_pooling_differences": maxima,
        "pooling_absolute_tolerances": {"mean": 1e-12, "sd": 1e-10, "mcse": 1e-12, "minimum": 0, "maximum": 0},
        "moment_diagnostic": {
            "formula": "W=mean(s_j^2); B=n*sum((mean_j-grand_mean)^2)/(m-1); R=sqrt(((n-1)*W/n+B/n)/W); m=4,n=1000. W=B=0 -> R=1; W=0,B>0 -> FAIL.",
            "scope": "Unsplit and unranked diagnostic of equal-length independent simulation streams; not modern rank-normalised split R-hat or an ESS estimate.",
            "summary": quantiles(rhats), "by_family": {k: quantiles(v) for k, v in by_family.items()},
            "threshold_exceedances": dict(diagnostic_exceedances),
            "zero_with_between_stream_drift": zero_with_drift,
            "thresholds_are_reported_not_silently_treated_as_validation_of_external_validity": True,
        },
        "file_hash_comparisons": hashes,
        "execution_summary_checked": bool(execution_summary),
        "memory_design": "Only one 3988-row cell block and one 6328-row stream block retained, plus compact diagnostic arrays; does not load full CSVs into a DataFrame.",
        "limits": [
            "The metric-identity contract is anchored to the hash-verified R2 reference; all frozen cells have the same metric set.",
            "This verifies counts, keys, grid factors, finite summaries and pooled/stream consistency, not every stochastic replicate or every deterministic estimand.",
            "Historical binary identity is reported separately and is not required for a structurally consistent new rerun.",
            "Marginal moment summaries cannot recover split/rank-normalised diagnostics, autocorrelations, ESS, replicate quantiles or joint replicate outcomes.",
            "The exact historical z_span and stream-index-drift implementation remains unavailable; neither is claimed reproduced.",
            "Passing reference scope does not certify full-grid data; full scope requires all 270 ordered cells.",
        ],
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--s2-root", required=True, type=Path)
    parser.add_argument("--cell-csv", required=True, type=Path)
    parser.add_argument("--stream-csv", required=True, type=Path)
    parser.add_argument("--scope", choices=("full", "reference"), default="full")
    parser.add_argument("--execution-summary", type=Path)
    parser.add_argument("--output", type=Path, help="New report path outside input sources; existing files are refused.")
    args = parser.parse_args()
    if args.output:
        dest = args.output.resolve()
        sources = [args.s2_root.resolve(), args.cell_csv.resolve(), args.stream_csv.resolve()]
        if dest.exists() or dest in sources or sources[0] in dest.parents:
            parser.error("--output must be a new path outside the S2 source tree")
    try:
        result = audit(args.s2_root, args.cell_csv, args.stream_csv, args.scope, args.execution_summary)
        exit_code = 0
    except (AuditFailure, OSError, ValueError, KeyError, csv.Error) as error:
        result = {"status": "FAIL", "scope": args.scope, "simulation_executed": False,
                  "failure": error.code if isinstance(error, AuditFailure) else type(error).__name__,
                  "context": error.context if isinstance(error, AuditFailure) else str(error)}
        exit_code = 1
    result["validator_sha256"] = digest(Path(__file__))
    text = json.dumps(result, ensure_ascii=False, indent=2) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(text, encoding="utf-8")
    print(text, end="")
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
