"""Regression tests for audit failures, using existing reference CSVs only.

The optional large fixture repeats reference summary values under the 270 grid
identities solely to exercise I/O/memory. It is NOT a simulation or scientific
reproduction and is destroyed after testing.
"""
import argparse
import csv
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import subprocess
import sys
import tempfile
import time

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("r3_validator", HERE / "validate_full_outputs_r3.py")
V = importlib.util.module_from_spec(spec)
spec.loader.exec_module(V)


def write_csv(path, rows):
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=V.COLUMNS)
        writer.writeheader()
        writer.writerows(rows)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--s2-root", required=True, type=Path)
    parser.add_argument("--full-size-synthetic", action="store_true")
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    root = args.s2_root.resolve()
    ref = root / "06_R2_REPRODUCTION/REFERENCE_AUDIT_20261111"
    cp, sp = [ref / n for n in V.REFERENCE_HASHES]
    source_hashes_before = {p.name: V.digest(p) for p in (cp, sp)}
    with cp.open(encoding="utf-8-sig", newline="") as handle:
        cell_rows = list(csv.DictReader(handle))
    with sp.open(encoding="utf-8-sig", newline="") as handle:
        stream_rows = list(csv.DictReader(handle))
    results = []
    baseline = V.audit(root, cp, sp, "reference")
    assert baseline["status"] == "PASS"
    results.append({"case": "unaltered_reference", "status": "PASS", "keys": 1582})
    with tempfile.TemporaryDirectory(prefix="TASM_R3_validator_tests_") as temp:
        temporary = Path(temp)
        def mutation(name, target, change, expected_code, scope="reference"):
            cells = [dict(row) for row in cell_rows]
            streams = [dict(row) for row in stream_rows]
            change(cells if target == "cell" else streams)
            cfile, sfile = temporary / "cell.csv", temporary / "stream.csv"
            write_csv(cfile, cells); write_csv(sfile, streams)
            try:
                V.audit(root, cfile, sfile, scope)
            except V.AuditFailure as error:
                assert error.code == expected_code, (name, error.code, expected_code)
                results.append({"case": name, "status": "PASS", "detected": error.code})
            else:
                raise AssertionError(f"Corruption was accepted: {name}")

        mutation("duplicate_key_replaces_another", "cell",
                 lambda rows: rows.__setitem__(1, dict(rows[0])), "duplicate_metric_key")
        mutation("missing_stream_row", "stream", lambda rows: rows.pop(), "cell_row_count_mismatch")
        mutation("nonfinite_mean", "cell", lambda rows: rows[0].__setitem__("mean", "nan"), "non_finite_summary")
        mutation("negative_sd", "stream", lambda rows: rows[0].__setitem__("sd", "-0.1"), "negative_sd_or_mcse")
        mutation("altered_sample_size_metadata", "stream",
                 lambda rows: rows[0].__setitem__("base_sample_size", "999"), "grid_factor_mismatch")
        mutation("wrong_replication_count", "stream",
                 lambda rows: rows[0].__setitem__("n_defined", "999"), "count_or_undefined_mismatch")
        mutation("unknown_metric_replaces_expected", "cell",
                 lambda rows: rows[0].__setitem__("metric_name", "fabricated"), "metric_identity_inventory_mismatch")
        mutation("incomplete_data_cannot_pass_full_scope", "cell", lambda rows: None, "cell_order_or_identity_mismatch", "full")
        def shifted_mean(rows):
            row = next(r for r in rows if r["stream_id"] == "pooled" and float(r["maximum"]) - float(r["minimum"]) > .1
                       and float(r["minimum"]) + .01 < float(r["mean"]) < float(r["maximum"]) - .01)
            row["mean"] = str(float(row["mean"]) + .001)
        mutation("plausible_but_inconsistent_pooled_mean", "cell", shifted_mean, "pooled_stream_reconciliation_failure")
        mutation("incorrect_mcse", "stream",
                 lambda rows: rows[0].__setitem__("mcse", "0.01"), "mcse_sd_count_inconsistency")
        mutation("repeated_cell_block", "cell", lambda rows: rows.extend(dict(r) for r in cell_rows), "too_many_rows_in_cell")
        if args.full_size_synthetic:
            grid, _ = V.load_contract(root)
            synthetic_dir = temporary / "SYNTHETIC_IO_ONLY_NOT_EXPERIMENT"
            synthetic_dir.mkdir()
            full_c, full_s = synthetic_dir / "CELL_METRIC_SUMMARY.csv", synthetic_dir / "STREAM_METRIC_SUMMARY.csv"
            started = time.perf_counter()
            for destination, template in ((full_c, cell_rows), (full_s, stream_rows)):
                with destination.open("w", encoding="utf-8-sig", newline="") as handle:
                    writer = csv.DictWriter(handle, fieldnames=V.COLUMNS)
                    writer.writeheader()
                    for cell in grid:
                        metadata = {k: cell[k] for k in V.FACTORS + ("cell_id",)}
                        writer.writerows({**r, **metadata} for r in template)
            writing_seconds = time.perf_counter() - started
            resource_script = temporary / "measure_full_fixture.py"
            resource_script.write_text(
                "import sys,importlib.util,json,resource\n"
                "spec=importlib.util.spec_from_file_location('v',sys.argv[1]);v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)\n"
                "r=v.audit(sys.argv[2],sys.argv[3],sys.argv[4],'full')\n"
                "r['peak_rss_kib']=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss\n"
                "print(json.dumps(r))\n", encoding="utf-8")
            command = [sys.executable, "-B", str(resource_script), str(HERE / "validate_full_outputs_r3.py"),
                       str(root), str(full_c), str(full_s)]
            completed = subprocess.run(command, capture_output=True, text=True, check=True)
            large = json.loads(completed.stdout)
            assert large["status"] == "PASS" and large["cells_checked"] == 270
            assert large["cell_rows_checked"] == 1076760 and large["stream_rows_checked"] == 1708560
            assert not any(r["historical_byte_identity"] for r in large["file_hash_comparisons"])
            results.append({"case": "full_size_synthetic_io_fixture", "status": "PASS",
                            "simulation_executed": False, "scientific_evidence": False,
                            "cells_relabelled_for_structure_only": 270,
                            "rows_processed": 2785320,
                            "bytes_processed": full_c.stat().st_size + full_s.stat().st_size,
                            "fixture_writing_seconds": writing_seconds,
                            "validation_seconds": large["elapsed_seconds"],
                            "peak_rss_kib_linux": large["peak_rss_kib"],
                            "historical_fingerprints_match": False,
                            "fixture_disposition": "TemporaryDirectory deleted after this test.",
                            "explanation": "Repeats the one existing reference's summary values under frozen grid metadata. It does not reproduce the other cells' scientific outcomes."})
    assert source_hashes_before == {p.name: V.digest(p) for p in (cp, sp)}
    output = {"status": "PASS", "tests_passed": len(results), "tests": results,
              "source_reference_files_unchanged": True, "simulator_called": False,
              "new_monte_carlo_replications": 0, "native_platform": sys.platform,
              "python": sys.version, "validator_sha256": V.digest(HERE / "validate_full_outputs_r3.py"),
              "test_script_sha256": V.digest(Path(__file__))}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(output, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(output, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
