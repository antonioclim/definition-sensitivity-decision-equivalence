TASM 269811381 — PREGĂTIRE COMPUTAȚIONALĂ R3
11 noiembrie 2026

SCOP ȘI STARE

Acesta este kitul de verificare independentă pregătit după versiunea TASM R2.
Numele R3 desemnează revizia curentă. În documentele vechi, EINT-R3 desemnează
etapa istorică a rulării integrale; aceste două utilizări nu sunt aceeași
înregistrare de execuție.

În faza curentă NU a fost lansată simularea completă și NU a fost executată
nicio replicare Monte Carlo nouă. Au fost inspectate protocolul, motorul,
contractul de ieșire și rapoartele istorice. Preflight-ul original a trecut
pentru opt workers în mediul disponibil, cu zero replicări.

Scripturile noi sunt separate de directoarele istorice ale S2 și nu modifică motorul ori protocolul.
Ele acceptă pachetul S2 final R2 ori extensia sa documentată R3.
Inventarul, amprentele și dimensiunile sunt verificate din manifestul curent,
fără număr fix de fișiere. Cele 46 de fișiere istorice protejate sunt ancorate
separat în R2_PROTECTED_SOURCE_HASHES.json, al cărui SHA este fixat în script.
Astfel, adăugarea documentației R3 nu permite schimbarea motorului, protocolului
sau rezultatelor istorice protejate.

FIȘIERE

validate_full_outputs_r3.py
  Verificator nou, independent de algoritmii de agregare ai simulatorului.
  Folosește numai biblioteca standard Python și nu lansează simulări.
  Domeniul implicit este full: toate cele 270 de celule, în ordinea
  registrului înghețat. Domeniul reference acceptă numai cell_0051.

run_full_verified_r3.py
  Orchestrator cu mod implicit PREFLIGHT_ONLY, fără simulare.
  Flagul explicit --authorise-full este necesar pentru execuția integrală.
  Dacă este folosit cu autorizarea proiectului, cheamă runnerul istoric
  nemodificat, păstrează jurnalul, arată progresul aproximativ din fișiere
  și aplică verificatorul independent după închiderea procesului.
  Un proces încheiat normal nu este prezentat automat drept validare.

test_validator_r3.py
  Referința existentă și cazuri de corupere. Mod implicit mic, fără simulări.
  Opțiunea --full-size-synthetic verifică citirea la dimensiunea integrală,
  folosind doar rezumate repetate și metadate de grilă. Opțiunea mare măsoară
  RSS prin modulul resource pe Linux; nu este oferită ca test nativ Windows.
  Fixture-ul mare este temporar și nu constituie rezultate științifice.

test_launcher_r3.py
  Testează numai preflight și refuzurile. Nu furnizează niciodată flagul
  --authorise-full. Verifică și acceptarea unui manifest extins, precum și
  refuzul unui fișier istoric modificat chiar dacă manifestele sunt actualizate.

VERIFICĂRI EFECTUATE

1. Referința existentă: PASS, 3.988 + 6.328 rânduri, 1.582 chei stocastice.
2. Treisprezece probe ale validatorului: PASS. Includ intrarea validă,
   unsprezece coruperi/limite și fixture-ul sintetic de I/O complet.
3. Fixture-ul mare: 2.785.320 rânduri, 799.744.240 octeți, 51,92 secunde de
   validare, vârf RSS 94.636 KiB (~92,4 MiB), în mediul Linux observat.
   Nu s-au generat rezultate pentru celelalte celule; s-a verificat doar
   comportamentul citirii și al validării structurale la această dimensiune.
4. Șapte probe ale orchestratorului: două preflight-uri valide (manifest
   inițial și extins) și cinci refuzuri (director nevid, director în surse,
   zero workers, workers peste CPU vizibile și fișier istoric modificat).
5. Mod implicit orchestrator: PREFLIGHT_ONLY; inventarul complet curent și
   cele 46 fișiere istorice protejate verificate; zero replicări. Acceptarea
   unui manifest extins este verificată pe o copie temporară.

Referințele și S2 au rămas nemodificate. Ramura de lansare full a
orchestratorului nu a fost executată în această fază. Întreruperea și
terminarea arborelui de procese nu au fost testate nativ Windows.

CE VERIFICĂ VALIDATORUL

- SHA protocol, SHA registru și SHA celor două referințe care fixează
  contractul identităților metrice;
- coloane exacte, celule așteptate, factori ai grilei, chei duplicate/lipsă;
- 2.406 rânduri deterministe și 1.582 pooled pentru fiecare celulă;
- patru fluxuri a câte 1.582 metrici, n=1.000 pe flux;
- numărători n_defined/n_undefined, valori finite, SD/MCSE nenegative,
  compatibilitatea mediei cu intervalul și MCSE=SD/sqrt(n);
- reconstrucția independentă a mediei, SD, MCSE, minimului și maximului pooled;
- un diagnostic explicit al momentelor între cele patru fluxuri;
- amprentele istorice, raportate separat de acordul structural/numeric.

Memoria păstrează câte un bloc de celulă din fiecare CSV și vectori compacți
de diagnostice. Fișierele complete nu sunt încărcate într-un DataFrame.
Contractul metric este ancorat în fișierele de referință identificate prin
SHA. În grila înghețată, toate celulele au aceeași structură de metrici.

FORMULE ȘI TOLERANȚE

Cu patru fluxuri, fiecare cu n=1.000, N=4.000:

  media pooled = suma(n_j * media_j) / N
  SD pooled^2  = [suma((n_j-1)*SD_j^2)
                  + suma(n_j*(media_j-media pooled)^2)] / (N-1)
  MCSE pooled  = SD pooled / sqrt(N)
  minimum      = minimul celor patru minime
  maximum      = maximul celor patru maxime

Toleranțe absolute de reconciliere: media 1e-12, SD 1e-10, MCSE 1e-12;
minimul și maximul trebuie să coincidă exact. Toleranța SD permite eroarea
de rotunjire a rezumatelor; nu schimbă datele sau simulatorul. Pe referință,
maximele observate au fost 3,786e-14 (media), 3,245e-12 (SD),
5,130e-14 (MCSE) și zero (min/max).

Diagnosticul nou este nesplitat și nerank-normalizat:

  W = media celor patru varianțe din fluxuri
  B = n * suma((media_j-media generală)^2) / (4-1)
  R = sqrt( ((n-1)*W/n + B/n) / W )

Dacă W=B=0, se raportează R=1. Dacă W=0 și B>0, se raportează eșec.
Pragurile 1,01/1,05/1,10 sunt raportate explicit; ele nu sunt o demonstrație
a validității externe. Pe referință, maximul este 1,0012439323 și nu există
depășiri ale pragului 1,01.

Acest R nu este diagnostic rank-normalised split R-hat și nu estimează ESS.
Rezumatele marginale nu permit reconstituirea autocorelațiilor, cuantilelor
replicărilor sau rezultatelor comune la nivel de replicare. Formula exactă
a implementării istorice z_span/drift nu a fost recuperată; nu este pretinsă
o replicare a acesteia. Noul script NU este validatorul istoric recuperat.

COMENZI WINDOWS 11 / POWERSHELL 5.1

Editați calea S2 pentru locul real al S2 R3 extras. Kitul este în directorul
08_R3_VERIFICATION\computation. Dacă folosiți kitul separat cu S2 R2, setați
explicit $Kit la directorul scripturilor separate.
Venv este în afara S2. Nu este necesară activarea, schimbarea ExecutionPolicy
sau rularea ca Administrator. Comenzile de mai jos nu pornesc full.

    $ErrorActionPreference = 'Stop'
    $S2 = 'C:\Research\TASM R3\S2\Supplementary_Material_S2_Code_and_Aggregate_Results'
    $Kit = Join-Path $S2 '08_R3_VERIFICATION\computation'
    if (-not (Test-Path -LiteralPath (Join-Path $Kit 'validate_full_outputs_r3.py') -PathType Leaf)) { throw 'Calea $Kit nu conține scripturile R3.' }
    if (-not (Test-Path -LiteralPath (Join-Path $S2 'MANIFEST.csv') -PathType Leaf)) { throw 'Calea $S2 nu este rădăcina S2 extras.' }
    $Venv = Join-Path $env:LOCALAPPDATA 'TASM_R3_venv'
    py -3.12 -m venv $Venv
    if ($LASTEXITCODE -ne 0) { throw 'Nu s-a creat mediul Python 3.12.' }
    $Python = Join-Path $Venv 'Scripts\python.exe'
    & $Python -m pip install -r (Join-Path $S2 '03_EXECUTABLE\requirements.txt')
    if ($LASTEXITCODE -ne 0) { throw 'Instalarea dependențelor a eșuat.' }
    $Stamp = Get-Date -Format 'yyyyMMdd_HHmmss_fff'
    $Reports = Join-Path $env:USERPROFILE ('TASM_R3_Reports\' + $Stamp)
    New-Item -ItemType Directory -Path $Reports -Force | Out-Null
    $Ref = Join-Path $S2 '06_R2_REPRODUCTION\REFERENCE_AUDIT_20261111'
    $Validator = Join-Path $Kit 'validate_full_outputs_r3.py'
    & $Python -B $Validator --s2-root $S2 --cell-csv (Join-Path $Ref 'REFERENCE_RERUN_CELL_METRIC_SUMMARY.csv') --stream-csv (Join-Path $Ref 'REFERENCE_RERUN_STREAM_METRIC_SUMMARY.csv') --scope reference --output (Join-Path $Reports 'REFERENCE_VALIDATION.json')
    if ($LASTEXITCODE -ne 0) { throw 'Validarea referinței a eșuat.' }
    & $Python -B (Join-Path $Kit 'test_validator_r3.py') --s2-root $S2 --output (Join-Path $Reports 'VALIDATOR_TESTS.json')
    if ($LASTEXITCODE -ne 0) { throw 'Probele validatorului au eșuat.' }
    & $Python -B (Join-Path $Kit 'test_launcher_r3.py') --s2-root $S2 --output (Join-Path $Reports 'LAUNCHER_TESTS.json')
    if ($LASTEXITCODE -ne 0) { throw 'Probele orchestratorului au eșuat.' }
    $Run = Join-Path $env:USERPROFILE ('TASM_R3_Runs\full_' + $Stamp)
    & $Python -B (Join-Path $Kit 'run_full_verified_r3.py') --s2-root $S2 --output-dir $Run --workers 4
    if ($LASTEXITCODE -ne 0) { throw 'Preflight-ul a eșuat.' }

ULTIMA COMANDĂ ESTE NUMAI PREFLIGHT. Directorul $Run rămâne gol.

LANSARE INTEGRALĂ NUMAI DUPĂ AUTORIZAREA EXPLICITĂ A ACESTEI OPERAȚII

Comanda următoare este separată intenționat; nu a fost executată în R3.
Păstrează exact protocolul și motorul. Refolosește variabilele de mai sus.

    & $Python -B (Join-Path $Kit 'run_full_verified_r3.py') --s2-root $S2 --output-dir $Run --workers 4 --authorise-full
    if ($LASTEXITCODE -ne 0) { throw 'Rularea integrală sau verificarea ei a eșuat; consultați directorul de audit.' }

Patru workers reprezintă alegerea conservatoare din ghid; preflight verifică
numărul față de CPU vizibile. Mediul din această conversație a acceptat opt,
dar acest lucru nu dovedește resursele calculatorului utilizatorului.

Nu există reluare automată a unui run întrerupt. Fișierele parțiale sunt
păstrate pentru diagnostic, iar un director nevid este refuzat. O nouă
execuție necesită un director nou, pentru a evita amestecarea rezultatelor.

VALIDAREA UNOR FIȘIERE FULL RECUPERATE, FĂRĂ SIMULARE

    $Recovered = 'F:\TASM_Recovered_Full'
    & $Python -B $Validator --s2-root $S2 --cell-csv (Join-Path $Recovered 'CELL_METRIC_SUMMARY.csv') --stream-csv (Join-Path $Recovered 'STREAM_METRIC_SUMMARY.csv') --scope full --output (Join-Path $Reports 'RECOVERED_FULL_VALIDATION.json')
    if ($LASTEXITCODE -ne 0) { throw 'Fișierele recuperate nu au trecut verificarea integrală.' }

Dacă există și EXECUTION_SUMMARY.json original, adăugați:
    --execution-summary (Join-Path $Recovered 'EXECUTION_SUMMARY.json')

COMANDĂ BASH PENTRU VALIDATORUL FĂRĂ SIMULARE

    python3 -B validate_full_outputs_r3.py \
      --s2-root '/cale/Supplementary_Material_S2_Code_and_Aggregate_Results' \
      --cell-csv '/cale/CELL_METRIC_SUMMARY.csv' \
      --stream-csv '/cale/STREAM_METRIC_SUMMARY.csv' \
      --scope full \
      --output '/cale-noua/INDEPENDENT_FULL_VALIDATION.json'

FEZABILITATE ȘI LIMITĂ TEMPORALĂ

Resurse observate: 9 CPU vizibile, afinitate 0–8, ~9,73 GiB RAM total,
~8,78 GiB disponibili și ~58,22 GiB disc liber. Nu este expusă cota cgroup;
numărul CPU vizibile nu garantează debitul susținut al tuturor workerilor.
Cele două CSV-uri complete istorice însumează 795.579.497 octeți.

Referința R2 a necesitat 50,66 s pentru 4.000 replicări. Extrapolarea simplă
la 270 celule este ~3,8 ore serial, ~57 minute ideal la 4 workers și ~28,5
minute ideal la 8 workers. Acestea nu sunt predicții măsurate: costul pe
celulă, contencția și overhead-ul pot modifica timpul. Grila are 96 celule
cu 8 unități și 174 cu 16; numărătorile sunt simulate multinomial.

Runnerul istoric transmite rezultatele în ordinea celulelor și scrie
incremental, dar ProcessPoolExecutor poate reține rezultate terminate
înaintea unei celule precedente mai lente. Rularea lungă nu a fost testată
în această fază și nu se certifică un maxim măsurat al memoriei ei.

EVIDENȚE

ORIGINAL_FULL_PREFLIGHT_R3.json
ORIGINAL_FULL_PREFLIGHT_EXECUTION.json
RESOURCES_R3.json
GRID_RESOURCE_PROFILE_R3.json
REFERENCE_VALIDATION_R3.json
VALIDATOR_TESTS_R3.json
LAUNCHER_GUARD_TESTS_R3.json
COMPUTATION_CLOSURE_R3.json

Toate măsurătorile executate aici sunt Linux. Ghidul PowerShell este pregătit
pentru sintaxa 5.1, dar nu a fost executat nativ pe Windows.
