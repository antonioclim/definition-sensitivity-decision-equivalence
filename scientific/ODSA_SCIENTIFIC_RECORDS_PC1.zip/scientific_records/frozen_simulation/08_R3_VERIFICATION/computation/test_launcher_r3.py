"""Test preflight-only and rejection paths. Never supplies --authorise-full."""
import argparse
import csv
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

HERE = Path(__file__).resolve().parent


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def manifests(root):
    files = sorted(p for p in root.rglob("*") if p.is_file()
                   and p.relative_to(root).as_posix() not in {"MANIFEST.csv", "SHA256SUMS.txt"}
                   and not any(x in {"__pycache__", ".pytest_cache"} for x in p.parts))
    with (root / "MANIFEST.csv").open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=("path", "bytes", "sha256"))
        writer.writeheader()
        writer.writerows({"path": p.relative_to(root).as_posix(), "bytes": p.stat().st_size, "sha256": digest(p)} for p in files)
    with (root / "SHA256SUMS.txt").open("w", encoding="utf-8", newline="\n") as handle:
        for p in sorted(files + [root / "MANIFEST.csv"]):
            handle.write(digest(p) + "  " + p.relative_to(root).as_posix() + "\n")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--s2-root", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    root = args.s2_root.resolve()
    engine = root / "03_EXECUTABLE/odsa_econ/engine.py"
    before = digest(engine)
    results = []
    with tempfile.TemporaryDirectory(prefix="TASM_R3_launcher_tests_") as directory:
        tmp = Path(directory)
        def call(name, source, dest, workers=1, expected_exit=0, contains=None):
            command = [sys.executable, "-B", str(HERE / "run_full_verified_r3.py"),
                       "--s2-root", str(source), "--output-dir", str(dest), "--workers", str(workers)]
            assert "--authorise-full" not in command
            result = subprocess.run(command, capture_output=True, text=True)
            assert result.returncode == expected_exit, (name, result.returncode, result.stderr, result.stdout)
            entry = {"case": name, "status": "PASS", "exit_code": result.returncode}
            if expected_exit == 0:
                value = json.loads(result.stdout)
                assert value["status"] == "PREFLIGHT_ONLY" and value["full_execution_performed"] is False
                assert not list(dest.iterdir())
                entry.update(current_payload_files_checked=value["current_payload_files_checked"],
                             protected_historical_files_checked=value["protected_historical_files_checked"])
            else:
                assert contains in result.stderr
                entry["detected"] = result.stderr.splitlines()[-1]
            results.append(entry)
        call("baseline_preflight_without_full_flag", root, tmp / "baseline_output")
        nonempty = tmp / "nonempty"
        nonempty.mkdir()
        (nonempty / "keep.txt").write_text("unchanged")
        call("nonempty_output", root, nonempty, expected_exit=2, contains="empty directory")
        call("source_output", root, root / "forbidden_test_destination", expected_exit=2, contains="separate from S2")
        call("zero_workers", root, tmp / "zero", workers=0, expected_exit=2, contains="workers must be")
        call("too_many_workers", root, tmp / "many", workers=9999, expected_exit=2, contains="workers must be")
        assert (nonempty / "keep.txt").read_text() == "unchanged"
        assert not (root / "forbidden_test_destination").exists()
        extended = tmp / "S2 extended manifest with spaces"
        shutil.copytree(root, extended, ignore=shutil.ignore_patterns("__pycache__", ".pytest_cache"))
        extra = extended / "08_R3_VERIFICATION/TEST_FIXTURE_ONLY.txt"
        extra.parent.mkdir(parents=True, exist_ok=True)
        extra.write_text("Temporary manifest-extension test, not a scientific result.\n", encoding="utf-8")
        readme = extended / "README_FIRST.md"
        readme.write_text(readme.read_text(encoding="utf-8") + "\nTemporary R3 manifest extension test.\n", encoding="utf-8")
        manifests(extended)
        call("extended_manifest_accepted_without_fixed_payload_count", extended, tmp / "extended_output")
        protected = extended / "03_EXECUTABLE/odsa_econ/diagnostics.py"
        protected.write_bytes(protected.read_bytes() + b"\n# temporary mutation\n")
        manifests(extended)
        call("protected_source_change_rejected_even_with_updated_manifests", extended, tmp / "changed_output",
             expected_exit=1, contains="Protected historical source differs")
    assert digest(engine) == before
    output = {"status": "PASS", "tests_passed": len(results), "tests": results,
              "full_execution_performed": False, "authorise_full_flag_never_supplied": True,
              "original_engine_unchanged": True, "native_platform": sys.platform,
              "python": sys.version, "launcher_sha256": digest(HERE / "run_full_verified_r3.py"),
              "test_script_sha256": digest(Path(__file__))}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(output, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(output, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
