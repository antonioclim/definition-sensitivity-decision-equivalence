//DIRECTORIES

set more off
clear *
set maxvar 12000

 
***************************************************************************
******************************* FIGURES A12-A16 ***************************
***************************************************************************

* output location
cd "${path_import}\Figures_A12_A16"

local files : dir "$data" files "*.csv"
foreach file in `files'{
	import delimited "`file'", clear
	egen max_experts = max(experts)
	gen normal_rank = 1 + 4*((experts-1)/(max_experts-1))
	local cleanfilename = subinstr("`file'", ".csv", "", .)
	local titletext : display proper("`cleanfilename'")
	local point_size 4
	local textsize small
	local tilt 0
	twoway (scatter functionality normal_rank, mlabel(businessfunction ) mlabsize(`textsize') msize(`point_size') mlabangle(`tilt') mcolor(red%30) mlabcolor(blue) msymbol(x)) (scatter integration normal_rank, mlabel(businessfunction) mlabsize(`textsize') msize(`point_size')  mlabangle(`tilt') mcolor(blue%30) mlabcolor(red) msymbol(triangle)) (scatter automation normal_rank, mlabel(businessfunction)  mlabangle(`tilt') mlabsize(`textsize') msize(`point_size') mcolor(green%20) mlabcolor(green) msymbol(square)) (function y=x , range(0 5) lcolor(black) lpattern(dash) lwidth(medium)) , ytitle("ChatGPT rankings") xtitle("Expert rankings") title("`titletext'" ,size(*0.9)) graphregion(color(white) margin(l=2 r=30)) plotregion(fcolor(white)) legend(position(4) margin(l=2 r=20) order(1 2 3)) xsize(9) 

	graph export "$path_output/2_graphs/`cleanfilename'.pdf",replace 
}

//note("Note: The graph compares the experts' rankings of the business function with ChatGPT's rankings across the dimensions of functionality, integration" "and automation. If a given business function has fewer than 3 markings, then there is overlap of the function across different definitions." )


***************************************************************************
******************************* FIGURE C3 *********************************
***************************************************************************
* output location
cd "${path_import}

u "${path_import}/FAT0_firm_level.dta", clear
drop if max_g_most ==.

preserve
	collapse (mean) max_g_most_gbf if num_g1>=2 [aw=base_wt]
	tempfile temp1
	save `temp1'
restore

preserve
	collapse (mean) max_g_most_ssbf if num_g1>=2 [aw=base_wt], by(a5a)
	tempfile temp2
	save `temp2'
restore

u `temp1', clear
append using `temp2'
drop if a5a == 102  // Other services excluded


// new x-axis
gen rank = 1 if a5a == .
replace rank = 2  if a5a == 1  // Agriculture
replace rank = 3  if a5a == 2  // Livestock
replace rank = 4  if a5a == 3  // Food processing
replace rank = 6  if a5a == 4  // Apparel
replace rank = 7  if a5a == 5  // Motor Vehicles
replace rank = 8  if a5a == 6  // Pharmaceuticals
replace rank = 10 if a5a == 7  // Wholesale or retail
replace rank = 11 if a5a == 8  // Financial services
replace rank = 12 if a5a == 9  // Land transport
replace rank = 13 if a5a == 10 // Health services
replace rank = 5  if a5a == 11 // Leather
replace rank = 9  if a5a == 101 // Other mfg

#delimit ;
	label define rank_label 
	1 "GBF"
	2 "Agriculture"
	3 "Livestock"
	4 "Food Processing"
	5 "Leather"
	6 "Apparel"
	7 "Motor vehicles"
	8 "Pharmaceuticals"
	9 "Other Manufact."
	10 "Wholesale or retail"
	11 "Financial services"
	12 "Land transport"
	13 "Health services", replace
;
#delimit cr
label values rank rank_label
sort rank

gen max_g_most = max_g_most_ssbf
replace max_g_most = max_g_most_gbf if rank ==1

* Create bar chart with reference line
graph bar (asis) max_g_most, over(rank, label(angle(45) labsize(vsmall))) ///
    ytitle("max_g_most", size(medium)) ///
    ylabel(0(0.25)0.8, angle(0)) ///
    yline(0.5, lcolor(black) lpattern(solid) lwidth(medium)) ///
    graphregion(color(white)) ///
    plotregion(margin(small)) ///
    bar(1, fcolor(midblue) lcolor(midblue) lwidth(thin)) ///
    name(bar_chart, replace)

graph export "${path_output}\2_graphs\Figure_C3.png", replace


***************************************************************************
******************************* FIGURE C4 *********************************
***************************************************************************


u "${path_import}/FAT0_firm_level.dta", clear

sum max_g_most
collapse (sd) max_g_most  [aw=base_wt], by(countrycode)


// IMPORT gdp DATA
preserve
	import excel "${path_import}\country_stats_2080.xlsx", sheet("Sheet2") cellrange(A1:C16) firstrow clear
	tempfile gdp
	save `gdp'
restore
merge 1:1 countrycode using `gdp', keep(3) nogen


scatter max_g_most  lgdp if max_g_most >= 0, legend(off) title(" ") ///
 xtitle("Log GDP per capita") ytitle("MAX-MOST GAP") mlabel(country) /// 
 mlabcolor(blue) msymbol(i) mlabsize(small) /// 
 msymbol(0h) mcolor(white) mlcolor(blue) || ///
 lfit  max_g_most lgdp, lcolor(blue) lpattern(dash)
 graph export "${path_output}\2_graphs\Figure_C4.png", replace
 
 
 