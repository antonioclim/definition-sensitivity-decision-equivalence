//DIRECTORIES

set more off
clear *
set maxvar 12000

/* The following line should contain
   the complete path and name of the raw data file.
   On a PC, use backslashes in paths as in C:\  */   


* DATA PATH & NAME
	/* The following line should contain the path to your do files */
	global path_dofile "C:\Users\malecm\Documents\Technology Adoption Survey\QJE_replication_2026\2_codes"
	/* The following line should contain the path to your inpuit '.xlsx' file */
	global path_import "C:\Users\malecm\Documents\Technology Adoption Survey\QJE_replication_2026\1_data"
	/* The following line should contain the path to your output files */
	global path_output "C:\Users\malecm\Documents\Technology Adoption Survey\QJE_replication_2026\3_output"

* output location
cd "${path_import}"


// Step 0: Save the financial variables from the Poland data

use "${path_import}/TAS_naukowiec.dta", clear
gen firmid = id + 900000
order firmid id
* Variables restricted or shared as an interval
keep firmid id a3b a3c a4e a5a e1* e2* e3* e4* e5* e6* e7* e8* e9* a6* s1b* s4a s5 s6 s7*
replace e1 = e1_gus if e1 == -9 | e1 ==.
replace e2 = e2_gus if e2 == -9 | e2 ==.
replace e6  = e6_gus  if e6 == -9 | e6 ==.
replace e6b = e6b_gus if e6b == -9 | e6b ==.
replace e7a = e7a_gus if e7a == -9 | e7a ==.
replace e7c = e7c_gus if e7c == -9 | e7c ==.
replace e7d = e7d_gus if e7d == -9 | e7d ==.
replace e8a = e8a_gus if e8a == -9 | e8a ==.
replace e8b = e8b_gus if e8b == -9 | e8b ==.
replace e9rd = e9rd_gus if e9rd == -9 | e9rd ==.

gen e6a = e6
replace e5d = e5d_1/e1a * 100 if e5d == .

drop *gus

replace a5a = 101 if a5a == 13 | a5a == 14 | a5a == 15
replace a5a = 102 if a5a == 12

save "${path_import}/TAS_naukowiec2.dta", replace


// Step 1: Merge Polish financial data
// MERGE WITH POLISH FINANCIAL DATA

* output location
cd "${path_import}"

// use the raw data to construct the variables needed
use "${path_import}\input\FAT0_raw_data_qje.dta", clear
merge m:1 firmid using "${path_import}/TAS_naukowiec2.dta", update replace
drop _merge
save "${path_import}\FAT0_raw_data_qje.dta", replace





