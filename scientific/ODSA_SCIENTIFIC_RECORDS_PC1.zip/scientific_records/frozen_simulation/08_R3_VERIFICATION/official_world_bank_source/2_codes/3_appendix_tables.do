//DIRECTORIES

set more off
clear *
set maxvar 12000


* output location
cd "${path_import}"


***************************************************************************
******************************** TABLE A23 **********************************
***************************************************************************

//////Table A23 prepare - Universe of establishments in the sample, by sector and size groups
// load datasets
use "${path_import}/FAT0_reshaped_firm_busfn_updated_new.dta", clear

collapse a5a base_wt, by(firmid country size_group)

gen sector = 1 if a5a == 1 | a5a == 2
replace sector = 2 if a5a == 3 | a5a == 4 | a5a == 5 | a5a == 6 | a5a == 11 | a5a == 101
replace sector = 3 if a5a == 102 | a5a == 7 | a5a == 8 | a5a == 9 | a5a == 10 	

tabulate sector, generate(sector_)
	
tabulate size_group, generate(size)

foreach var of varlist sector_1 sector_2 sector_3 size1 size2 size3 {
	replace `var' = base_wt*`var'
}

gen total_firms = base_wt

collapse (sum) total_firms sector_1 sector_2 sector_3 size1 size2 size3, by(country)

//drop size_group

foreach var of varlist total_firms sector_1 sector_2 sector_3 size1 size2 size3 {
	replace `var' = . if `var' == 0
}

gen overall = 1
save "${path_import}/table_a23.dta", replace

collapse (sum) total_firms sector* size*
gen country = "Total" 
gen overall = 2

append using "${path_import}/table_a23.dta"
sort overall country
drop overall
order country total_firms sector* size*

format total_firms sector_1 sector_2 sector_3 size1 size2 size3 %15.0fc 
global table2_notes "This table displays the weighted distribution of all establishments across countries by sector (Agriculture, Manufacturing, and Services) and firm size groups: Small (5-19 workers), Medium (20-99 workers), and Large (100+ workers).* Brazil refers to the states of Ceará, Paraná, and São Paulo. ** States of Tamil Nadu, Uttar Pradesh, Gujarat, and Maharashtra in India. The survey does not cover agriculture or services in Bangladesh, nor agriculture in Cambodia. In India, only the states of Gujarat and Maharashtra have agriculture included in the survey. \autoref{tab:country_dist} provides the distribution of the number of firms sampled in each country (unweighted), by sector and firm size group."

foreach var of varlist total_firms sector* size1 size2 size3 {
    gen n`var' = string(`var',"%15.0fc") 
	drop `var'
	rename n`var' `var'
	replace `var' = "" if `var' == "."
	replace `var' = "\textbf{" + `var' + "}" if country == "Total"
}
replace country = "\textbf{Total}" if country == "Total"
replace country = "India**" if country == "India" 
replace country = "Brazil*" if country == "Brazil" 


label var total_firms "\textbf{Total}"
label var sector_1 "\textbf{Agri.}"
label var sector_2 "\textbf{Manu.}"
label var sector_3 "\textbf{Serv.}"
label var size1 "\textbf{Small}"
label var size2 "\textbf{Medium}"
label var size3 "\textbf{Large}"


//enter table 1 directly in the file by copying the texfile 
texsave using "${path_output}/table_A22.tex", hlines(15 16) replace title(Number of establishments in the universe, by sector and size groups) varlabels footnote("${table2_notes}") valuelabels nofix label("tab:country_dist")
	

***************************************************************************
******************************* TABLE A.25 ********************************
***************************************************************************

/// Vietnam
u "${path_import}\replication_tableC25-C27_vietnam.dta", clear
reg emp i.fat_data i.region i.ind_group i.emp_group if progress_fat==2 | progress_fat==3 
estimates store vietnam

/// Brazil
u "${path_import}\replication_tableC25-C27_brazil.dta", replace
reg rais_emp i.fat_data i.ind_group i.emp_group if rais_sampling==3
estimates store brazil

/// Senegal
u "${path_import}\replication_tableC25-C27_senegal.dta", clear
reg emp i.fat_data i.region i.ind_group i.emp_group i.formality if ansd_progress_merge==3 	// sample_frame==1
estimates store senegal


/// Create tex file
* Open file for writing
file open myfile using "${path_output}\1_latex_tables\table_A25.tex", write replace

* Write LaTeX header
file write myfile "\begin{table}[htbp]\centering" _n
file write myfile "\caption{Comparison of establishment size between respondents vs non-respondents}" _n
file write myfile "\label{tab:tableA25}" _n
file write myfile "\begin{tabular}{lccc}" _n
file write myfile "\toprule" _n
file write myfile "VARIABLES & Brazil & Vietnam & Senegal \\" _n
file write myfile "\midrule" _n

* Extract coefficients and standard errors
estimates restore brazil
local b_brazil = _b[1.fat_data]
local se_brazil = _se[1.fat_data]
local n_brazil = e(N)
local r2_brazil = e(r2)

estimates restore vietnam  
local b_vietnam = _b[1.fat_data]
local se_vietnam = _se[1.fat_data]
local n_vietnam = e(N)
local r2_vietnam = e(r2)

estimates restore senegal
local b_senegal = _b[1.fat_data]
local se_senegal = _se[1.fat_data]
local n_senegal = e(N)
local r2_senegal = e(r2)

* Write coefficient row
file write myfile "Respondents (FAT) & " ///
    %6.2f (`b_brazil') " & " ///
    %6.2f (`b_vietnam') " & " ///
    %6.2f (`b_senegal') " \\" _n

* Write standard error row (in parentheses)
file write myfile " & " ///
    "(" %6.2f (`se_brazil') ") & " ///
    "(" %6.2f (`se_vietnam') ") & " ///
    "(" %6.2f (`se_senegal') ") \\" _n

* Add blank line
file write myfile " & & & \\" _n

* Write observations
file write myfile "Observations & " ///
    %9.0fc (`n_brazil') " & " ///
    %9.0fc (`n_vietnam') " & " ///
    %9.0fc (`n_senegal') " \\" _n

* Write R-squared
file write myfile "R-squared & " ///
    %5.3f (`r2_brazil') " & " ///
    %5.3f (`r2_vietnam') " & " ///
    %5.3f (`r2_senegal') " \\" _n

* Write controls section
file write myfile "Controls: & & & \\" _n
file write myfile "\ \ \ Sector FE & Y & Y & Y \\" _n
file write myfile "\ \ \ Size-group FE & Y & Y & Y \\" _n  
file write myfile "\ \ \ Region FE & Y & Y & Y \\" _n

* Write footer
file write myfile "\bottomrule" _n
file write myfile "\end{tabular}" _n
file write myfile "\end{table}" _n

* Close file
file close myfile



***************************************************************************
******************************* TABLE A.26 ********************************
***************************************************************************
/// Senegal
u "${path_import}\replication_tableC25-C27_senegal.dta", clear

reg tech_int_abf_firm q4 i.region i.ind_group i.emp_group i.formality if dup_firms==0
estimates store col1

reg tech_int_abf_firm q4 i.region i.ind_group i.emp_group i.formality i.fage_group i.exporter i.mnc if dup_firms==0
estimates store col2

* Export to LaTeX
esttab col1 col2 using "${path_output}\1_latex_tables\table_A26.tex", ///
    replace ///
    b(3) se(3) ///
    star(* 0.10 ** 0.05 *** 0.01) ///
    label booktabs ///
    alignment(D{.}{.}{-1}) ///
    mtitles("Senegal" "Senegal") ///
    keep(q4) ///
    stats(N r2, fmt(0 3) labels("Observations" "\(R^2\)")) ///
    indicate("Sector FE = *.ind_group" ///
             "Size-group FE = *.emp_group" ///
             "Region FE = *.region" ///
             "Age = *.fage_group" ///
             "Exporter = *.exporter" ///
             "Foreign owned = *.mnc", ///
             labels("Y" "")) ///
    varlabels(q4 "Top quartile of attempts (4 or more)") ///
    prehead("\def\sym#1{\ifmmode^{#1}\else\(^{#1}\)\fi}" "\centering" "\begin{tabular}{l*{@M}{D{.}{.}{-1}}}" "\toprule")


***************************************************************************
******************************* TABLE A.27 ********************************
***************************************************************************

/// Vietnam
u "${path_import}\replication_tableC25-C27_vietnam.dta", clear

reg tech_int_abf_firm i.orig_sam i.region i.ind_group i.emp_group if fat_data==1
estimates store vietnam1

reg tech_int_abf_firm i.orig_sam i.region i.ind_group i.emp_group i.fage_group i.exporter i.mnc if fat_data==1
estimates store vietnam2


/// Brazil
u "${path_import}\replication_tableC25-C27_brazil.dta", clear

reg tech_int_abf_firm i.orig_sam i.ind_group i.emp_group if fat_data==1
estimates store brazil1

reg tech_int_abf_firm i.orig_sam i.ind_group i.emp_group i.fage_group i.exporter i.mnc if fat_data==1
estimates store brazil2

/// Senegal
u "${path_import}\replication_tableC25-C27_senegal.dta", clear

reg tech_int_abf_firm i.orig_sam i.region i.ind_group i.emp_group i.formality if dup_firms==0
estimates store senegal1

reg tech_int_abf_firm i.orig_sam i.region i.ind_group i.emp_group i.formality i.fage_group i.exporter i.mnc if dup_firms==0
estimates store senegal2


/// Generate tex file

* Open file for writing
file open myfile using "${path_output}\1_latex_tables\table_A27.tex", write replace

* Write LaTeX header
file write myfile "\begin{table}[htbp]\centering" _n
file write myfile "\caption{Comparison of technology sophistication between original and replacement sample}" _n
file write myfile "\label{tab:tableA27}" _n
file write myfile "\begin{tabular}{lcccccc}" _n
file write myfile "\toprule" _n
file write myfile "VARIABLES & Brazil & Brazil & Vietnam & Vietnam & Senegal & Senegal \\" _n
file write myfile "\midrule" _n

* Extract coefficients and standard errors for all models
estimates restore brazil1
local b_br1 = _b[1.orig_sam]
local se_br1 = _se[1.orig_sam]
local n_br1 = e(N)
local r2_br1 = e(r2)

estimates restore brazil2
local b_br2 = _b[1.orig_sam]
local se_br2 = _se[1.orig_sam]
local n_br2 = e(N)
local r2_br2 = e(r2)

estimates restore vietnam1
local b_vn1 = _b[1.orig_sam]
local se_vn1 = _se[1.orig_sam]
local n_vn1 = e(N)
local r2_vn1 = e(r2)

estimates restore vietnam2
local b_vn2 = _b[1.orig_sam]
local se_vn2 = _se[1.orig_sam]
local n_vn2 = e(N)
local r2_vn2 = e(r2)

estimates restore senegal1
local b_sn1 = _b[1.orig_sam]
local se_sn1 = _se[1.orig_sam]
local n_sn1 = e(N)
local r2_sn1 = e(r2)

estimates restore senegal2
local b_sn2 = _b[1.orig_sam]
local se_sn2 = _se[1.orig_sam]
local n_sn2 = e(N)
local r2_sn2 = e(r2)

* Write coefficient row
file write myfile "Original sample & " ///
    %6.3f (`b_br1') " & " ///
    %6.3f (`b_br2') " & " ///
    %6.3f (`b_vn1') " & " ///
    %6.3f (`b_vn2') " & " ///
    %6.3f (`b_sn1') " & " ///
    %6.3f (`b_sn2') " \\" _n

* Write standard error row (in parentheses)
file write myfile " & " ///
    "(" %5.3f (`se_br1') ") & " ///
    "(" %5.3f (`se_br2') ") & " ///
    "(" %5.3f (`se_vn1') ") & " ///
    "(" %5.3f (`se_vn2') ") & " ///
    "(" %5.3f (`se_sn1') ") & " ///
    "(" %5.3f (`se_sn2') ") \\" _n

* Add blank line
file write myfile "\midrule" _n

* Write observations
file write myfile "Observations & " ///
    %9.0fc (`n_br1') " & " ///
    %9.0fc (`n_br2') " & " ///
    %9.0fc (`n_vn1') " & " ///
    %9.0fc (`n_vn2') " & " ///
    %9.0fc (`n_sn1') " & " ///
    %9.0fc (`n_sn2') " \\" _n

* Write R-squared
file write myfile "R-squared & " ///
    %5.3f (`r2_br1') " & " ///
    %5.3f (`r2_br2') " & " ///
    %5.3f (`r2_vn1') " & " ///
    %5.3f (`r2_vn2') " & " ///
    %5.3f (`r2_sn1') " & " ///
    %5.3f (`r2_sn2') " \\" _n

* Write controls section
file write myfile "Controls: & & & & & & \\" _n
file write myfile "\ \ \ Sector & Y & Y & Y & Y & Y & Y \\" _n
file write myfile "\ \ \ Size group & Y & Y & Y & Y & Y & Y \\" _n  
file write myfile "\ \ \ Region & Y & Y & Y & Y & Y & Y \\" _n
file write myfile "\ \ \ Age &  & Y &  & Y &  & Y \\" _n
file write myfile "\ \ \ Exporter &  & Y &  & Y &  & Y \\" _n
file write myfile "\ \ \ Foreign owned &  & Y &  & Y &  & Y \\" _n

* Write footer
file write myfile "\bottomrule" _n
file write myfile "\end{tabular}" _n
file write myfile "\begin{tablenotes}" _n
file write myfile "\footnotesize" _n
file write myfile "\item Note: *** p<0.01, ** p<0.05, * p<0.1. Data are from the Brazil, Vietnam, and Senegal FAT surveys. " _n
file write myfile "For each country, technology sophistication (\$MOST_i\$) is regressed on a dummy for the original sampling " _n
file write myfile "list with controls for the stratification (sectors, size groups, and regions) and/or firm characteristics (age " _n
file write myfile "groups, exporter, and foreign owned). Robust standard errors in parenthesis." _n
file write myfile "\end{tablenotes}" _n
file write myfile "\end{table}" _n

* Close file
file close myfile


***************************************************************************
******************************* TABLE A.28 ********************************
***************************************************************************

u "${path_import}\replication_C28-C29.dta", clear
 
tab country
count

* Open file for writing
cap drop latexfile
file open latexfile using "${path_output}\1_latex_tables\table_A28.tex", write replace

* Write LaTeX header
file write latexfile "\begin{table}[htbp]" _n
file write latexfile "\centering" _n
file write latexfile "\caption{Analysis of Enumerator Bias Distribution}" _n
file write latexfile "\label{tab:enumerator_bias}" _n
file write latexfile "\begin{tabular}{lcccc}" _n
file write latexfile "\hline\hline" _n
file write latexfile "VARIABLES & Brazil & Vietnam & Senegal & Bangladesh \\" _n
file write latexfile "\hline" _n

* Initialize locals to store results
local ctry "Brazil Vietnam Senegal Bangladesh Ghana India Korea Kenya"

* First panel: Brazil, Vietnam, Senegal, Bangladesh
local panel1 "Brazil Vietnam Senegal Bangladesh"
local share_line1 "Share of Significantly Different Interviewers"
local num_sig_line1 "Number of Significantly Different Interviewers"
local num_int_line1 "Number of Interviewers"

foreach c of local panel1 {
    preserve 
        keep if country =="`c'"
        * region
        cap drop region
        gen region = s1c_rev
        * employment
        cap drop emp_group
        gen emp_group = s1b_rev
        * industry
        cap drop ind_group
        gen ind_group = s1a_rev
        * interviewer id
        cap drop a8_num interviewer_id
        egen a8_num = sieve(a8), keep(numeric)
        destring a8_num, gen(interviewer_id) force
        replace interviewer_id = round(interviewer_id)
  *      replace interviewer_id = 0 if interviewer_id==.
  *      replace interviewer_id = 0 if interviewer_id < 0
		if "`c'" == "Vietnam" {
            replace interviewer_id = 300 if interviewer_id > 1000000000
        }
        
        * analysis
        cap drop diff_enumer
        gen diff_enumer = 0
        reg tot_emp i.interviewer_id i.region i.ind_group i.emp_group 
        levelsof interviewer_id, local(interviewers)
        local remove "40063 42370"
        local interviewers: list interviewers - remove
        
        foreach i of local interviewers{
            local t = _b[`i'.interviewer_id]/_se[`i'.interviewer_id]
            local p = 2*ttail(e(df_r),abs(`t'))
            qui replace diff_enumer = 1 if `p' < 0.05 & interviewer_id ==`i'
        }
        
        * Count total interviewers (excluding 0)
        qui distinct interviewer_id if interviewer_id != 0
        local total_int = r(ndistinct)
        
        * Count significantly different interviewers
        qui distinct interviewer_id if diff_enumer == 1 & interviewer_id != 0
        local sig_int = r(ndistinct)
        
        * Calculate share (rounded to 2 decimals)
        local share = round(`sig_int' / `total_int', 0.01)
        
        * Store in locals
        local share_`c' = `share'
        local sig_`c' = `sig_int'
        local total_`c' = `total_int'
        
        * Display results
        disp "`c': Share = " %4.2f `share' ", Sig Different = " `sig_int' ", Total = " `total_int'
        
    restore
}

* Write first panel rows
file write latexfile "`share_line1' & `share_Brazil' & `share_Vietnam' & `share_Senegal' & `share_Bangladesh' \\" _n
file write latexfile " & & & & \\" _n
file write latexfile "`num_sig_line1' & `sig_Brazil' & `sig_Vietnam' & `sig_Senegal' & `sig_Bangladesh' \\" _n
file write latexfile "Number of Interviewers & `total_Brazil' & `total_Vietnam' & `total_Senegal' & `total_Bangladesh' \\" _n
file write latexfile "\hline" _n

* Second panel header
file write latexfile " & Ghana & India & Korea & Kenya \\" _n
file write latexfile "\hline" _n

* Second panel: Ghana, India, Korea, Kenya
local panel2 "Ghana India Korea Kenya"

foreach c of local panel2 {
    preserve 
        keep if country =="`c'"
        * region
        cap drop region
        gen region = s1c_rev
        * employment
        cap drop emp_group
        gen emp_group = s1b_rev
        * industry
        cap drop ind_group
        gen ind_group = s1a_rev
        * interviewer id
        cap drop a8_num interviewer_id
        egen a8_num = sieve(a8), keep(numeric)
		
		*Cleanup of Kenya interviewer id's
		tab a8_num if country == "Kenya"
		replace a8_num= substr(a8, 1, 2) if country== "Kenya"
		replace a8_num = "0" if (a8_num=="31" | a8_num== "48" | a8_num== "67" | a8_num== "7") & country== "Kenya"
		tab a8_num if country == "Kenya"
		drop if a8_num == "0" & country == "Kenya"
		
		
        destring a8_num, gen(interviewer_id) force
        replace interviewer_id = round(interviewer_id)

        if "`c'" == "Vietnam" {
            replace interviewer_id = 300 if interviewer_id > 1000000000
        }
        
        * analysis
        cap drop diff_enumer
        gen diff_enumer = 0
        reg tot_emp i.interviewer_id i.region i.ind_group i.emp_group 
        levelsof interviewer_id, local(interviewers)
        local remove "40063 42370"
        local interviewers: list interviewers - remove
        
        foreach i of local interviewers{
            local t = _b[`i'.interviewer_id]/_se[`i'.interviewer_id]
            local p = 2*ttail(e(df_r),abs(`t'))
            qui replace diff_enumer = 1 if `p' < 0.05 & interviewer_id ==`i'
        }
        
        * Count total interviewers (excluding 0)
        qui distinct interviewer_id if interviewer_id != 0
        local total_int = r(ndistinct)
        
        * Count significantly different interviewers
        qui distinct interviewer_id if diff_enumer == 1 & interviewer_id != 0
        local sig_int = r(ndistinct)
        
        * Calculate share (rounded to 2 decimals)
        local share = round(`sig_int' / `total_int', 0.01)
        
        * Store in locals
        local share_`c' = `share'
        local sig_`c' = `sig_int'
        local total_`c' = `total_int'
        
        * Display results
        disp "`c': Share = " %4.2f `share' ", Sig Different = " `sig_int' ", Total = " `total_int'
        
    restore
}

		
		
* Write second panel rows
file write latexfile "Share of Significantly Different Interviewers & `share_Ghana' & `share_India' & `share_Korea' & `share_Kenya' \\" _n
file write latexfile " & & & & \\" _n
file write latexfile "Number of Significantly Different Interviewers & `sig_Ghana' & `sig_India' & `sig_Korea' & `sig_Kenya' \\" _n
file write latexfile "Number of Interviewers & `total_Ghana' & `total_India' & `total_Korea' & `total_Kenya' \\" _n
file write latexfile "\hline\hline" _n
file write latexfile "\end{tabular}" _n

* Add note
file write latexfile "\begin{minipage}{\textwidth}" _n
file write latexfile "\small" _n
file write latexfile "Note: Data from the Firm-level Adoption of Technology (FAT) surveys in Brazil, Vietnam, Senegal, Bangladesh, Ghana, India, and Korea. " _n
file write latexfile "Significantly different interviewers are identified from the regressions of employment on interviewer dummies with controlling for stratification information (e.g., sector, size, and region). " _n
file write latexfile "For each country, the share of significantly different interviewers is computed by dividing the number of interviews conducted by significantly different interviewers by the total number of interviews." _n
file write latexfile "\end{minipage}" _n
file write latexfile "\end{table}" _n

file close latexfile

disp "LaTeX table saved to: ${path_output}\1_latex_tables\table_A28.tex"



***************************************************************************
******************************* TABLE A.29 ********************************
***************************************************************************

local countries `""Vietnam" "Senegal" "Bangladesh" "Kenya" "'
eststo clear

foreach c of local countries {
	u "${path_import}\replication_C28-C29.dta", clear
    keep if country =="`c'"
    
    cap drop region
    gen region = s1c_rev
    cap drop emp_group
    gen emp_group = s1b_rev
    cap drop ind_group
    gen ind_group = s1a_rev
    cap drop a8_num interviewer_id
    egen a8_num = sieve(a8), keep(numeric)
	
	*Cleanup of Kenya interviewer id's
		tab a8_num if country == "Kenya"
		replace a8_num= substr(a8, 1, 2) if country== "Kenya"
		replace a8_num = "0" if (a8_num=="31" | a8_num== "48" | a8_num== "67" | a8_num== "7") & country== "Kenya"
		tab a8_num if country == "Kenya"
		drop if a8_num == "0" & country == "Kenya"
		
    destring a8_num, gen(interviewer_id)
    
    if "`c'" == "Vietnam" {
        replace interviewer_id = 300 if interviewer_id > 1000000000
    }
    
    cap drop diff_enumer
    gen diff_enumer = 0
    reg tot_emp i.interviewer_id i.region i.ind_group i.emp_group 
    levelsof interviewer_id, local(interviewers)
    local remove 40063 42370
    local interviewers: list interviewers - remove

    
    foreach i of local interviewers {
        capture {
            local t = _b[`i'.interviewer_id]/_se[`i'.interviewer_id]  
            local p = 2*ttail(e(df_r),abs(`t'))
            qui replace diff_enumer = 1 if `p' < 0.05 & interviewer_id ==`i'
        }
    }
    
	//check distinct interviewers
	di "`c'"
	distinct interviewer_id if interviewer_id != 0
	distinct interviewer_id if diff_enumer == 1 & interviewer_id != 0
    gen full_sample = 1

	 
    preserve
        keep if diff_enumer == 0
        replace full_sample = 0
        tempfile subsample
        save `subsample', replace
    restore
	
	preserve
		append using `subsample'
		
		* Store results with country name
		eststo full_`c': quietly estpost summarize tech_int_abf_firm [aw=base_wt] if full_sample ==1
		eststo sub_`c': quietly estpost summarize tech_int_abf_firm [aw=base_wt] if full_sample ==0
		eststo diff_`c': quietly estpost ttest tech_int_abf_firm, by(full_sample)
    restore
   
}

* Open the tex file
capture file close myfile
file open myfile using "${path_output}\1_latex_tables\table_A29.tex", write replace

* Write table header
file write myfile "\begin{table}[htbp]" _n
file write myfile "\centering" _n
file write myfile "\caption{Difference in technology sophistication in general business functions with and without outlying enumerators}" _n
file write myfile "\label{tab:C29}" _n
file write myfile "\begin{tabular}{lccc}" _n
file write myfile "\hline\hline" _n
file write myfile " & All Sample & Sample Without Different & Difference \\" _n
file write myfile " & & Enumerators & \\" _n
file write myfile "\hline" _n

* Loop through countries to write results
foreach c in Vietnam Senegal Bangladesh Kenya {
    
    * Get statistics from stored estimates - estpost summarize
    quietly estimates restore full_`c'
    matrix stats_all = e(mean), e(sd), e(count)
    local mean_all = string(stats_all[1,1], "%9.3f")
    local se_all = string(stats_all[1,2], "%9.3f")  
    local n_all = stats_all[1,3]
    
    quietly estimates restore sub_`c'
    matrix stats_sub = e(mean), e(sd), e(count)
    local mean_sub = string(stats_sub[1,1], "%9.3f")
    local se_sub = string(stats_sub[1,2], "%9.3f")
    local n_sub = stats_sub[1,3]
    
    * Get difference from ttest results
    quietly estimates restore diff_`c'
    matrix stats_diff = e(b), e(se)
    local diff = string(stats_diff[1,1], "%9.3f")
    local se_diff = string(stats_diff[1,2], "%9.3f")
    
    * Write country section
    file write myfile "`c' \\" _n
    file write myfile "Mean & `mean_all' & `mean_sub' & `diff' \\" _n
    file write myfile "SE & (`se_all') & (`se_sub') & (`se_diff') \\" _n
    file write myfile "Observations & `n_all' & `n_sub' & \\" _n
    
    if "`c'" != "Kenya" {
        file write myfile "\hline" _n
    }
}

file write myfile "\hline\hline" _n
file write myfile "\end{tabular}" _n
file write myfile "\begin{tablenotes}[para,flushleft]" _n
file write myfile "\small" _n
file write myfile "Note: *** p<0.01, ** p<0.05, * p<0.1. Data from the Firm-level Adoption of Technology (FAT) surveys " _n
file write myfile "in Vietnam, Senegal, Bangladesh and Kenya. Brazil, Ghana, India and Korea are excluded because they " _n
file write myfile "do not include significantly different interviewers. The average of technology sophistication in general " _n
file write myfile "business functions (\$MOST_j\$) is compared between all sample and sample excluding significantly different " _n
file write myfile "enumerators. Standard errors in parenthesis." _n
file write myfile "\end{tablenotes}" _n
file write myfile "\end{table}" _n


file close myfile

/*
** These tables A31 and A32 use RAIS dataset merged with FAT data for Brazil

********************************************************************************
****************************** Table A31 ***************************************
********************************************************************************

if c(username) == "wb470973" {
	global path_FAT "C:\Users\wb470973\OneDrive - WBG\Marcio Cruz's files - QJE_replication_2025_ RAIS"
	global path_output "C:\Users\wb470973\OneDrive - WBG\Marcio Cruz's files - QJE_replication_2025_ RAIS"

}

** Define globals
global weight "base_wt_rev1"
global control "i.a5a i.region i.size_group i.fage_group i.mnc_group i.exp_group "

use "${path_FAT}\Inputs\RAIS_firm_level_2018.dta" 
merge 1:1 cnpj_cei using "${path_FAT}\Inputs\FAT_treated.dta"
keep if _merge == 3

cap drop region
if country == "Brazil" {
	
	gen region = 0
	replace	region	=	1	if 	s2d	==	"AQUIRAZ" & country == "Brazil"
	replace	region	=	1	if 	s2d	==	"CASCAVEL" & country == "Brazil"
	replace	region	=	1	if 	s2d	==	"CAUCAIA" & country == "Brazil"
	replace	region	=	1	if 	s2d	==	"EUSÉBIO" & country == "Brazil"
	replace	region	=	1	if 	s2d	==	"FORTALEZA" & country == "Brazil"
	replace	region	=	1	if 	s2d	==	"GUAIUBA" & country == "Brazil"
	replace	region	=	1	if 	s2d	==	"HORIZONTE" & country == "Brazil"
	replace	region	=	1	if 	s2d	==	"MARACANAÚ" & country == "Brazil"
	replace	region	=	1	if 	s2d	==	"MARANGUAPE" & country == "Brazil"
	replace	region	=	1	if 	s2d	==	"PACAJUS" & country == "Brazil"
	replace	region	=	1	if 	s2d	==	"SÃO GONÇALO DO AMARANTE" & country == "Brazil"
		
	label define region 0 "Other regions" 1 "MRF"
	label values region region		
	
}

drop _merge
*MERGE WITH FATA DATA PROVIDING THE TECHNOLOGY MEASURES (MOST) for GBF and SBF
merge 1:1 firmid using  "${path_FAT}\Inputs\FAT0_brazil.dta"
keep if _merge == 3
replace mean_wage = mean_sal_ultimo if mean_wage == 0

gen ln_wage = log(mean_wage)

cd "$path_output\Tables\"

foreach var in "Averagewage" "Sharecollege" "Sharehigh" "Sharepotec" {
		capture erase "Estimates_`var'.txt"
		capture erase "Estimates_`var'.xls"
}

cap gen sales = sales_2018 
gen sales_pw = sales/ totemp
gen lnsalespw = log(sales_pw)

foreach var of varlist  lnsalespw s_gbf s_ssbf {
	reg `var' ln_wage $control [pw=base_wt] , robust 
	outreg2 using "$path_output\Tables\Estimates_Averagewage.xls", ///
		append ctitle("`var'") dec(3) addtext(Sector FE, YES, Region FE, YES)

}

********************************************************************************
****************************** Table A32 ***************************************
********************************************************************************
use "${path_output}\Inputs2\Inputs\RAIS_firm_level_2017.dta", clear
merge 1:1 cnpj_cei using "${path_output}\Inputs\FAT_treated.dta"

replace treated = 0 if treated == .
label var treated "Surveyed"
label var base_ctr_wt "Weight"
keep cnpj_cei- treated treated base_ctr_wt

*** Drop non eligible sectors and firms with less than 5 employees

drop if sector_RAIS == 0 & treated == 0
drop if size_group_RAIS == 0 & treated == 0

drop if sector_RAIS == .

replace base_ctr_wt = 1 if base_ctr_wt == .
svyset [pw = base_ctr_wt]

save "${path_output}\Inputs\Final_merged_RAIS_2017", replace

putexcel set "${path_output}\Tables\Ttest_2017", replace sheet("Full sample") 

putexcel B2 = "N. of employees"
putexcel C2 = "Average wage"
putexcel D2 = "Share college"
putexcel E2 = "Share low-skill"
putexcel F2 = "Share high-skill"

putexcel A3 = "FAT Average"
putexcel A4 = "Universe Average (population)"
putexcel A5 = "Estimate (control - treated)"
putexcel A6 = "Standard Error"
putexcel A7 = "T-Statistic"

rename n B
rename mean_wage C
rename share_college D
rename share_low_skill E
rename share_high_skill F


foreach var of varlist B C D E F {

svy: mean `var', over(treated) coeflegend

putexcel `var'3 = _b[c.`var'@1.treated]
putexcel `var'4 =  _b[c.`var'@0bn.treated]

lincom _b[c.`var'@0bn.treated] - _b[c.`var'@1.treated]	

putexcel `var'5 = `r(estimate)'
putexcel `var'6 = `r(se)'
putexcel `var'7 = `r(t)'

}



*/

	

***************************************************************************
******************************* TABLE C.1 *********************************
***************************************************************************

use "${path_import}\FAT0_firm_level.dta", clear


// generate part 1 of the table
gen sales_per_worker = sales/tot_emp
replace sales_per_worker = ln(sales_per_worker)

rename tot_emp summary1
rename e5d summary2
rename mgt_z summary3
rename sales_per_worker summary4


foreach var of varlist summary* {
	
	sum `var' [aw=base_wt], detail 
	gen mean_`var' = `r(mean)'
	sum `var' [aw=base_wt], detail 
	gen N_`var' = `r(N)'
	sum `var' [aw=base_wt], detail 
	gen p50_`var' = `r(p50)'
	
	sum `var' [aw=base_wt] if size_group == 1
	gen mean1_`var' = `r(mean)'
	sum `var' [aw=base_wt] if size_group == 1
	gen N1_`var' = `r(N)'

	sum `var' [aw=base_wt] if size_group == 2
	gen mean2_`var' = `r(mean)'
	sum `var' [aw=base_wt] if size_group == 2
	gen N2_`var' = `r(N)'

	sum `var' [aw=base_wt] if size_group == 3
	gen mean3_`var' = `r(mean)'
	sum `var' [aw=base_wt] if size_group == 3
	gen N3_`var' = `r(N)'

	
}


keep summary* mean* N* p50*
collapse (mean) summary* mean* N* p50*
gen id = 1
reshape long summary mean_summary N_summary p50_summary N1_summary mean1_summary N2_summary mean2_summary N3_summary mean3_summary, i(id) j(variable)

drop id
tostring variable, replace
replace variable = "Total # of employees" if variable == "1"
replace variable = "% of workers with college" if variable == "2"
replace variable = "Management practice (z-score)" if variable == "3"
replace variable = "Sales per worker" if variable == "4"

drop summary


foreach var of varlist mean_summary p50_summary mean1_summary mean2_summary mean3_summary {
	gen n_`var' = string(`var',"%4.2f") 
	drop `var'
	rename n_`var' `var'
	replace `var' = "" if `var' == "."
}	


foreach var of varlist N_summary N1_summary N2_summary N3_summary {
	gen n_`var' = string(`var',"%4.0f") 
	drop `var'
	rename n_`var' `var'
	replace `var' = "" if `var' == "."
}	

order variable N_summary mean_summary p50_summary N1_summary mean1_summary N2_summary mean2_summary N3_summary mean3_summary


label var variable ""
label var mean_summary "Mean"
label var N_summary "N"
label var p50_summary "p50"
label var N1_summary "N"
label var mean1_summary "Mean"
label var N2_summary "N"
label var mean2_summary "Mean"
label var N3_summary "N"
label var mean3_summary "Mean"
gen order1 = 1
gen order2 = _n
save "${path_import}/table2_1.dta", replace

drop order1 order2

///////////////////////////////////////////////////////////

use "${path_import}\FAT0_firm_level.dta", clear
cap drop db* dc* tech ib* ic*
duplicates drop *, force


replace s4 = 0 if s4 == 2
tabulate fage, generate(fage_group_)


tabulate a5a, gen(a5a_)

preserve
collapse (mean) s4 mnc exporter fage_group_* elec_comp_int a5a_*
gen order2 = 1

save "${path_import}/table2_2.dta", replace
restore

drop if size_group == .

collapse (mean) s4 mnc exporter fage_group_* elec_comp_int a5a_*, by(size_group)
gen order2 = 2

append using "${path_import}/table2_2.dta"
sort order2 size_group

xpose, clear	
drop if v1 == 1 | v1 == .

foreach var of varlist v1 v2 v3 v4 {
	replace `var' = `var'*100
    
}
 
label var v1 "Share" 
label var v2 "Share" 
label var v3 "Share" 
label var v4 "Share" 


set obs `=_N+3'

gen list_ = _n
generate label_var = "Multi-establishment" if list_ == 1
replace label_var = "Multinational" if list_ == 2
replace label_var = "Exporter" if list_ == 3
replace label_var = "1-5 Years" if list_ == 4
replace label_var = "6-10 Years" if list_ == 5
replace label_var = "11-15 Years" if list_ == 6
replace label_var = "16+ Years" if list_ == 7
replace label_var = "Has electricity, computer and internet" if list_ == 8
replace label_var = "Agriculture" if list_ == 9
replace label_var = "Livestock" if list_ == 10
replace label_var = "Food Processing" if list_ == 11
replace label_var = "Apparel" if list_ == 12
replace label_var = "Motor vehicles" if list_ == 13
replace label_var = "Pharmaceuticals" if list_ == 14
replace label_var = "Wholesale or retail" if list_ == 15
replace label_var = "Financial services" if list_ == 16
replace label_var = "Land Transport" if list_ == 17
replace label_var = "Health Services" if list_ == 18
replace label_var = "Leather" if list_ == 19
replace label_var = "Other Manufacturing" if list_ == 20
replace label_var = "Other Services" if list_ == 21



replace label_var = "\textit{Age:}" if list_ == 22
replace label_var = "\textit{Sector:}" if list_ == 23


replace list_ = 3.5 if list_ == 22
replace list_ = 8.5 if list_ == 23 
replace list_ = 0.5 if list_ == 24

sort list

order label_var v*
drop list_


//////////////////////////////////////////////////
foreach var of varlist v1 v2 v3 v4 {
	gen n_`var' = string(`var',"%4.1f") 
	drop `var'
	rename n_`var' `var'
	replace `var' = `var' + "%"
	replace `var' = "" if `var' == ".%"
	//replace `var' = "Share" if label_var == ""
}	
	
label var v1 "Share" 
label var v2 "Share" 
label var v3 "Share" 
label var v4 "Share" 
	
drop if label_var == ""	
	
rename v1 mean_summary 
rename v2 mean1_summary
rename v3 mean2_summary
rename v4 mean3_summary
rename label_var variable

gen order1 = 2
gen order2 = _n
append using "${path_import}/table2_1.dta"
sort order1 order2

order variable N_summary mean_summary p50_summary N1_summary mean1_summary N2_summary mean2_summary N3_summary mean3_summary

set obs `=_N+1'
replace order1 = 0 if order1 == .
sort order1 order2

foreach var of varlist N* {
	replace `var' = "N" if order1 == 0
}

foreach var of varlist mean* {
	replace `var' = "Mean" if order1 == 0
}

foreach var of varlist p50 {
	replace `var' = "p50" if order1 == 0
}

foreach var of varlist N_summary p50_summary {
	label var `var' ""
}

label var mean_summary "All"
label var N1_summary "Small"
label var mean1_summary "(5-19)"
label var N2_summary "Medium"
label var mean2_summary "(20-99)"
label var N3_summary "Large"
label var mean3_summary "(100+)"

drop order1 order2
* Add a new blank row at the end
set obs `=_N+1'
replace mean_summary = "Share" in L
replace mean1_summary = "Share" in L
replace mean2_summary = "Share" in L
replace mean3_summary = "Share" in L
gen order = _n
replace order = order + 1 if order > 5
replace order = 6 in `=_N'   // position you want

sort order
drop order
global table2_notes "Notes: The top panel provides descriptive statistics for the total number of employees, % of workers with a college degree, Z-score of Management Practice, and ln(Sales pw). These statistics are computed using the establishment-level sampling weights, and are also reported for different size-groups. The bottom panel reports the share of establishments for respective characteristics. Note that these establishment shares are unweighted."


texsave using "${path_output}/table_C1.tex", hlines(1 5 6 28) replace title(Summary Statistics) varlabels footnote("${table2_notes}")  valuelabels size(footnotesize) width(18cm) label("tab:desc_stats_establishments")	



***************************************************************************
******************************* TABLE C.2 *********************************
***************************************************************************

use "${path_import}/FAT0_reshaped_firm_busfn_updated_new.dta", clear

drop if anum_bus_fn == .

gsort -gbf +bus_fn +sector

gen gap = 1 if MAX_bus_fn > MOST_bus_fn & anum_bus_fn > 1
replace gap = 0 if MAX_bus_fn == MOST_bus_fn & anum_bus_fn > 1

foreach var of varlist  num_r_bus_fn MAX_bus_fn MOST_bus_fn gap num_max_bus_fn {
	gen mean_`var' = .
	forvalue i = 1/68 {
	sum `var' [aw=base_wt] if bus_fn == `i'
	replace mean_`var' = `r(mean)' if bus_fn == `i'
	}
}

collapse (mean) mean_*, by(bus_fn label_fn gbf ssbf sector)

gen overall = 1 //just for ordering the vars
save "${path_import}/FAT0 data/table3.dta", replace
 
collapse (mean) mean_*
gen label_fn = "ABFs"
gen overall = 2
gen gbf = 0
gen ssbf = 0

append using "${path_import}/FAT0 data/table3.dta"
save "${path_import}/FAT0 data/table3.dta", replace

collapse (mean) mean_*, by(gbf)
gen label_fn = "GBFs"
drop if gbf == 0 | gbf == .
drop gbf 
gen overall = 3
gen ssbf = 0

append using "${path_import}/FAT0 data/table3.dta"
save "${path_import}/FAT0 data/table3.dta", replace

collapse (mean) mean_*, by(ssbf)
gen label_fn = "SSBFs"
drop if ssbf == 0 | ssbf == .
gen overall = 4

append using "${path_import}/FAT0 data/table3.dta"
save "${path_import}/FAT0 data/table3.dta", replace

gsort -gbf +sector +bus_fn overall

replace label_fn = strtrim(label_fn)

label var mean_gap "GAP"
label var mean_num_r_bus_fn "NUM"
label var mean_MAX_bus_fn "MAX"
label var mean_MOST_bus_fn "MOST"
label var mean_num_max_bus_fn "N\(_f\)"

save "${path_import}/FAT0 data/table3.dta", replace



use "${path_import}/FAT0 data/table3.dta", clear 
keep if sector == . | sector == 1 | sector == 2 | sector == 3 | sector == 4 | sector == 11
set obs `=_N+10'
gen obs = _n

replace label_fn = "General Business Functions" if obs == 38
replace label_fn = "Agriculture" if obs == 39
replace label_fn = "Livestock" if obs == 40
replace label_fn = "Food Processing" if obs == 41
replace label_fn = "Wearing Apparel" if obs == 42
replace label_fn = "Leather and Footwear" if obs == 43
replace label_fn = "Overall" if obs == 44
replace label_fn = "" if obs == 45
replace label_fn = "" if obs == 46
replace label_fn = "" if obs == 47


replace label_fn = "\textit{"+label_fn+"}" if overall == . & label_fn != ""

replace obs = 0.5 if obs == 38
replace obs = 7.5 if obs == 39
replace obs = 13.5 if obs == 40
replace obs = 18.5 if obs == 41
replace obs = 24.5 if obs == 42
replace obs = 29.5 if obs == 43
replace obs = 34.5 if obs == 44
replace obs = 13.4 if obs == 45
replace obs = 34.4 if obs == 46
replace obs = 34.3 if obs == 47

sort obs 
order label_fn

drop obs 
gen obs=_n

save "${path_import}/FAT0 data/table3_1.dta", replace


//part2
use "${path_import}/FAT0 data/table3.dta", clear 
keep if sector == 5| sector == 6 | sector == 7 | sector == 8 | sector == 9 | sector == 10 | sector == 101

foreach var of varlist * {
	rename `var' `var'2
}

set obs `=_N+13'
gen obs = _n

replace label_fn = "Automotive" if obs == 35
replace label_fn = "Pharmaceuticals" if obs == 36
replace label_fn = "Wholesale and Retail" if obs == 37
replace label_fn = "Financial Services" if obs == 38
replace label_fn = "Transportation" if obs == 39
replace label_fn = "Healthcare" if obs == 40
replace label_fn = "Other Manufacturing" if obs == 41
replace label_fn = "" if obs > 41

replace label_fn = "\textit{"+label_fn+"}" if overall == . & label_fn != ""

replace obs = 0.5 if obs == 35
replace obs = 6.5 if obs == 36
replace obs = 13.5 if obs == 37
replace obs = 18.5 if obs == 38
replace obs = 23.5 if obs == 39
replace obs = 28.5 if obs == 40
replace obs = 33.5 if obs == 41
replace obs = 6.4 if obs == 42
replace obs = 23.4 if obs == 43
replace obs = 35 if obs == 44
replace obs = 36 if obs == 45
replace obs = 37 if obs == 46
replace obs = 38 if obs == 47

sort obs
drop obs 
gen obs = _n

merge 1:1 obs using "${path_import}/FAT0 data/table3_1.dta"

keep label_fn2 mean_num_r_bus_fn2 mean_MAX_bus_fn2 mean_MOST_bus_fn2 mean_gap2 mean_num_max_bus_fn2 obs label_fn mean_num_r_bus_fn mean_MAX_bus_fn mean_MOST_bus_fn mean_gap mean_num_max_bus_fn 


foreach var of varlist mean_gap mean_num_r_bus_fn mean_MAX_bus_fn mean_MOST_bus_fn  mean_gap2 mean_num_r_bus_fn2 mean_MAX_bus_fn2 mean_MOST_bus_fn2 {
	gen n_`var' = string(`var',"%4.1f") 
	drop `var'
	rename n_`var' `var'
	replace `var' = "" if `var' == "."
}

foreach var of varlist mean_num_max_bus_fn {
	gen n_`var' = string(`var',"%4.0f") if obs <45
	replace  n_`var' = string(`var',"%4.1f") if obs >=45
	drop `var'
	rename n_`var' `var'
	replace `var' = "" if `var' == "."
	
}

foreach var of varlist mean_num_max_bus_fn2 {
	gen n_`var' = string(`var',"%4.0f")
	drop `var'
	rename n_`var' `var'
	replace `var' = "" if `var' == "."
	
}




order obs label_fn mean_num_r_bus_fn mean_MAX_bus_fn mean_MOST_bus_fn mean_gap mean_num_max_bus_fn label_fn2 mean_num_r_bus_fn2 mean_MAX_bus_fn2 mean_MOST_bus_fn2 mean_gap2 mean_num_max_bus_fn2

label var label_fn "Business Function"
label var mean_gap "\tiny \(GAP\)"
label var mean_num_r_bus_fn "\tiny \(NUM\)"
label var mean_MAX_bus_fn "\tiny \(MAX\)"
label var mean_MOST_bus_fn "\tiny \(MOST\)"
label var mean_num_max_bus_fn "\tiny \(N\)"
label var label_fn2 "Business Function"
label var mean_gap2 "\tiny \(GAP\)"
label var mean_num_r_bus_fn2 "\tiny \(NUM\)"
label var mean_MAX_bus_fn2 "\tiny \(MAX\)"
label var mean_MOST_bus_fn2 "\tiny \(MOST\)"
label var mean_num_max_bus_fn2 "\tiny \(N\)"


***************************************************************************

preserve 
keep if obs > 44
keep label_fn mean_num_r_bus_fn mean_MAX_bus_fn mean_MOST_bus_fn mean_gap mean_num_max_bus_fn
save "${path_import}/FAT0 data/table3_pt1.dta", replace
restore

keep if obs < 44
drop obs


global table3_notes "\footnotesize  Notes: The table reports the average of $NUM_{f,j}$, $MAX_{f,j}$, $MOST_{f,j}$ and $GAP_{f,j}$ across establishments in each business function $f$. Averages are calculated using sampling weights. $N$ is the number of technologies in the grid for the business function."	
	
	
texsave using "${path_output}/table_C2.tex", hlines(0 8 16 22 29 35) replace title(Average level of technology measures) varlabels footnote("") valuelabels size(tiny) width(18.5cm) colwidth(0.2cm) align(lCCCCClCCCCC) nofix label("tab:stats_tech_measures_app") 



***************************************************************************
******************************* TABLE C.3 *********************************
***************************************************************************

use "${path_import}/FAT0_reshaped_firm_busfn_updated_new.dta", clear


	 
	gen value_bus_fn = 1+r_bus_fn -r_min_bus_fn
	gen dcont_bf = (anum_bus_fn < value_bus_fn)
	replace dcont_bf = . if anum_bus_fn==.
	drop value_bus_fn
	
	
*** Table 6: Percentage of establishments with technology gaps
	matrix dcont_bybf_num_gt2 = J(1,1,.)
	foreach i of numlist 1/68 {
		tabstat dcont_bf [aw=base_wt] if  anum_bus_fn>=2 & bus_fn==`i', save
		matrix dcont_bybf_num_gt2 = (dcont_bybf_num_gt2\r(StatTotal))
	}
	matlist dcont_bybf_num_gt2
	matrix dcont_bybf_num_gt2 = dcont_bybf_num_gt2[2...,1...]

	tabstat dcont_bf [aw=base_wt] if  anum_bus_fn>=2, save
	matrix dcont_abf = r(StatTotal)'
	tabstat dcont_bf [aw=base_wt] if  anum_bus_fn>=2 & gbf==1, save
	matrix dcont_gbf = r(StatTotal)'
	tabstat dcont_bf [aw=base_wt] if  anum_bus_fn>=2 & ssbf==1, save
	matrix dcont_sbf = r(StatTotal)'

	matrix dcont_allbf_num_gt2 = (dcont_abf, dcont_gbf, dcont_sbf)'
	matlist dcont_allbf_num_gt2
	
	matrix results = (dcont_bybf_num_gt2\ dcont_allbf_num_gt2)
	matlist results

	matrix rownames results = Admin Planning Sourcing Marketing Sales Payment QualCont LandPrep Irrigation PestCont Harvesting Storage Packing Breeding Nutrition AnimalHealth HerdManagement TransportLivestock InputTest Mixing AntiBacterial Packaging FoodStorage  Design Cutting Sewing Finishing  Assembly Pressing Painting Molding Management  Facilities Weighing Compounding Encapsulation QualityControl Packaging  CustomerService Pricing Merchandising Inventory Advertisement CustomerService IDVerification LoanApplication LoanApproval OperationalSupport Planning Execution Monitoring PerformanceMeasurement Maintenance InfrastructureMachines SchedulingAppointments ManagementRecords HealthcareManagement Procedures Design Cutting Sewing Finishing FoodProcFabrication WAFabrication AutomotiveFabrication PharmaFabrication LeatherFabrication OtherManufFabrication Across_ABF Across_GBF Across_SBF
	
	matlist results
	putexcel set "${path_output}\table_C3.xlsx",  replace
putexcel A1=matrix(results) ,rownames 


*** After creating the matrix "results" with rownames assigned ***

file open tex using "${path_output}\table_C3.tex", write replace
file write tex "\begin{table}[htbp]\centering" _n
file write tex "\caption{Frequency of Sophistication Gaps by Business Function}" _n
file write tex "\begin{tabular}{l c  l c}" _n
file write tex "\hline" _n
file write tex "Business Functions & \(SG_i\) & Business Functions & \(SG_i\) \\" _n
file write tex "\hline" _n

*** ---------------- General Business Functions ---------------- ***
file write tex "\textit{General Business Functions} & & \textit{Automotive} & \\" _n
file write tex "Business Administration & " %4.0f (results[1,1]*100) "\% & Vehicle assembly & " %4.0f (results[28,1]*100) "\% \\" _n
file write tex "Production Planning & " %4.0f (results[2,1]*100) "\% & Body processing and welding & " %4.0f (results[29,1]*100) "\% \\" _n
file write tex "Sourcing & " %4.0f (results[3,1]*100) "\% & Painting & " %4.0f (results[30,1]*100) "\% \\" _n
file write tex "Marketing & " %4.0f (results[4,1]*100) "\% & Plastic injection molding & " %4.0f (results[31,1]*100) "\% \\" _n
file write tex "Sales & " %4.0f (results[5,1]*100) "\% & Productive assets management & " %4.0f (results[32,1]*100) "\% \\" _n
file write tex "Payment & " %4.0f (results[6,1]*100) "\% & Fabrication & " %4.0f (results[65,1]*100) "\% \\" _n
file write tex "Quality Control & " %4.0f (results[7,1]*100) "\% & & \\" _n
file write tex "\hline" _n

*** ---------------- Agriculture - Crops ---------------- ***
file write tex "\textit{Agriculture - Crops} & & \textit{Pharmaceutical} & \\" _n
file write tex "Land Preparation & " %4.0f (results[8,1]*100) "\% & Facilities & " %4.0f (results[33,1]*100) "\% \\" _n
file write tex "Irrigation & " %4.0f (results[9,1]*100) "\% & Weighing & " %4.0f (results[34,1]*100) "\% \\" _n
file write tex "Pest Control & " %4.0f (results[10,1]*100) "\% & Compounding & " %4.0f (results[35,1]*100) "\% \\" _n
file write tex "Harvesting & " %4.0f (results[11,1]*100) "\% & Encapsulation & " %4.0f (results[36,1]*100) "\% \\" _n
file write tex "Storage & " %4.0f (results[12,1]*100) "\% & Quality Control & " %4.0f (results[37,1]*100) "\% \\" _n
file write tex "Packing & " %4.0f (results[13,1]*100) "\% & Packaging & " %4.0f (results[38,1]*100) "\% \\" _n
file write tex "& & Fabrication & " %4.0f (results[66,1]*100) "\% \\" _n
file write tex "\hline" _n

*** ---------------- Livestock ---------------- ***
file write tex "\textit{Livestock} & & \textit{Wholesale and Retails} & \\" _n
file write tex "Breeding & " %4.0f (results[14,1]*100) "\% & Customer Service & " %4.0f (results[39,1]*100) "\% \\" _n
file write tex "Nutrition & " %4.0f (results[15,1]*100) "\% & Pricing & " %4.0f (results[40,1]*100) "\% \\" _n
file write tex "Animal healthcare & " %4.0f (results[16,1]*100) "\% & Merchandising & " %4.0f (results[41,1]*100) "\% \\" _n
file write tex "Herd management & " %4.0f (results[17,1]*100) "\% & Inventory & " %4.0f (results[42,1]*100) "\% \\" _n
file write tex "Transport of Livestock & " %4.0f (results[18,1]*100) "\% & Advertisement & " %4.0f (results[43,1]*100) "\% \\" _n
file write tex "\hline" _n

*** ---------------- Food Processing ---------------- ***
file write tex "\textit{Food Processing} & & \textit{Finance} & \\" _n
file write tex "Input Test & " %4.0f (results[19,1]*100) "\% & Customer Service & " %4.0f (results[44,1]*100) "\% \\" _n
file write tex "Mixing/Blending/Cooking & " %4.0f (results[20,1]*100) "\% & ID Verification & " %4.0f (results[45,1]*100) "\% \\" _n
file write tex "Anti-bacterial & " %4.0f (results[21,1]*100) "\% & Loan Application & " %4.0f (results[46,1]*100) "\% \\" _n
file write tex "Packaging & " %4.0f (results[22,1]*100) "\% & Loan Approval & " %4.0f (results[47,1]*100) "\% \\" _n
file write tex "Food Storage & " %4.0f (results[23,1]*100) "\% & Operational Support Area & " %4.0f (results[48,1]*100) "\% \\" _n
file write tex "Fabrication & " %4.0f (results[63,1]*100) "\% & & \\" _n
file write tex "\hline" _n

*** ---------------- Wearing Apparel ---------------- ***
file write tex "\textit{Wearing Apparel} & & \textit{Transportation} & \\" _n
file write tex "Design & " %4.0f (results[24,1]*100) "\% & Customer Service & " %4.0f (results[49,1]*100) "\% \\" _n
file write tex "Cutting & " %4.0f (results[25,1]*100) "\% & Logistics & " %4.0f (results[50,1]*100) "\% \\" _n
file write tex "Sewing & " %4.0f (results[26,1]*100) "\% & Monitoring & " %4.0f (results[51,1]*100) "\% \\" _n
file write tex "Finishing & " %4.0f (results[27,1]*100) "\% & Performance Measurement & " %4.0f (results[52,1]*100) "\% \\" _n
file write tex "Fabrication & " %4.0f (results[64,1]*100) "\% & Maintenance & " %4.0f (results[53,1]*100) "\% \\" _n
file write tex "\hline" _n

*** ---------------- Leather and Footwear ---------------- ***
file write tex "\textit{Leather and Footwear} & & \textit{Healthcare} & \\" _n
file write tex "Design & " %4.0f (results[59,1]*100) "\% & Infrastructure and Machines & " %4.0f (results[54,1]*100) "\% \\" _n
file write tex "Cutting & " %4.0f (results[60,1]*100) "\% & Scheduling Appointments & " %4.0f (results[55,1]*100) "\% \\" _n
file write tex "Sewing & " %4.0f (results[61,1]*100) "\% & Management of Patient Records & " %4.0f (results[56,1]*100) "\% \\" _n
file write tex "Finishing & " %4.0f (results[62,1]*100) "\% & Healthcare Management & " %4.0f (results[57,1]*100) "\% \\" _n
file write tex "Fabrication & " %4.0f (results[67,1]*100) "\% & Procedures & " %4.0f (results[58,1]*100) "\% \\" _n
file write tex "\hline" _n

*** ---------------- Other Manufacturing ---------------- ***
file write tex "& & \textit{Other Manufacturing}  \\" _n
file write tex "& & Fabrication & " %4.0f (results[68,1]*100) "\% \\" _n
file write tex "\hline" _n
file write tex "\end{tabular}" _n

*** Notes ***
file write tex "\vspace{0.5em}"
file write tex "\begin{minipage}{0.9\textwidth}"
file write tex "\footnotesize \textit{Notes:} The table reports the percentage of establishments that experience sophistication gaps in each business function. See Section~4.1 for the definition of sophistication gaps. The percentages are calculated using sampling weights."
file write tex "\end{minipage}"
file write tex "\end{table}" _n
file close tex





***************************************************************************
******************************* TABLE C.5 *********************************
***************************************************************************

use "${path_import}/FAT0_firm_level.dta", clear

collapse max_g_most MAX_bus_fn MOST_bus_fn [aw=base_wt], by(fage size_group)
drop if size_group == .
drop if fage == .
reshape wide max_g_most MAX_bus_fn MOST_bus_fn, i(fage) j(size_group)

order fage max_g_most* MAX_bus_fn* MOST_bus_fn*

save "${path_output}/tableC.5.dta", replace

// make the latex table with these results

gen age_cat = ""
replace age_cat ="<=5" if fage==1
replace age_cat ="6-10" if fage==2
replace age_cat ="11-15" if fage==3
replace age_cat =">=16" if fage==4

file open tex using "${path_output}\table_C5.tex", write replace
file write tex ///
"\begin{table}[htbp]" _n ///
"\centering" _n ///
"\caption{Average GAP, MAX, and MOST along firm's age and size groups}" _n ///
"\begin{tabular}{lccccccccc}" _n ///
"\toprule" _n ///
"& \multicolumn{3}{c}{GAP} & \multicolumn{3}{c}{MAX} & \multicolumn{3}{c}{MOST} \\" _n ///
"\cmidrule(lr){2-4} \cmidrule(lr){5-7} \cmidrule(lr){8-10}" _n ///
"\textbf{Age Group} & Small & Medium & Large & Small & Medium & Large & Small & Medium & Large \\" _n ///
"\midrule" _n

* Loop through rows
quietly {
    forvalues i = 1/`=_N' {
        local age_cat = age_cat[`i']
        local g1 = round(max_g_most1[`i'], .01)
        local g2 = round(max_g_most2[`i'], .01)
        local g3 = round(max_g_most3[`i'], .01)
        local m1 = round(MAX_bus_fn1[`i'], .01)
        local m2 = round(MAX_bus_fn2[`i'], .01)
        local m3 = round(MAX_bus_fn3[`i'], .01)
        local mo1 = round(MOST_bus_fn1[`i'], .01)
        local mo2 = round(MOST_bus_fn2[`i'], .01)
        local mo3 = round(MOST_bus_fn3[`i'], .01)

        file write tex ///
        "`age_cat' & `g1' & `g2' & `g3' & `m1' & `m2' & `m3' & `mo1' & `mo2' & `mo3' \\" _n
    }
}

file write tex ///
"\bottomrule" _n ///
"\end{tabular}" _n ///
"\begin{minipage}{16cm}" _n ///
"\vspace{0.3cm}" _n ///
"\footnotesize Notes: Averages of \textit{GAP}, \textit{MAX}, and \textit{MOST} across establishments in specific size and age groups. Averages computed using establishment-level sampling weights." _n ///
"\end{minipage}" _n /// 
"\end{table}" _n

file close tex
***************************************************************************
**#**************************** TABLE C.6 *********************************
***************************************************************************
// get from productivity regs


use "${path_import}/FAT0_firm_level.dta", clear

//LOAN REJECTION VARIABLE
replace d3c = . if d3c > 99
gen loan_rejected = 1 if d3c > 0
replace loan_rejected = 0 if d3c == 0

//BIAS VARIABLE
gen scaled_perceptions = 1+4/9*(b7b-1)
gen misperception_gaps = scaled_perceptions - avg_max_most

gen fam_bus=0 if a4b!=.
replace fam_bus=1 if a4b!=. & (a4b==1 | a4b==2)

gen rich=0 if countrycode!=.
replace rich=1 if (countrycode==6 | countrycode==12 | countrycode==13)

//
est clear

reg max_g_most Hj loan_rejected mgt_z fam_bus mnc exporter  misperception_gaps i.fage  i.countrycode i.a5a if size==1 [pw=base_wt]
estadd local SectorFE "Yes"
estadd local CountryFE "Yes"
estadd local data "Small"
est store tablec6_1

reg max_g_most Hj loan_rejected mgt_z fam_bus mnc exporter  misperception_gaps i.fage  i.countrycode i.a5a if size==2 [pw=base_wt]
estadd local SectorFE "Yes"
estadd local CountryFE "Yes"
estadd local data "Medium"
est store tablec6_2

reg max_g_most Hj loan_rejected mgt_z fam_bus mnc exporter  misperception_gaps i.fage  i.countrycode i.a5a if size==3 [pw=base_wt]
estadd local SectorFE "Yes"
estadd local CountryFE "Yes"
estadd local data "Large"
est store tablec6_3

reg max_g_most Hj loan_rejected mgt_z fam_bus mnc exporter  misperception_gaps i.fage  i.countrycode i.a5a if rich==0 [pw=base_wt]
estadd local SectorFE "Yes"
estadd local CountryFE "Yes"
estadd local data "Poor Countries"
est store tablec6_4

reg max_g_most Hj loan_rejected mgt_z fam_bus mnc exporter  misperception_gaps i.fage  i.countrycode i.a5a if rich==1 [pw=base_wt]
estadd local SectorFE "Yes"
estadd local CountryFE "Yes"
estadd local data "Rich Countries"
est store tablec6_5


label var Hj "\\ \(H_j\)"
label var loan_rejected "D(Rejected Loan)"
label var misperception_gaps "Bias"
label var num_fraction_1 "Fraction of BFs with \(NUM_{f,j} > 1\)"
label var mnc "Foreign Owned"
label var s4 "Multi-establishment"
label var exporter "Exporter"
label values fage age
label var fam_bus "Family Business" 


global tablec6_notes "Notes : Dependent variable is defined at establishment level as number of BFs with \(MAX_{fj} > MOST_{fj}\), over number of BFs with \(NUM_{f,j} > 1\). The base categories are Size: Small, and Age $\leq$ 5 Years. Establishments weighted by sampling weights. Loan rejected is a binary variable taking value 1 if the establishment has any loan rejected in the last year."

esttab tablec6* using "${path_output}/table_C6.tex",  replace label s(N r2 SectorFE CountryFE Data, label("N" "R-squared" "2-Dig. Sector FE" "Country FE" "Data") fmt(%4.0f %4.3f)) star(* 0.1 ** 0.05 *** 0.01) b(%4.3f) se(%4.3f) drop(*.a5a *.countrycode) nobase title() prehead("\begin{table}[htbp]\centering \def\sym#1{\ifmmode^{#1}\else\(^{#1}\)\fi} \caption{Correlates of MAX-MOST Gaps across establishments by size and country income level}  \label{tab:gaps_regression} \adjustbox{max width=0.8\textwidth}{\begin{tabular}{l*{5}{c}}\hline\hline \\  &\multicolumn{5}{c}{\(GAP_j\)} \\") postfoot("\hline \hline \end{tabular}} \begin{minipage}{18cm} \vspace{0.1cm} \vspace{0.1cm}\footnotesize ${tablec6_notes} *, ** and *** denote 10\%, 5\% and 1\% significance respectively. \end{minipage} \end{table}") substitute(\_ _) eqlabels(none) nomtitle collabels(none)


************************************************************************************
**#**************************** TABLE C.4, C.7-C.9 *********************************
************************************************************************************

use "${path_import}/FAT0_firm_level.dta", clear

// construct solow residuals
gen ln_sales = ln(sales)
gen ln_mat_cost = ln(mat_cost)
gen ln_cap_cost = ln(cap_cost)
gen ln_energy_cost = ln(energy_cost)
reg ln_sales ln_emp ln_mat_cost ln_cap_cost ln_energy_cost i.a5a [pw=base_wt] 
predict u_solow if e(sample), resid


// A. and B. - sales, lab_cost, mat_cost, energy_cost, cap_cost
gen profits = sales - lab_cost - 0.01*cap_cost - mat_cost - energy_cost
gen profit_rate = profits/sales
xtile profit_pct = profit_rate [aw=base_wt], nq(100)
gen profit_w = 1 if profit_pct < 98 & profit_pct > 2


est clear

gen rich=0 
replace rich=1 if (countrycode==6 | countrycode==12 | countrycode==13)

gen Sj_rich=Sj*rich

gen S_1 = 1 if avg_max_most < 1.5
gen S_2 = 1 if avg_max_most >= 1.5 & avg_max_most < 2.5
gen S_3 = 1 if avg_max_most >= 2.5 & avg_max_most < 3.5
gen S_4 = 1 if avg_max_most >= 3.5 & avg_max_most != .

foreach var of varlist S_* {
	replace `var' = 0 if `var' == . & avg_max_most != .
}



sum avg_max_most [aw=base_wt],detail
gen med_sj = `r(p50)'
gen avg_soph_high = 1 if avg_max_most > med_sj & avg_max_most != .
replace avg_soph_high= 0 if avg_soph_high == . & avg_max_most != . 
replace avg_soph_high = avg_soph_high*avg_max_most


gen Sj_1 = S_1*avg_max_most
gen Sj_2 = S_2*avg_max_most
gen Sj_3 = S_3*avg_max_most
gen Sj_4 = S_4*avg_max_most



///////////////////////////////////
// LABELS 
label var u_solow "TFP"
label var sales_pw "ln(Sales per worker)"
label var Sj_rich "(\bar{S}_j * D(Rich Country)\)"
label var profit_rate "Profit Rate"
label var MOST_bus_fn "\(MOST_j\)"
label var MAX_bus_fn "\(MAX_j\)"

label var S_1 "D(\(\bar{S}_j\) < 1.5)" 
label var S_2 "D(1.5 $\leq$ \(\bar{S}_j\) $\leq$ 2.5)" 
label var S_3 "D(2.5 $\leq$ \(\bar{S}_j\) $\leq$ 3.5)" 
label var S_4 "D(\(\bar{S}_j\) $\geq$ 3.5)"

label var Sj_1 "D(\(\bar{S}_j\) < 1.5) * \(\bar{S}_j\) " 
label var Sj_2 "D(1.5 $\leq$ \(\bar{S}_j\) $\leq$ 2.5) * \(\bar{S}_j\)" 
label var Sj_3 "D(2.5 $\leq$ \(\bar{S}_j\) $\leq$ 3.5) * \(\bar{S}_j\)" 
label var Sj_4 "D(\(\bar{S}_j\) $\geq$ 3.5) * \(\bar{S}_j\)"

label var avg_soph_high "\(\bar{S}_j*D(High Sophistication)\)"
label var Sj "\(\bar{S}_j\)"

label var Kj "\(K_j\)"
label var Hj "\(H_j\)"


******************************* TABLE C.4 *********************************

// Column 1

est clear 

reg sales_pw Sj avg_soph_high i.a5a i.countrycode [pw=base_wt]
estadd local SectorFE "Yes"
estadd local CountryFE "Yes"
est store lin1

reg sales_pw Sj_1 Sj_2 Sj_3 Sj_4  i.a5a i.countrycode [pw=base_wt]
estadd local SectorFE "Yes"
estadd local CountryFE "Yes"
est store lin2

reg sales_pw Kj Hj Sj avg_soph_high i.a5a i.countrycode [pw=base_wt]
estadd local SectorFE "Yes"
estadd local CountryFE "Yes"
est store lin3

reg sales_pw Kj Hj Sj_1 Sj_2 Sj_3 Sj_4 i.a5a i.countrycode [pw=base_wt]
estadd local SectorFE "Yes"
estadd local CountryFE "Yes"
est store lin4

reg u_solow Sj avg_soph_high i.a5a i.countrycode [pw=base_wt]
estadd local SectorFE "Yes"
estadd local CountryFE "Yes"
est store lin5

reg u_solow Sj_1 Sj_2 Sj_3 Sj_4 i.a5a i.countrycode [pw=base_wt]
estadd local SectorFE "Yes"
estadd local CountryFE "Yes"
est store lin6


esttab lin* using "${path_output}/table_C4.tex", replace label s(N r2 SectorFE CountryFE, label("N" "R-squared" "Sector FE" "Country FE") fmt("%4.0f" "%4.2f")) star(* 0.1 ** 0.05 *** 0.01) b("%4.2f") se("%4.2f") drop(*.a5a *.countrycode) nobase prehead("\begin{table}[htbp]\centering \def\sym#1{\ifmmode^{#1}\else\(^{#1}\)\fi} \caption{Productivity and Sophistication: Non-Linearities} \label{tab:} \resizebox{0.7\textwidth}{!}{ \begin{tabular}{l*{6}{c}}\hline\hline \\ &\multicolumn{4}{c}{ln(Sales per worker)} &\multicolumn{2}{c}{TFP}  \\ \\  \cmidrule(lr){2-5} \cmidrule(lr){6-7} \\") postfoot("\hline \hline \end{tabular}} \begin{minipage}{16cm} \vspace{0.1cm} \vspace{0.1cm}\scriptsize  Note: D(.) are binary variables that take the value 1 if the establishment satisfies the condition in parenthesis and 0 otherwise. High Sophistication represents that the establishment has above-median $\overlone{S}_j$. TFP is measured by the Solow residual. See details about its calculation in the paper. All regressions are estimated using establishment-level sampling weights *, ** and *** denote 10\%, 5\% and 1\% significance, respectively. \end{minipage} \end{table}") eqlabels(none) nomtitle collabels(none) substitute(\_ _) 



******************************* TABLE C.7 *********************************

// columns 1 & 2
est clear 
reg sales_pw Kj Hj Sj i.a5a i.countrycode  [pw=base_wt]
estadd local SectorFE "Yes"
estadd local CountryFE "Yes"
estadd local Data "All"
est store soph1
reg sales_pw Kj Hj Sj i.a5a [pw=base_wt]
estadd local SectorFE "Yes"
estadd local CountryFE "No"
estadd local Data "All"
est store soph2

// columns 3 & 4
reg sales_pw Sj i.a5a i.countrycode  [pw=base_wt]
estadd local SectorFE "Yes"
estadd local CountryFE "Yes"
estadd local Data "All"
est store soph3
reg sales_pw Sj i.a5a [pw=base_wt]
estadd local SectorFE "Yes"
estadd local CountryFE "No"
estadd local Data "All"
est store soph4

// columns 5 & 6
reg sales_pw Kj Hj MOST_bus_fn MAX_bus_fn i.a5a i.countrycode  [pw=base_wt]
estadd local SectorFE "Yes"
estadd local CountryFE "Yes"
estadd local Data "All"
est store soph5
reg sales_pw Kj Hj MOST_bus_fn MAX_bus_fn i.a5a [pw=base_wt]
estadd local SectorFE "Yes"
estadd local CountryFE "No"
estadd local Data "All"
est store soph6

// columns 7 & 8 
reg sales_pw MOST_bus_fn MAX_bus_fn i.a5a i.countrycode  [pw=base_wt]
estadd local SectorFE "Yes"
estadd local CountryFE "Yes"
estadd local Data "All"
est store soph7
reg sales_pw MOST_bus_fn MAX_bus_fn i.a5a [pw=base_wt]
estadd local SectorFE "Yes"
estadd local CountryFE "No"
estadd local Data "All"
est store soph8

// columns 9 & 10
reg profit_rate Sj i.a5a i.countrycode if profit_w == 1  [pw=base_wt]
estadd local SectorFE "Yes"
estadd local CountryFE "Yes"
estadd local Data "All"
est store soph9
reg profit_rate Sj i.a5a  if profit_w == 1  [pw=base_wt]
estadd local SectorFE "Yes"
estadd local CountryFE "No"
estadd local Data "All"
est store soph10

// columns 11 & 12
reg profit_rate MOST_bus_fn MAX_bus_fn i.a5a i.countrycode if profit_w == 1 [pw=base_wt]
estadd local SectorFE "Yes"
estadd local CountryFE "Yes"
estadd local Data "All"
est store soph11
reg profit_rate MOST_bus_fn MAX_bus_fn i.a5a  if profit_w == 1  [pw=base_wt]
estadd local SectorFE "Yes"
estadd local CountryFE "No"
estadd local Data "All"
est store soph12

// columns 13 & 14
reg u_solow Sj i.a5a i.countrycode  [pw=base_wt]
estadd local SectorFE "Yes"
estadd local CountryFE "Yes"
estadd local Data "All"
est store soph13
reg u_solow Sj i.a5a [pw=base_wt]
estadd local SectorFE "Yes"
estadd local CountryFE "No"
estadd local Data "All"
est store soph14

// columns 15 & 16
reg u_solow MOST_bus_fn MAX_bus_fn i.a5a i.countrycode  [pw=base_wt]
estadd local SectorFE "Yes"
estadd local CountryFE "Yes"
estadd local Data "All"
est store soph15
reg u_solow MOST_bus_fn MAX_bus_fn i.a5a [pw=base_wt]
estadd local SectorFE "Yes"
estadd local CountryFE "No"
estadd local Data "All"
est store soph16


esttab soph* using "${path_output}/table_C7.tex", replace label s(N r2 SectorFE CountryFE Data, label("N" "R-squared" "Sector FE" "Country FE" "Data" ) fmt("%4.0f" "%4.2f")) star(* 0.1 ** 0.05 *** 0.01) b("%4.2f") se("%4.2f") drop(*.a5a *.countrycode) nobase prehead("\begin{landscape} \begin{table}[htbp]\centering \def\sym#1{\ifmmode^{#1}\else\(^{#1}\)\fi} \caption{Productivity and Sophistication} \label{tab:prod_table12} \resizebox{1.2\textwidth}{!}{ \begin{tabular}{l*{16}{c}}\hline\hline \\ &\multicolumn{8}{c}{ln(Sales per worker)} &\multicolumn{4}{c}{Profit Rate} &\multicolumn{4}{c}{TFP}  \\ \\  \cmidrule(lr){2-9} \cmidrule(lr){10-13} \cmidrule(lr){14-17} \\") postfoot("\hline \hline \end{tabular}} \begin{minipage}{16cm} \vspace{0.1cm} \vspace{0.1cm}\scriptsize Note: Profit Rate is the share of profits in total sales, TFP is the Solow residual. See the text for details. $\overline{S}_j$ is the simple average of $MAX_j$ and $MOST_j$. Regressions with Profit rates as dependent variables have a restricted sample to establishments between the $2^{nd}$ and $98^{th}$ percentiles of profit rate distribution. *, ** and *** denote 10\%, 5\% and 1\% significance respectively. \end{minipage} \end{table} \end{landscape}") eqlabels(none) nomtitle collabels(none) substitute(\_ _) 


******************************* TABLE C.8 *********************************
est clear

reg sales_pw Kj Hj Sj i.a5a i.countrycode if sector==1  [pw=base_wt]
estadd local SectorFE "Yes"
estadd local CountryFE "Yes"
estadd local Data "Agri."
est store sectors1
reg sales_pw Kj Hj Sj i.a5a if sector==1 [pw=base_wt]
estadd local SectorFE "Yes"
estadd local CountryFE "No"
estadd local Data "Agri."
est store sectors2

reg sales_pw Kj Hj Sj i.a5a i.countrycode if sector==2  [pw=base_wt]
estadd local SectorFE "Yes"
estadd local CountryFE "Yes"
estadd local Data "Manu."
est store sectors3
reg sales_pw Kj Hj Sj i.a5a if sector==2 [pw=base_wt]
estadd local SectorFE "Yes"
estadd local CountryFE "No"
estadd local Data "Manu."
est store sectors4

reg sales_pw Kj Hj Sj i.a5a i.countrycode if sector==3  [pw=base_wt]
estadd local SectorFE "Yes"
estadd local CountryFE "Yes"
estadd local Data "Serv."
est store sectors5
reg sales_pw Kj Hj Sj i.a5a if sector==3 [pw=base_wt]
estadd local SectorFE "Yes"
estadd local CountryFE "No"
estadd local Data "Serv."
est store sectors6

reg sales_pw Sj i.a5a i.countrycode if sector==1  [pw=base_wt]
estadd local SectorFE "Yes"
estadd local CountryFE "Yes"
estadd local Data "Agri."
est store sectors7
reg sales_pw Sj i.a5a if sector==1 [pw=base_wt]
estadd local SectorFE "Yes"
estadd local CountryFE "No"
estadd local Data "Agri."
est store sectors8

reg sales_pw Sj i.a5a i.countrycode if sector==2  [pw=base_wt]
estadd local SectorFE "Yes"
estadd local CountryFE "Yes"
estadd local Data "Manu."
est store sectors9
reg sales_pw Sj i.a5a if sector==2 [pw=base_wt]
estadd local SectorFE "Yes"
estadd local CountryFE "No"
estadd local Data "Manu."
est store sectors10

reg sales_pw Sj i.a5a i.countrycode if sector==3  [pw=base_wt]
estadd local SectorFE "Yes"
estadd local CountryFE "Yes"
estadd local Data "Serv."
est store sectors11
reg sales_pw Sj i.a5a if sector==3 [pw=base_wt]
estadd local SectorFE "Yes"
estadd local CountryFE "No"
estadd local Data "Serv."
est store sectors12

reg u_solow Sj i.a5a i.countrycode if sector==1  [pw=base_wt]
estadd local SectorFE "Yes"
estadd local CountryFE "Yes"
estadd local Data "Agri."
est store sectors13
reg u_solow Sj i.a5a if sector==1 [pw=base_wt]
estadd local SectorFE "Yes"
estadd local CountryFE "No"
estadd local Data "Agri."
est store sectors14

reg u_solow Sj i.a5a i.countrycode if sector==2  [pw=base_wt]
estadd local SectorFE "Yes"
estadd local CountryFE "Yes"
estadd local Data "Manu."
est store sectors15
reg u_solow Sj i.a5a if sector==2 [pw=base_wt]
estadd local SectorFE "Yes"
estadd local CountryFE "No"
estadd local Data "Manu."
est store sectors16

reg u_solow Sj i.a5a i.countrycode if sector==3  [pw=base_wt]
estadd local SectorFE "Yes"
estadd local CountryFE "Yes"
estadd local Data "Serv."
est store sectors17
reg u_solow Sj i.a5a if sector==3 [pw=base_wt]
estadd local SectorFE "Yes"
estadd local CountryFE "No"
estadd local Data "Serv."
est store sectors18

esttab sectors* using "${path_output}/table_C8.tex", replace label s(N r2 SectorFE CountryFE Data, label("N" "R-squared" "Sector FE" "Country FE" "Data" ) fmt("%4.0f" "%4.2f")) star(* 0.1 ** 0.05 *** 0.01) b("%4.2f") se("%4.2f") drop(*.a5a *.countrycode) nobase prehead("\begin{landscape} \begin{table}[htbp]\centering \def\sym#1{\ifmmode^{#1}\else\(^{#1}\)\fi} \caption{Productivity and Sophistication: Sectoral Distribution} \label{tab:} \resizebox{1.2\textwidth}{!}{ \begin{tabular}{l*{18}{c}}\hline\hline \\ &\multicolumn{14}{c}{ln(Sales per worker)} &\multicolumn{4}{c}{TFP}  \\ \\   \cmidrule(lr){2-15} \cmidrule(lr){16-19} \\") postfoot("\hline \hline \end{tabular}} \begin{minipage}{16cm} \vspace{0.1cm} \vspace{0.1cm}\scriptsize Profit Rate is the share of profits in total sales, TFP is the Solow residual. See the text for details. $\overline{S}_j$ is the simple average of $MAX_j$ and $MOST_j$. Agri., Manu. and Serv. refer to the samples of establishments in agriculture, manufacturing and services 1-digit sectors. Regressions with Profit rates as dependent variables have restricted sample to establishments between the $2^{nd}$ and $98^{th}$ percentiles of profit rate distribution. Note: *, ** and *** denote 10\%, 5\% and 1\% significance respectively. \end{minipage} \end{table} \end{landscape}") eqlabels(none) nomtitle collabels(none) substitute(\_ _) 



******************************* TABLE C.9 *********************************
est clear

reg sales_pw Kj Hj Sj Sj_rich i.a5a i.countrycode [pw=base_wt]
estadd local SectorFE "Yes"
estadd local CountryFE "Yes"
estadd local Data "All"
est store countries1

reg sales_pw Kj Hj Sj i.a5a i.countrycode if rich==1 [pw=base_wt]
estadd local SectorFE "Yes"
estadd local CountryFE "Yes"
estadd local Data "Rich Countries"
est store countries2

reg sales_pw Kj Hj Sj i.a5a i.countrycode if rich==0 [pw=base_wt]
estadd local SectorFE "Yes"
estadd local CountryFE "Yes"
estadd local Data "Poor Countries"
est store countries3

reg sales_pw Sj Sj_rich i.a5a i.countrycode [pw=base_wt]
estadd local SectorFE "Yes"
estadd local CountryFE "Yes"
estadd local Data "All"
est store countries4

reg sales_pw Sj i.a5a i.countrycode if rich==1 [pw=base_wt]
estadd local SectorFE "Yes"
estadd local CountryFE "Yes"
estadd local Data "Rich Countries"
est store countries5

reg sales_pw Sj i.a5a i.countrycode if rich==0 [pw=base_wt]
estadd local SectorFE "Yes"
estadd local CountryFE "Yes"
estadd local Data "Poor Countries"
est store countries6

reg profit_rate Sj Sj_rich i.a5a i.countrycode if profit_w == 1 [pw=base_wt]
estadd local SectorFE "Yes"
estadd local CountryFE "Yes"
estadd local Data "All"
est store countries7

reg profit_rate Sj i.a5a i.countrycode if profit_w == 1 & rich==1 [pw=base_wt]
estadd local SectorFE "Yes"
estadd local CountryFE "Yes"
estadd local Data "Rich Countries"
est store countries8

reg profit_rate Sj i.a5a i.countrycode if profit_w == 1 & rich==0 [pw=base_wt]
estadd local SectorFE "Yes"
estadd local CountryFE "Yes"
estadd local Data "Poor Countries"
est store countries9

reg u_solow Sj Sj_rich i.a5a i.countrycode [pw=base_wt]
estadd local SectorFE "Yes"
estadd local CountryFE "Yes"
estadd local Data "All"
est store countries10

reg u_solow Sj i.a5a i.countrycode if rich==1 [pw=base_wt]
estadd local SectorFE "Yes"
estadd local CountryFE "Yes"
estadd local Data "Rich Countries"
est store countries11

reg u_solow Sj i.a5a i.countrycode if rich==0 [pw=base_wt]
estadd local SectorFE "Yes"
estadd local CountryFE "Yes"
estadd local Data "Poor Countries"
est store countries12


esttab countries* using "${path_output}/table_C9.tex", replace label s(N r2 SectorFE CountryFE Data, label("N" "R-squared" "Sector FE" "Country FE" "Data" ) fmt("%4.0f" "%4.2f")) star(* 0.1 ** 0.05 *** 0.01) b("%4.2f") se("%4.2f") drop(*.a5a *.countrycode) nobase prehead("\begin{landscape} \begin{table}[htbp]\centering \def\sym#1{\ifmmode^{#1}\else\(^{#1}\)\fi} \caption{Productivity and Sophistication: Sectoral Distribution} \label{tab:} \resizebox{1.2\textwidth}{!}{ \begin{tabular}{l*{12}{c}}\hline\hline \\ &\multicolumn{6}{c}{ln(Sales per worker)} &\multicolumn{3}{c}{Profit Rate} &\multicolumn{3}{c}{TFP}  \\ \\   \cmidrule(lr){2-7} \cmidrule(lr){8-10} \cmidrule(lr){11-13} \\") postfoot("\hline \hline \end{tabular}} \begin{minipage}{16cm} \vspace{0.1cm} \vspace{0.1cm}\scriptsize Note: Profit Rate is the share of profits in total sales, TFP is the Solow residual. See the text for details. $\overline{S}_j$ is the simple average of $MAX_j$ and $MOST_j$. $D(High-income)$ is a dummy variable that takes the value of 1 if country is high-income (South Korea, Poland and Croatia), and 0 otherwise. Regressions with Profit rates as dependent variables have restricted sample to establishments between the $2^{nd}$ and $98^{th}$ percentiles of profit rate distribution. *, ** and *** denote 10\%, 5\% and 1\% significance respectively.  For the profit rate, we drop the top and bottom 2\%. \end{minipage} \end{table} \end{landscape}") eqlabels(none) nomtitle collabels(none) substitute(\_ _) 



