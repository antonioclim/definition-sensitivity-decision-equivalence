//DIRECTORIES

set more off
clear *
set maxvar 12000


***************************************************************************
******************************** TABLE 2 **********************************
***************************************************************************

//////Table 2 prepare - Number of establishments in the sample, by sector and size groups
// load datasets
use "${path_import}/FAT0_reshaped_firm_busfn_updated_new.dta", clear

collapse a5a, by(firmid country size_group)

gen sector = 1 if a5a == 1 | a5a == 2
replace sector = 2 if a5a == 3 | a5a == 4 | a5a == 5 | a5a == 6 | a5a == 11 | a5a == 101
replace sector = 3 if a5a == 102 | a5a == 7 | a5a == 8 | a5a == 9 | a5a == 10 

tabulate sector, generate(sector_)
	
tabulate size_group, generate(size)

gen total_firms = 1

collapse (sum) total_firms sector_* size*, by(country)

drop size_group

foreach var of varlist total_firms sector_1 sector_2 sector_3 size1 size2 size3 {
	replace `var' = . if `var' == 0
}

gen overall = 1
save "${path_import}/FAT0 data/table2.dta", replace

collapse (sum) total_firms sector* size*
gen country = "Total" 
gen overall = 2

append using "${path_import}/FAT0 data/table2.dta"
sort overall country
drop overall
order country total_firms sector* size*

	
global table2_notes "Notes : This table displays the sampling distribution of all establishments across countries by sector (Agriculture, Manufacturing, and Services) and firm size groups: Small (5-19 workers), Medium (20-99 workers), and Large (100+ workers).* Brazil refers to the states of Ceará, Paraná, and São Paulo. ** States of Tamil Nadu, Uttar Pradesh, Gujarat, and Maharashtra in India. The survey does not cover agriculture or services in Bangladesh, nor agriculture in Cambodia. In India, only the states of Gujarat and Maharashtra have agriculture included in the survey."
* 

foreach var of varlist total_firms sector* size1 size2 size3 {
    gen n_`var' = string(`var',"%4.0f") 
	drop `var'
	rename n_`var' `var'
	replace `var' = "" if `var' == "."
	replace `var' = "\textbf{" + `var' + "}" if country == "Total"
}

replace country = "\textbf{Total}" if country == "Total"
replace country = "India**" if country == "India" 
replace country = "Brazil*" if country == "Brazil" 


label var total_firms "\textbf{Total}"
label var sector_1 "\textbf{Agri.}"
label var sector_2 "\textbf{Manu.}"
label var sector_3 "\textbf{Serv.}"
label var size1 "\textbf{Small}"
label var size2 "\textbf{Medium}"
label var size3 "\textbf{Large}"


//enter table 1 directly in the file by copying the texfile 
texsave using "${path_output}/1_latex_tables/table_2.tex", hlines(15 16) replace title(Number of establishments in the sample, by sector and size groups) varlabels footnote("${table2_notes}") valuelabels nofix label("tab:country_dist")


***************************************************************************
******************************** TABLE 3 **********************************
***************************************************************************

use "${path_import}/FAT0_reshaped_firm_busfn_consolidated.dta", clear
drop if anum_bus_fn == . | MAX_bus_fn_q == . 
replace MOST_bus_fn = . if MOST_bus_fn == 0
gen sales_pw = ln(sales) - ln(tot_emp)
gen Hj = e5d/100


collapse MAX_bus_fn* MOST_bus_fn*, by(firmid base_wt a5a sales_pw Hj)

rename MAX_bus_fn MAX_bus_fn_b
rename MOST_bus_fn MOST_bus_fn_b

reg sales_pw i.a5a [pw=base_wt]
predict sales_r, resid

reg Hj i.a5a [pw=base_wt]
predict H_r, resid


global types "b q"


foreach var of global types {
	
	//MOST 
	reg MOST_bus_fn_`var' i.a5a  [pw=base_wt]
	predict most_r_`var', resid
	corr most_r_`var' sales_r [aw=base_wt]
	gen sales_most_`var' = `r(rho)'
	corr most_r_`var' H_r [aw=base_wt]
	gen h_most_`var' = `r(rho)'
	
	//MAX
	reg MAX_bus_fn_`var' i.a5a  [pw=base_wt]
	predict max_r_`var', resid
	corr max_r_`var' sales_r [aw=base_wt]
	gen sales_max_`var' = `r(rho)'
	corr max_r_`var' H_r [aw=base_wt]
	gen h_max_`var' = `r(rho)'
	
}

// save the b-q correlations
corr most_r_b most_r_q [aw=base_wt]
gen most_b_q = `r(rho)'

corr max_r_b max_r_q [aw=base_wt]
gen max_b_q = `r(rho)'

collapse sales_* h_* most_b_q max_b_q
drop sales_pw sales_r

save "${path_output}/table_3.dta", replace
// making a latex table with the results
foreach v in sales_most_b sales_max_b sales_most_q sales_max_q ///
             h_most_b h_max_b h_most_q h_max_q most_b_q max_b_q {
    quietly summarize `v'
    local `v' = r(mean)
}
* Create a matrix in desired table order
file open tex using "${path_output}/1_latex_tables/table_3.tex", write replace
file write tex ///
"{\begin{table}[htbp]" _n ///
"\centering" _n ///
"\caption{Comparison of baseline and Q-measures of technology sophistication}" _n ///
"\begin{tabular}{lcccc}" _n ///
"\hline\hline" _n ///
"& \$MAX_j\$ & \$MOST_j\$ & \$H_j\$ & \$\log(\text{Sales per Worker})\$ \\" _n ///
"\hline" _n ///
"\$MAX_j^Q\$ & `=string(max_b_q,"%4.2f")' & . & `=string(h_max_q,"%4.2f")' & `=string(sales_max_q,"%4.2f")' \\" _n ///
"\$MAX_j\$ & . & . & `=string(h_max_b,"%4.2f")' & `=string(sales_max_b,"%4.2f")' \\" _n ///
"\$MOST_j^Q\$ & . & `=string(most_b_q,"%4.2f")' & `=string(h_most_q,"%4.2f")' & `=string(sales_most_q,"%4.2f")' \\" _n ///
"\$MOST_j\$ & . & . & `=string(h_most_b,"%4.2f")' & `=string(sales_most_b,"%4.2f")' \\" _n ///
"\hline\hline" _n ///
"\end{tabular}" _n ///
"\end{table}}" _n
file close tex




***************************************************************************
******************************** TABLE 4 **********************************
***************************************************************************

use "${path_import}/FAT0_reshaped_firm_busfn_updated_new.dta", clear
drop if anum_bus_fn == . 
replace MOST_bus_fn = . if MOST_bus_fn == 0
tab anum_bus_fn
drop if a5a != sector & sector != .
drop if MAX_bus_fn < MOST_bus_fn
drop if MOST_bus_fn < 1 


//generate adjusted weights
gen non_missing_bf = 1 if anum_bus_fn != .
replace non_missing_bf = 0 if non_missing_bf == .

bysort firmid : egen tot_bf = total(non_missing_bf)


reghdfe MOST_bus_fn [pw=base_wt], absorb(i.bus_fn i.firmid) vce(cluster i.firmid) resid
predict double most, residuals

reghdfe MAX_bus_fn [pw=base_wt], absorb(i.bus_fn i.firmid) vce(cluster i.firmid) resid
predict double max, residuals

reghdfe num_r_bus_fn [pw=base_wt], absorb(i.bus_fn i.firmid) vce(cluster i.firmid) resid
predict double num, residuals

reg most max [pw=base_wt]
gen r2_1 = `e(r2)'

reg max num [pw=base_wt]
gen r2_2 = `e(r2)'

reg most num [pw=base_wt]
gen r2_3 = `e(r2)'


reghdfe MOST_bus_fn MAX_bus_fn [pw=base_wt], absorb(i.bus_fn i.firmid) vce(cluster i.firmid)
estadd local BF "Y"
estadd local firm "Y"
estadd scalar r21 = r2_1
est store table4_1 

reghdfe MAX_bus_fn num_r_bus_fn [pw=base_wt], absorb(i.bus_fn i.firmid) vce(cluster i.firmid)
estadd local BF "Y"
estadd local firm "Y"
estadd scalar r21 = r2_2
est store table4_2 

reghdfe MOST_bus_fn num_r_bus_fn [pw=base_wt], absorb(i.bus_fn i.firmid) vce(cluster i.firmid)
estadd local BF "Y"
estadd local firm "Y"
estadd scalar r21 = r2_3
est store table4_3


label var MAX_bus_fn "\(MAX_{f,j}\)"
label var MOST_bus_fn "\(MOST_{f,j}\)"
label var num_r_bus_fn "\(NUM_{f,j}\)"

global table4_notes "Notes: This table reports the regression estimates of specifications \ref{MOSTMAX}, \ref{MAXNUM}, and \ref{MOSTNUM}. To compute the last row, we first residualize the dependent and independent variables by regressing them on the fixed effects, and then we regress the residuals of the dependent on those of the independent. The reported number is the corresponding \(R^2\). Regressions are estimated using establishment-level sampling weights. Standard errors are clustered at the establishment level. *, ** and *** denote 10\%, 5\% and 1\% significance respectively. *, ** and *** denote 10\%, 5\% and 1\% significance respectively."

esttab table4* using "${path_output}/1_latex_tables/table_4.tex", drop(_cons) replace label s(N r2 BF firm r21, label("N" "R-squared" "BF FE" "Firm FE" "Variation Explained") fmt(%4.0f %4.2f)) star(* 0.1 ** 0.05 *** 0.01) b(%4.2f) se(%4.2f) nobase title() prehead("\begin{table}[htbp]\centering \def\sym#1{\ifmmode^{#1}\else\(^{#1}\)\fi} \caption{Relationship between technology measures}  \label{tab:most_max_num_reg} \begin{tabular}{l*{4}{c}}\hline\hline \\") postfoot("\hline \hline \end{tabular} \begin{minipage}{12cm} \vspace{0.1cm} \vspace{0.1cm}\footnotesize ${table4_notes} *, ** and *** denote 10\%, 5\% and 1\% significance respectively. \end{minipage} \end{table}") substitute(\_ _) nonum



***************************************************************************
******************************** TABLE 5 **********************************
***************************************************************************
use "${path_import}/FAT0_firm_level.dta", clear

gen rich_country=0 if countrycode!=.
replace rich_country=1 if (countrycode==6 | countrycode==12 | countrycode==13)

collapse max_g_most MAX_bus_fn MOST_bus_fn [aw=base_wt], by(fage rich_country)
drop if fage == .
reshape wide max_g_most MAX_bus_fn MOST_bus_fn, i(fage) j(rich_country)

// NEED TO FORMAT IN LATEX 0 is poor 1 is rich
order fage max_g_most* MAX* MOST*

save "${path_output}/table_5.dta", replace
gen age_cat = ""
replace age_cat ="<=5" if fage==1
replace age_cat ="6-10" if fage==2
replace age_cat ="11-15" if fage==3
replace age_cat =">=16" if fage==4

// make the latex table with these results
file open tex using "${path_output}\1_latex_tables\table_5.tex", write replace
file write tex ///
"\begin{table}[htbp]" _n ///
"\centering" _n ///
"\caption{Average GAP, MAX, and MOST, by age and country income groups}" _n ///
"\begin{tabular}{lcccccc}" _n ///
"\hline\hline" _n ///
"& \multicolumn{2}{c}{GAP} & \multicolumn{2}{c}{MAX} & \multicolumn{2}{c}{MOST} \\" _n ///
"\cmidrule(lr){2-3} \cmidrule(lr){4-5} \cmidrule(lr){6-7}" _n ///
"Age Group & Poor & Rich & Poor & Rich & Poor & Rich \\" _n ///
"\hline" _n

quietly {
    forvalues i = 1/`=_N' {
        local age = age_cat[`i']
        local g0 = max_g_most0[`i']
        local g1 = max_g_most1[`i']
        local m0 = MAX_bus_fn0[`i']
        local m1 = MAX_bus_fn1[`i']
        local most0 = MOST_bus_fn0[`i']
        local most1 = MOST_bus_fn1[`i']

        file write tex ///
        "`age' & `=string(`g0',"%4.2f")' & `=string(`g1',"%4.2f")' & " ///
        "`=string(`m0',"%4.2f")' & `=string(`m1',"%4.2f")' & " ///
        "`=string(`most0',"%4.2f")' & `=string(`most1',"%4.2f")' \\" _n
    }
}
file write tex "\hline\hline" _n
file write tex "\footnotesize Notes: Averages of \emph{GAP}, \emph{MAX}, and \emph{MOST}, across establishments in specific age and country groups. Averages computed using establishment-level sampling weights." _n
file write tex "\end{tabular}" _n
file write tex "\end{table}" _n
file close tex


***************************************************************************
******************************** TABLE 6 **********************************
***************************************************************************

use "${path_import}/FAT0_firm_level.dta", clear

//LOAN REJECTION VARIABLE
gen loan_rejected = 1 if d3c > 0
replace loan_rejected = 0 if d3c == 0

//BIAS VARIABLE
gen scaled_perceptions = 1+4/9*(b7b-1)
gen misperception_gaps = scaled_perceptions - avg_max_most

//variables for deciles = age, misperception_gaps, sales_pw, mgt_z, ln_emp, Hj 
foreach var of varlist age misperception_gaps sales_pw mgt_z ln_emp Hj {
    
    xtile decile_`var' = `var' [aw=base_wt], nq(10)
    
    forvalues i = 1/10 {
        
        // Define the gap variable only if decile i has observations
        quietly summarize max_g_most [aw=base_wt] if decile_`var' == `i'
        if r(N) > 0 {
            gen gap_`var'_`i' = r(mean)
        }
        else {
            gen gap_`var'_`i' = 0
        }
        
        quietly summarize `var' [aw=base_wt] if decile_`var' == `i'
        if r(N) > 0 {
            gen mean_`var'_`i' = r(mean)
        }
        else {
            gen mean_`var'_`i' = 0
        }

 
    }
	
	corr `var' max_g_most [aw=base_wt]
	gen overall_corr_`var' = `r(rho)'
	
	
}


//define the p1-p10
collapse gap* mean* overall*


//
global variables "age misperception_gaps sales_pw mgt_z ln_emp Hj"

//
gen i = 1

reshape long gap_age_ gap_misperception_gaps_ gap_sales_pw_ gap_mgt_z_ gap_ln_emp_ gap_Hj_ mean_age_ mean_misperception_gaps_ mean_sales_pw_ mean_mgt_z_ mean_ln_emp_ mean_Hj_, i(i) j(decile)

//gen the summary rows
foreach var of global variables {
	
	gen diff_p_`var' = gap_`var'_[10] - gap_`var'_[1]
	
	corr mean_`var'_ gap_`var'_ 
	gen bcorr_`var' = `r(rho)'
		
}
drop mean_*
save "${path_output}/1_latex_tables/table6_deciles_1.dta", replace


////////////////////// TABLE 6 PANEL 2

use "${path_import}/FAT0_firm_level.dta", clear

gen fam_bus=0 if a4b!=.
replace fam_bus=1 if a4b!=. & (a4b==1 | a4b==2)

//LOAN REJECTION VARIABLE
gen loan_rejected = 1 if d3c > 0
replace loan_rejected = 0 if d3c == 0

//variables for 0/1 = exporter, mnc, fam_bus, loan_rejected

foreach var of varlist exporter mnc fam_bus loan_rejected {
 
	//
	sum max_g_most [aw=base_wt] if `var' == 0
	gen gap0_`var' = `r(mean)'
	
	sum max_g_most [aw=base_wt] if `var' == 1
	gen gap1_`var' = `r(mean)'

	gen gap1m0`var' = gap1_`var' - gap0_`var'
	
	corr `var' max_g_most [aw=base_wt]
	gen overall_corr_`var' = `r(rho)'
	
}

collapse gap* overall*
gen i = 1
reshape long gap1_ gap0_ gap1m0 overall_corr_, i(i) j(variable) string

save "${path_output}/1_latex_tables/table6_deciles_2.dta", replace


// making the latex table
use "${path_output}\1_latex_tables\table6_deciles_1.dta", clear

*------------------------------------------------------------*
* Step 1: Define variables and column labels
*------------------------------------------------------------*
local vars age  sales_pw  ln_emp Hj mgt_z misperception_gaps
local varlabels "Age &"  "Productivity &"  "Size &" "\(H_j\) &" "Manag. &" "Bias"

*------------------------------------------------------------*
* Step 2: Open LaTeX file
*------------------------------------------------------------*
file open tex using "${path_output}\1_latex_tables\table_6.tex", write replace
file write tex ///
"\begin{table}[htbp]" _n ///
"\centering" _n ///
"\caption{Average MAX–MOST gap across establishment distribution across observable characteristics}" _n
file write tex "\begin{tabular}{lcccccc}\\%" _n
file write tex "\hline\\%" _n
file write tex "Decile & `varlabels' \\\%" _n
file write tex "\hline\\%" _n

*------------------------------------------------------------*
* Step 3: Write decile rows (1–10)
*------------------------------------------------------------*
quietly {
    levelsof decile, local(decs)
    foreach d of local decs {
        file write tex "`d'"
        foreach v of local vars {
            local val = string(gap_`v'[`d'], "%4.2f")
            file write tex " & `val'"
        }
        file write tex " \\\%" _n
    }
}

file write tex "\hline\\%" _n

*------------------------------------------------------------*
* Step 4: Add P10–P1 (from diff_p_* variables)
*------------------------------------------------------------*
file write tex "P10–P1"
foreach v of local vars {
    local val = string(diff_p_`v'[1], "%4.2f")
    file write tex " & `val'"
}
file write tex " \\\%" _n

*------------------------------------------------------------*
* Step 5: Add Overall Corr. (from overall_corr_* variables)
*------------------------------------------------------------*
file write tex "Overall Corr."
foreach v of local vars {
    local val = string(overall_corr_`v'[1], "%4.2f")
    file write tex " & `val'"
}
file write tex " \\\%" _n

*------------------------------------------------------------*
* Step 6: Add Between Corr. (from bcorr_* variables)
*------------------------------------------------------------*
file write tex "Between Corr."
foreach v of local vars {
    local val = string(bcorr_`v'[1], "%4.2f")
    file write tex " & `val'"
}
file write tex " \\\%" _n

file write tex "\hline\\%" _n

//// Second panel
use "${path_output}\1_latex_tables\table6_deciles_2.dta", clear
* Keep only variables of interest
keep variable  gap1_ gap0_ gap1m0 overall_corr_

* Step 1: Save variable order
levelsof variable, local(cols)

* Step 2: Drop variable column for transposing
drop variable

* Step 3: Transpose
xpose, clear varname
rename _varname metric

* Step 4: Assign column names based on saved list
local i = 1
foreach c of local cols {
    local newname : word `i' of `cols'
    rename v`i' `newname'
    local ++i
}
list

replace metric = "1" if metric == "gap1_"
replace metric = "0" if metric == "gap0_"
replace metric = "D(1)–D(0)" if metric == "gap1m0"
replace metric = "Overall Corr." if metric == "overall_corr_"

****************************************************
* 7. Export to LaTeX
****************************************************

file write tex " & Exporter & MNC & Family  & Loan Reject. &  & \\" _n
file write tex "\hline" _n

quietly forvalues i = 1/4 {
    // Get values from the i-th observation
    local row_metric = metric in `i'
    local v1 = exporter in `i'
    local v2 = fam_bus in `i'
    local v3 = loan_rejected in `i'
    local v4 = mnc in `i'

    // Write to LaTeX file with formatting
    file write tex "`row_metric' & " ///
        "`=string(`v1', "%6.2f")' & " ///
        "`=string(`v4', "%6.2f")' & " ///
        "`=string(`v2', "%6.2f")' & " ///
        "`=string(`v3', "%6.2f")' & &\\" _n
}

file write tex "\hline" _n
file write tex "\end{tabular}" _n
file write tex "\vspace{0.5em}" 
file write tex "\begin{minipage}{0.9\textwidth}"
file write tex "\footnotesize \textit{Notes:} Notes: This table displays the average MAX-MOST gap across the establishments in a decile of the distribution of each variable in the columns. Productivity is log sales per worker. Employment is the total number of workers. Human capital is the share of workers with a college degree. Manag. is the z-score for management practices. Age is the age of the establishment. Exporter, MNC, Family and Loan Reject. are binary variables that take the value of 1 if establishment is exporter, part of a multinational corporation, a family business and if a loan application has been rejected. P10-P1 is the difference between the average in the tenth and first deciles. Overall Corr is the correlation between GAP\(_j)\ and the variable in the column across establishments. Between Corr is the correlation across deciles of GAP\(_j)\ and the variable in the column. All statistics computed using establishment sampling weights."
file write tex "\end{minipage}"
file write tex "\end{table}" _n
file close tex


***************************************************************************
******************************** TABLE 7 **********************************
***************************************************************************
use "${path_import}/FAT0_firm_level.dta", clear
*use "${path_import}/FAT0_firm_level_harmonized.dta", clear

gen rich_country=0 if countrycode!=.
replace rich_country=1 if (countrycode==6 | countrycode==12 | countrycode==13)


* Define value labels for rich_country
label define rich_lbl 0 "Poor Country" 1 "Rich Country"
label values rich_country rich_lbl


fvset base 1 size_group     // assuming 3 = Large
fvset base 0 rich_country   // assuming 0 = not rich country

label var MOST_bus_fn "\(MOST_j\)"
label var MAX_bus_fn "\(MAX_j\)"
label var s4 "Multi-establishment"
label var mnc "Foreign owned"
label var exporter "Exporter"
label var Hj "\(H_j\)"
label var mgt_z "Management (Z-Score)"


//LOAN REJECTION VARIABLE
gen loan_rejected = 1 if d3c > 0
replace loan_rejected = 0 if d3c == 0

//BIAS VARIABLE
gen scaled_perceptions = 1+4/9*(b7b-1)
gen misperception_gaps = scaled_perceptions - avg_max_most

gen fam_bus=0 if a4b!=.
replace fam_bus=1 if a4b!=. & (a4b==1 | a4b==2)

/// RUN REGRESSIONS
reg max_g_most Hj mgt_z fam_bus misperception_gaps mnc exporter i.fage  loan_rejected i.countrycode i.a5a  [pw = base_wt]
estadd local SectorFE "Yes"
estadd local CountryFE "Yes"
est store gaps_regression

reg MAX_bus_fn Hj mgt_z fam_bus misperception_gaps mnc exporter i.fage i.size_group i.countrycode i.a5a  [pw = base_wt]
estadd local SectorFE "Yes"
estadd local CountryFE "Yes"
est store max_regression1

reg MOST_bus_fn Hj mgt_z fam_bus misperception_gaps mnc exporter i.fage i.size_group i.countrycode i.a5a  [pw = base_wt]
estadd local SectorFE "Yes"
estadd local CountryFE "Yes"
est store most_regression1

reg MAX_bus_fn Hj mgt_z fam_bus misperception_gaps mnc exporter i.fage i.size_group##i.rich_country i.countrycode i.a5a  [pw = base_wt]
estadd local SectorFE "Yes"
estadd local CountryFE "Yes"
est store max_regression2

reg MOST_bus_fn Hj mgt_z fam_bus misperception_gaps mnc exporter i.fage i.size_group##i.rich_country i.countrycode i.a5a  [pw = base_wt]
estadd local SectorFE "Yes"
estadd local CountryFE "Yes"
est store most_regression2

esttab gaps_regression max_regression1 most_regression1 max_regression2 most_regression2 using "${path_output}\1_latex_tables\table_7.tex", nomtitles drop(_cons *.countrycode *.a5a 1.rich_country) label nobase b("%4.2f") se("%4.2f") replace s(N r2 SectorFE CountryFE, label("N" "R-squared" "2-Dig. Sector FE" "Country FE") fmt("%4.0f" "%4.2f" "" "")) star(* 0.1 ** 0.05 *** 0.01) title(Technological Sophistication and Establishment Characteristics) prehead("\begin{table}[htbp]\centering \def\sym#1{\ifmmode^{#1}\else\(^{#1}\)\fi} \caption{Technological sophistication and establishment characteristics}  \label{tab:regression_max_most} \resizebox{.7\textwidth}{!}{\begin{tabular}{l*{5}{c}}\hline\hline   & \(GAP_j\) & \(MAX_j\) & \(MOST_j\)& \(MAX_j\)& \(MOST_j\) \\") postfoot("\hline \hline \end{tabular}} \begin{minipage}{16cm} \vspace{0.1cm} \vspace{0.1cm}\footnotesize ${table19_notes} *, ** and *** denote 10\%, 5\% and 1\% significance respectively. \end{minipage} \end{table}") substitute("\_ _" "# *") 



***************************************************************************
******************************** TABLE 8 **********************************
***************************************************************************
use "${path_import}/FAT0_firm_level.dta", clear

// gen the tables 
foreach var of varlist MAX_bus_fn MOST_bus_fn {
	
	sum `var' [aw=base_wt]
	gen mean_`var'_0 = `r(mean)'
	
	sum `var' [aw=base_wt]
	gen sd_`var'_0 = `r(sd)'
	
	sum `var' [aw=base_wt], detail
	gen p50_`var'_0 = `r(p50)'
	
	sum `var'[aw=base_wt], detail
	gen skew_`var'_0 = `r(skewness)'
	
	pctile pct_`var'= `var' [aw=base_wt], nq(100) 
	gen p10_`var'_0 = pct_`var'[10]
	gen p90_`var'_0 = pct_`var'[90]
	gen p10_90_`var'_0 = p90_`var'_0 - p10_`var'_0

		forvalues i = 1/3 {
			
			sum `var' [aw=base_wt] if sector == `i'
			gen mean_`var'_`i' = `r(mean)'
	
			sum `var' [aw=base_wt] if sector == `i'
			gen sd_`var'_`i' = `r(sd)'
	
			sum `var' [aw=base_wt] if sector == `i', detail
			gen p50_`var'_`i' = `r(p50)'
	
			sum `var'[aw=base_wt] if sector == `i', detail
			gen skew_`var'_`i' = `r(skewness)'
	
			pctile pct_`var'_`i' = `var' [aw=base_wt] if sector == `i', nq(100) 
			gen p10_`var'_`i' = pct_`var'_`i'[10]
			gen p90_`var'_`i' = pct_`var'_`i'[90]
			gen p10_90_`var'_`i' = p90_`var'_`i' - p10_`var'_`i'
			
								
		}
		
}

keep mean* sd* p50* skew* p10_90*
collapse *

gen i = 1
reshape long mean_MAX_bus_fn_ sd_MAX_bus_fn_ p50_MAX_bus_fn_ skew_MAX_bus_fn_ p10_90_MAX_bus_fn_ mean_MOST_bus_fn_ sd_MOST_bus_fn_ p50_MOST_bus_fn_ skew_MOST_bus_fn_ p10_90_MOST_bus_fn_ , i(i) j(sector)
drop i 


save "${path_output}/1_latex_tables/table_8.dta", replace


// make a latex table with the results
* Open LaTeX file
file open tex using "${path_output}/1_latex_tables/table_8.tex", write replace

file write tex ///
"\begin{table}[htbp]" _n ///
"\centering" _n ///
"\caption{Cross-establishment distribution of MAX and MOST}" _n ///
"\begin{tabular}{lccccc}" _n ///
"\hline\hline" _n 

* --- Upper panel: MAX variables ---
file write tex ". & \multicolumn{5}{c}{\(MAX_j\)} \\" _n
file write tex "\cmidrule(lr){2-6}" _n 
file write tex "Sector & Mean & SD & Median &  P90-P10 & Skewness \\" _n 
file write tex "\hline" _n 

quietly {
    forvalues i = 1/`=_N' {
        local sec = sector[`i']
        local mean = mean_MAX_bus_fn_[`i']
        local sd = sd_MAX_bus_fn_[`i']
        local p50 = p50_MAX_bus_fn_[`i']
        local skew = skew_MAX_bus_fn_[`i']
        local p1090 = p10_90_MAX_bus_fn_[`i']

        file write tex ///
        "`sec' & `=string(`mean',"%4.2f")' & `=string(`sd',"%4.2f")' & " ///
        "`=string(`p50',"%4.2f")'  & `=string(`p1090',"%4.2f")' & `=string(`skew',"%4.2f")' \\" _n
    }
}

file write tex "\hline" _n

* --- Lower panel: MOST variables ---
file write tex ". & \multicolumn{5}{c}{\(MOST_j\)} \\" _n
file write tex "\cmidrule(lr){2-6}" _n 
file write tex "Sector & Mean & SD & Median &  P90-P10 & Skewness \\" _n 
file write tex "\hline" _n 

quietly {
    forvalues i = 1/`=_N' {
        local sec = sector[`i']
        local mean = mean_MOST_bus_fn_[`i']
        local sd = sd_MOST_bus_fn_[`i']
        local p50 = p50_MOST_bus_fn_[`i']
        local skew = skew_MOST_bus_fn_[`i']
        local p1090 = p10_90_MOST_bus_fn_[`i']

        file write tex ///
        "`sec' & `=string(`mean',"%4.2f")' & `=string(`sd',"%4.2f")' & " ///
        "`=string(`p50',"%4.2f")'  & `=string(`p1090',"%4.2f")' & `=string(`skew',"%4.2f")' \\" _n
    }
}

file write tex "\hline\hline" _n
file write tex "\end{tabular}" _n
file write tex "\vspace{0.5em}" _n
file write tex "\begin{minipage}{0.9\textwidth}"_n
file write tex "\footnotesize Notes: Mean is the average of establishment-level $MAX_j$ or $MOST_j$. SD is the standard deviation. P50 is the median. P90-P10 is the difference between the technology sophistication of establishments in the $90^{th}$ and $10^{th}$ percentiles of technology sophistication. All statistics computed using establishment sampling weights. Overall refers to the entire sample; Agriculture, Manufacturing, and Services restrict the sample to establishments in the 1-digit sector." _n
file write tex "\end{minipage}"_n
file write tex "\end{table}" _n

file close tex




***************************************************************************
******************************** TABLE 9 **********************************
***************************************************************************

use "${path_import}/FAT0_firm_level.dta", clear

bysort isic4d: egen N_isic = count(firmid)

foreach var of varlist MAX_bus_fn MOST_bus_fn sales_pw {
	
	forvalues i = 2/3 {
		
		reg `var' i.isic`i'd [pw=base_wt]
		gen r2_`var'_isic`i' = `e(r2)'
		
	}
	
	reg `var' i.isic4d [pw=base_wt] if N_isic >= 5
    gen r2_`var'_isic4 = `e(r2)'
	
	
}

collapse r2*


save "${path_output}/1_latex_tables/table_9.dta", replace

file open tex using "${path_output}/1_latex_tables/table_9.tex", write replace

file write tex ///
"\begin{table}[htbp]" _n ///
"\centering" _n ///
"\caption{R-squared values by ISIC level and outcome}" _n ///
"\begin{tabular}{lccc}" _n ///
"\hline\hline" _n ///
"& Productivity & MAX & MOST \\" _n ///
"\hline" _n ///
"ISIC 2 & `=string(r2_sales_pw_isic2,"%4.3f")' & `=string(r2_MAX_bus_fn_isic2,"%4.3f")' & `=string(r2_MOST_bus_fn_isic2,"%4.3f")' \\" _n ///
"ISIC 3 & `=string(r2_sales_pw_isic3,"%4.3f")' & `=string(r2_MAX_bus_fn_isic3,"%4.3f")' & `=string(r2_MOST_bus_fn_isic3,"%4.3f")' \\" _n ///
"ISIC 4 & `=string(r2_sales_pw_isic4,"%4.3f")' & `=string(r2_MAX_bus_fn_isic4,"%4.3f")' & `=string(r2_MOST_bus_fn_isic4,"%4.3f")' \\" _n ///
"\hline\hline" _n ///
"\end{tabular}" _n ///
"\caption*{\footnotesize Notes: This table displays the share of the cross- establishment variance of log sales per worker, MAX_j and MOST_j accounted for a full set of sector dummies. Sectors are defined using the International Standard Industrial Classification of All Economic Activities (ISIC), revision 4. Rows refer to the level of aggregation of sectoral fixed effects: division (2-digit), groups (3-digit), or classes (4-digit). At the 4-digit level, we kept sectors for which there were at least 5 establishments in the sample.}" _n ///
"\end{table}" _n

file close tex


***************************************************************************
******************************** TABLE 10 *********************************
***************************************************************************
use "${path_import}/FAT0_firm_level.dta", clear

*drop if country==10 | country==11

// construct solow residuals
gen ln_sales = ln(sales)
gen ln_mat_cost = ln(mat_cost)
gen ln_cap_cost = ln(cap_cost)
gen ln_energy_cost = ln(energy_cost)
reg ln_sales ln_emp ln_mat_cost ln_cap_cost ln_energy_cost i.a5a [pw=base_wt] 
predict u_solow if e(sample), resid


// A. and B. - sales, lab_cost, mat_cost, energy_cost, cap_cost
gen profits = sales - lab_cost - 0.01*cap_cost - mat_cost - energy_cost
gen profit_rate = profits/sales
xtile profit_pct = profit_rate [aw=base_wt], nq(100)
gen profit_w = 1 if profit_pct < 98 & profit_pct > 2


est clear

gen rich=0 
replace rich=1 if (countrycode==6 | countrycode==12 | countrycode==13)

gen Sj_rich=Sj*rich

gen S_1 = 1 if avg_max_most < 1.5
gen S_2 = 1 if avg_max_most >= 1.5 & avg_max_most < 2.5
gen S_3 = 1 if avg_max_most >= 2.5 & avg_max_most < 3.5
gen S_4 = 1 if avg_max_most >= 3.5 & avg_max_most != .

foreach var of varlist S_* {
	replace `var' = 0 if `var' == . & avg_max_most != .
}



sum avg_max_most [aw=base_wt],detail
gen med_sj = `r(p50)'
gen avg_soph_high = 1 if avg_max_most > med_sj & avg_max_most != .
replace avg_soph_high= 0 if avg_soph_high == . & avg_max_most != . 
replace avg_soph_high = avg_soph_high*avg_max_most


gen Sj_1 = S_1*avg_max_most
gen Sj_2 = S_2*avg_max_most
gen Sj_3 = S_3*avg_max_most
gen Sj_4 = S_4*avg_max_most


////////////// MAIN TABLE 1

reg sales_pw Kj Hj Sj i.a5a i.countrycode  [pw=base_wt]
estadd local SectorFE "Yes"
estadd local CountryFE "Yes"
estadd local Data "All"
est store main1_1

reg sales_pw Kj Hj Sj i.a5a [pw=base_wt]
estadd local SectorFE "Yes"
estadd local CountryFE "No"
estadd local Data "All"
est store main1_2

reg sales_pw Kj Hj MOST_bus_fn MAX_bus_fn i.a5a i.countrycode  [pw=base_wt]
estadd local SectorFE "Yes"
estadd local CountryFE "Yes"
estadd local Data "All"
est store main1_3

reg sales_pw Kj Hj MOST_bus_fn MAX_bus_fn i.a5a [pw=base_wt]
estadd local SectorFE "Yes"
estadd local CountryFE "No"
estadd local Data "All"
est store main1_4

reg sales_pw Kj Hj Sj i.a5a if sector==1 [pw=base_wt]
estadd local SectorFE "Yes"
estadd local CountryFE "No"
estadd local Data "Agri."
est store main1_5

reg sales_pw Kj Hj Sj i.a5a if sector==2 [pw=base_wt]
estadd local SectorFE "Yes"
estadd local CountryFE "No"
estadd local Data "Manu."
est store main1_6

reg sales_pw Kj Hj Sj i.a5a if sector==3 [pw=base_wt]
estadd local SectorFE "Yes"
estadd local CountryFE "No"
estadd local Data "Serv."
est store main1_7

reg sales_pw Kj Hj Sj Sj_rich i.a5a i.countrycode  [pw=base_wt]
estadd local SectorFE "Yes"
estadd local CountryFE "No"
estadd local Data "All"
est store main1_8




///////////////////////////////////
// LABELS 
label var u_solow "TFP"
label var sales_pw "ln(Sales per worker)"
label var Sj_rich "(\bar{S}_j * D(Rich Country)\)"
label var profit_rate "Profit Rate"
label var MOST_bus_fn "\(MOST_j\)"
label var MAX_bus_fn "\(MAX_j\)"

label var S_1 "D(\(\bar{S}_j\) < 1.5)" 
label var S_2 "D(1.5 $\leq$ \(\bar{S}_j\) $\leq$ 2.5)" 
label var S_3 "D(2.5 $\leq$ \(\bar{S}_j\) $\leq$ 3.5)" 
label var S_4 "D(\(\bar{S}_j\) $\geq$ 3.5)"

label var Sj_1 "D(\(\bar{S}_j\) < 1.5) * \(\bar{S}_j\) " 
label var Sj_2 "D(1.5 $\leq$ \(\bar{S}_j\) $\leq$ 2.5) * \(\bar{S}_j\)" 
label var Sj_3 "D(2.5 $\leq$ \(\bar{S}_j\) $\leq$ 3.5) * \(\bar{S}_j\)" 
label var Sj_4 "D(\(\bar{S}_j\) $\geq$ 3.5) * \(\bar{S}_j\)"

label var avg_soph_high "\(\bar{S}_j*D(High Sophistication)\)"
label var Sj "\(\bar{S}_j\)"

label var Kj "\(K_j\)"
label var Hj "\(H_j\)"



//////////
esttab main* using "${path_output}\1_latex_tables\table_10.tex", replace label s(N r2 SectorFE CountryFE Data, label("N" "R-squared" "Sector FE" "Country FE" "Data") fmt("%4.0f" "%4.2f")) star(* 0.1 ** 0.05 *** 0.01) b("%4.2f") se("%4.2f") drop(*.a5a *.countrycode) nobase prehead("\begin{table}[htbp]\centering \def\sym#1{\ifmmode^{#1}\else\(^{#1}\)\fi} \caption{Productivity and Sophistication} \label{tab:} \resizebox{0.7\textwidth}{!}{ \begin{tabular}{l*{8}{c}}\hline\hline \\ &\multicolumn{8}{c}{ln(Sales per worker)}\\ \\  \cmidrule(lr){2-9}\\") postfoot("\hline \hline \end{tabular}} \begin{minipage}{16cm} \vspace{0.1cm} \vspace{0.1cm}\scriptsize Note: $\overline{S}_j$ is the simple average of $MAX_j$ and $MOST_j$. $D(Rich Country)$ is a dummy variable that takes the value of 1 if country is high-income (South Korea, Poland and Croatia), and 0 otherwise. Agri. refers to agriculture sector, Manu. refers to manufacturing sector, Serv. refers to the services sector. *, ** and *** denote 10\%, 5\% and 1\% significance respectively. \end{minipage} \end{table}") eqlabels(none) nomtitle collabels(none) substitute(\_ _) 
