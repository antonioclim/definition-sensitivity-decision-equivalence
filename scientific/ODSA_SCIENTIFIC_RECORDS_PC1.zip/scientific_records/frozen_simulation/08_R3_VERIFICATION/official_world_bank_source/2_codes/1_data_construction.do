//DIRECTORIES

set more off
clear *
set maxvar 12000


* output location
cd "${path_import}"


// merge isic classification
use "${path_import}\FAT0_raw_data_qje.dta", clear
merge 1:1 firmid using "${path_import}/isic_data.dta"
drop _merge


******************************************************************************************************************
****************************** MODULE 1: Firm Characteristics and Financial Variables ****************************
******************************************************************************************************************

gen ppp = .
replace ppp = 2.226397081 if country=="Brazil" & s1c_rev==1  // 2018
replace ppp = 2.368305484 if country=="Brazil" & s1c_rev!=1  // 2020
replace ppp = 7484.730611 if country=="Vietnam"
replace ppp = 239.0067358 if country=="Senegal"
replace ppp = 31.29487143 if country=="Bangladesh"
replace ppp = 40.90159935 if country=="Kenya"
replace ppp = 21.0732267 if country=="India"
replace ppp = 856.426215 if country=="Korea"
replace ppp = 2.030105042 if country=="Ghana"
replace ppp = 217.1726873 if country=="BurkinaFaso"
replace ppp = 1.822844 if country=="Poland"
replace ppp = 0.950974307 if country=="Georgia"
replace ppp = 14.16684078 if country=="Ethiopia"
replace ppp = 435.156175 if country=="Chile"
replace ppp = 1392.458621 if country=="Cambodia" 
replace ppp = 23.21529305 if country=="India_Wave2_New"
replace ppp = 0.42830789 if country=="Croatia"


// Total Employment: tot_emp
egen tot_emp_2018 = rowtotal(e1a e1b e1c e1d) if (country=="Brazil" & s1c_rev==1) | (country=="Senegal" | country=="Vietnam" | country=="Bangladesh" | country=="India")
replace tot_emp_2018 = . if (e1a==. & e1b==. & e1c==. & e1d==.)

gen tot_emp_2019 = e1 if (country=="Kenya" | country=="Korea" | country=="Ghana" | country=="BurkinaFaso" | country=="Poland" | country=="Georgia" | country=="Ethiopia" | country=="Chile" | country=="Cambodia" | country=="India_Wave2_New" | country=="Croatia" | country=="Philippines") | (country=="Brazil" & s1c_rev~=1)
replace tot_emp_2019 = e1a if e1==. & (country=="Kenya" | country=="Korea" | country=="Ghana" | country=="BurkinaFaso" | country=="Poland" | country=="Georgia" | country=="Ethiopia" | country=="Chile" | country=="Cambodia" |  country=="India_Wave2_New" | country=="Croatia") | (country=="Brazil" & s1c_rev~=1)
replace tot_emp_2019 = . if country=="Poland"

gen tot_emp = tot_emp_2018
replace tot_emp = tot_emp_2019 if (country=="Kenya" | country=="Korea" | country=="Ghana" | country=="BurkinaFaso" | country=="Poland" | country=="Georgia" | country=="Ethiopia" | country=="Chile" | country=="Cambodia" |  country=="India_Wave2_New" | country=="Croatia") | (country=="Brazil" & s1c_rev~=1)


// Sales: sales
gen sales = e6a/ppp

// Material Cost: mat_cost 
gen mat_cost = e7b/ppp 

// Labour Cost: lab_cost
gen lab_cost = e7a/ppp 

// Energy Cost: energy_cost 
gen energy_cost = e7c/ppp

// Total Cost: tot_cost
gen tot_cost = e7d/ppp

// Age: age
gen year = a6
replace year = . if a6==-9
replace year = . if a6<1800 | a6>=2022

gen age = .
replace age = 2019 - year if (country=="Brazil" & s1c_rev==1) | (country=="Vietnam" | country=="Senegal" | country=="Bangladesh")
replace age = 2020 - year if (country=="Kenya" | country=="Ghana" | country=="India" | country=="Korea" | country=="BurkinaFaso" | country=="Poland")
replace age = 2021 - year if (country=="Georgia" | country=="Ethiopia" | country=="Chile" | country=="Cambodia") | (country=="Brazil" & s1c_rev~=1)
replace age = 2022 - year if (country=="India_Wave2_New" | country=="Croatia")

gen fage_group = . 
replace fage_group = 1 if age>=0 & age<=5
replace fage_group = 2 if age>=6 & age<=10
replace fage_group = 3 if age>=11 & age<=15
replace fage_group = 4 if age>=16 & age~=.

// Size Group : based on total employment
gen size_group2 = .
replace size_group2 = 1 if s7<=19
replace size_group2 = 2 if s7>=20 & s7<=99
replace size_group2 = 3 if s7>=100 & s7<.

gen size_group = .
replace size_group = 1 if tot_emp<=19
replace size_group = 2 if tot_emp>=20 & tot_emp<=99 
replace size_group = 3 if tot_emp>=100 & tot_emp~=.
replace size_group = size_group2 if size_group==. // imputation based on screener strata

*replace size_group = 1 if s1b=="Small" & country=="Poland"
*replace size_group = 2 if s1b=="Medium" & country=="Poland"
*replace size_group = 3 if s1b=="Large" & country=="Poland"

replace size_group = 1 if s1b==1 & country=="Poland"
replace size_group = 2 if s1b==2 & country=="Poland"
replace size_group = 3 if s1b==3 & country=="Poland"


// Exporter
gen exporter = (d6a==1 | d6a==2) if (country=="Brazil" & s1c_rev==1) | (country=="Senegal" | country=="Vietnam"  | country=="Bangladesh" | country=="India" | country=="BurkinaFaso")
replace exporter = 1 if d6a==1 & (country=="Kenya" | country=="Korea" | country=="Ghana" | country=="Poland" | country=="Georgia" | country=="Ethiopia" | country=="Chile" | country=="Cambodia" | country=="India_Wave2_New" | country=="Croatia") | (country=="Brazil" & s1c_rev~=1)
replace exporter = 0 if d6a==2 & (country=="Kenya" | country=="Korea" | country=="Ghana" | country=="Poland" | country=="Georgia" | country=="Ethiopia" | country=="Chile" | country=="Cambodia" | country=="India_Wave2_New" | country=="Croatia") | (country=="Brazil" & s1c_rev~=1)
replace exporter = 1 if country == "Croatia" & d6a == 1
replace exporter = 1 if country == "Croatia" & d6a == 2


//Cap Cost
gen cap_cost = e8a/ppp
gen land_cost = e8b/ppp
egen totcap = rowtotal(cap_cost land_cost) if cap_cost~=. | land_cost~=.
gen cappw = totcap/tot_emp

// MNC 
gen mnc = (a3b>=50 & a3b~=.)

// Electricity, Computer, Internet
gen d_electricity = (b1a==1)
replace d_electricity = . if b1a==.
replace d_electricity = 1 if country=="Korea" | country=="Poland" | country=="Georgia" // b1a was asked in Ethiopia and Chile
replace d_electricity = 0 if b1b==2 & country=="Ghana" 
replace d_electricity = 1 if b1b==1 & country=="Ghana" 

gen computer = b4a  
gen d_computer = (computer>0)
replace d_computer = . if computer==.

gen internet = .
replace internet = 1 if b5a==1
replace internet = 0 if b5a==2

gen elec_comp_int = (d_electricity==1 & d_computer==1 & internet==1)
replace elec_comp_int = . if d_electricity==. | d_computer==. | internet==.

// Sector
gen sector = 1 if a5a == 1 | a5a == 2
replace sector = 2 if a5a == 3 | a5a == 4 | a5a == 5 | a5a == 6 | a5a == 11 | a5a == 12 | a5a == 13 | a5a == 14 | a5a == 15 | a5a == 101
replace sector = 3 if a5a == 102 | a5a == 7 | a5a == 8 | a5a == 9 | a5a == 10 	

// Country -- replace "India_Wave2_New" by "India"

replace country = "India" if country == "India_Wave2_New"

// MGT Index

preserve
		gen mgt1 = d4a
		gen mgt2 = d4b
		gen mgt3 = d4c
		gen mgt4 = d4d

		replace mgt1 = 0 if mgt1 == 2
		replace mgt2 = 0 if mgt2 == 4
		replace mgt3 = 0 if mgt3 == 7
		replace mgt4 = 0 if mgt4 == 4

		///////////////////////////////// rescale ///////////////////////////////
		//1 is 0-1
		//2 
		gen r_mgt2 = mgt2/3
		gen r_mgt3 = mgt3/6
		gen r_mgt4 = mgt4/3

		sum mgt1 r_*

		egen mgt_index = rowmean(mgt1 r_mgt*)

		gen mgt_mean = .
		gen mgt_sd = .

		encode country, gen(countr)
		sum countr

		forvalues var = 1/15 {
			sum mgt_index [aw=base_wt]  if countr == `var'
			replace mgt_mean = `r(mean)' if countr == `var'

			sum mgt_index [aw=base_wt] if countr == `var'
			replace mgt_sd = `r(sd)' if countr == `var'
		}

		gen mgt_z = (mgt_index - mgt_mean)/mgt_sd
		keep firmid mgt_z
		save "${path_import}/mgt_z.dta", replace


restore 

merge 1:1 firmid using "${path_import}/mgt_z.dta"
drop _merge




*************************************************************************************************************
**************************************** MODULE 2: Technology Measures **************************************
*************************************************************************************************************

//reshape the data to long format
reshape long db8a db9a db10a db11a db12a db13b db14a db15a dc1_0a dc1_1b dc1_2b dc1_3b dc1_4b dc1_5b dc1_6b dc2_0a dc2_1b dc2_2b dc2_3b dc2_4b dc2_5b dc3_1b dc3_2b dc3_3b dc3_4b dc3_5b dc4_1b dc4_2b dc4_3b dc4_4b dc5_1b dc5_2b dc5_3b dc5_4b dc5_5b dc6_1b dc6_2b dc6_3b dc6_4b dc6_5b dc6_6b dc7_1b dc7_2b dc7_3b dc7_4b dc7_5b dc8_1b dc8_2b dc8_3b dc8_4b dc8_5b dc9_1b dc9_2b dc9_3b dc9_4b dc9_5b dc10_2b dc10_3b dc11_1b dc11_2b dc11_3b dc11_4b dc10_1a dc10_4c dc10_5a ib8b ib9b ib10a ib11b ib12b ib13c ib14b ib15b ic1_1c ic1_2c ic1_3c ic1_4c ic1_5c ic1_6c ic2_1c ic2_2c ic2_3c ic2_4c ic2_5c ic3_1c ic3_2c ic3_3c ic3_4c ic3_5c ic4_1c ic4_2c ic4_3c ic4_4c ic5_1c ic5_2c ic5_3c ic5_4c ic5_5c ic6_1c ic6_2c ic6_3c ic6_4c ic6_5c ic6_6c ic7_1c ic7_2c ic7_3c ic7_4c ic7_5c ic8_1c ic8_2c ic8_3c ic8_4c ic8_5c ic9_1c ic9_2c ic9_3c ic9_4c ic9_5c ic10_2c ic10_3c ic11_1c ic11_2c ic11_3c ic11_4c, i(firmid) j(tech)


gen bus_fn1 = db8a
gen bus_fn2 = db9a
gen bus_fn3 = db10a
gen bus_fn4 = db11a
gen bus_fn5 = db13b
gen bus_fn6 = db14a
gen bus_fn7 = db15a
gen bus_fn8 = dc1_1b if a5a == 1
gen bus_fn9 = dc1_2b if a5a == 1
gen bus_fn10 = dc1_3b if a5a == 1
gen bus_fn11 = dc1_4b if a5a == 1
gen bus_fn12 = dc1_5b if a5a == 1
gen bus_fn13 = dc1_6b if a5a == 1
gen bus_fn14 = dc2_1b if a5a == 2
gen bus_fn15 = dc2_2b if a5a == 2
gen bus_fn16 = dc2_3b if a5a == 2
gen bus_fn17 = dc2_4b if a5a == 2
gen bus_fn18 = dc2_5b if a5a == 2
gen bus_fn19 = dc3_1b if a5a == 3
gen bus_fn20 = dc3_2b if a5a == 3
gen bus_fn21 = dc3_3b if a5a == 3
gen bus_fn22 = dc3_4b if a5a == 3
gen bus_fn23 = dc3_5b if a5a == 3
gen bus_fn24 = dc4_1b if a5a == 4
gen bus_fn25 = dc4_2b if a5a == 4
gen bus_fn26 = dc4_3b if a5a == 4
gen bus_fn27 = dc4_4b if a5a == 4
gen bus_fn28 = dc5_1b if a5a == 5
gen bus_fn29 = dc5_2b if a5a == 5
gen bus_fn30 = dc5_3b if a5a == 5
gen bus_fn31 = dc5_4b if a5a == 5
gen bus_fn32 = dc5_5b if a5a == 5
gen bus_fn33 = dc6_1b if a5a == 6
gen bus_fn34 = dc6_2b if a5a == 6
gen bus_fn35 = dc6_3b if a5a == 6
gen bus_fn36 = dc6_4b if a5a == 6
gen bus_fn37 = dc6_5b if a5a == 6
gen bus_fn38 = dc6_6b if a5a == 6
gen bus_fn39 = dc7_1b if a5a == 7
gen bus_fn40 = dc7_2b if a5a == 7
gen bus_fn41 = dc7_3b if a5a == 7
gen bus_fn42 = dc7_4b if a5a == 7
gen bus_fn43 = dc7_5b if a5a == 7
gen bus_fn44 = dc8_1b if a5a == 8
gen bus_fn45 = dc8_2b if a5a == 8
gen bus_fn46 = dc8_3b if a5a == 8
gen bus_fn47 = dc8_4b if a5a == 8
gen bus_fn48 = dc8_5b if a5a == 8
gen bus_fn49 = dc9_1b if a5a == 9
gen bus_fn50 = dc9_2b if a5a == 9
gen bus_fn51 = dc9_3b if a5a == 9
gen bus_fn52 = dc9_4b if a5a == 9
gen bus_fn53 = dc9_5b if a5a == 9
gen bus_fn54 = dc10_1a if a5a == 10
gen bus_fn55 = dc10_2b if a5a == 10
gen bus_fn56 = dc10_3b if a5a == 10
gen bus_fn57 = dc10_4c if a5a == 10
gen bus_fn58 = dc10_5a if a5a == 10
gen bus_fn59 = dc11_1b if a5a == 11
gen bus_fn60 = dc11_2b if a5a == 11
gen bus_fn61 = dc11_3b if a5a == 11
gen bus_fn62 = dc11_4b if a5a == 11


//fabrication
gen bus_fn63 = db12a if a5a == 3
gen bus_fn64 = db12a if a5a == 4
gen bus_fn65 = db12a if a5a == 5
gen bus_fn66 = db12a if a5a == 6
gen bus_fn67 = db12a if a5a == 11
gen bus_fn68 = db12a if a5a == 101 | a5a == 13 | a5a == 14 | a5a == 15


//GENERATE MOSTS
gen most_bus_fn1 = ib8b
gen most_bus_fn2 = ib9b
gen most_bus_fn3 = ib10a
gen most_bus_fn4 = ib11b
gen most_bus_fn5 = ib13c
gen most_bus_fn6 = ib14b
gen most_bus_fn7 = ib15b
gen most_bus_fn8 = ic1_1c
gen most_bus_fn9 = ic1_2c
gen most_bus_fn10 = ic1_3c
gen most_bus_fn11 = ic1_4c
gen most_bus_fn12 = ic1_5c
gen most_bus_fn13 = ic1_6c
gen most_bus_fn14 = ic2_1c
gen most_bus_fn15 = ic2_2c
gen most_bus_fn16 = ic2_3c
gen most_bus_fn17 = ic2_4c
gen most_bus_fn18 = ic2_5c
gen most_bus_fn19 = ic3_1c
gen most_bus_fn20 = ic3_2c
gen most_bus_fn21 = ic3_3c
gen most_bus_fn22 = ic3_4c
gen most_bus_fn23 = ic3_5c
gen most_bus_fn24 = ic4_1c
gen most_bus_fn25 = ic4_2c
gen most_bus_fn26 = ic4_3c
gen most_bus_fn27 = ic4_4c
gen most_bus_fn28 = ic5_1c
gen most_bus_fn29 = ic5_2c
gen most_bus_fn30 = ic5_3c
gen most_bus_fn31 = ic5_4c
gen most_bus_fn32 = ic5_5c
gen most_bus_fn33 = ic6_1c
gen most_bus_fn34 = ic6_2c
gen most_bus_fn35 = ic6_3c
gen most_bus_fn36 = ic6_4c
gen most_bus_fn37 = ic6_5c
gen most_bus_fn38 = ic6_6c
gen most_bus_fn39 = ic7_1c
gen most_bus_fn40 = ic7_2c
gen most_bus_fn41 = ic7_3c
gen most_bus_fn42 = ic7_4c
gen most_bus_fn43 = ic7_5c
gen most_bus_fn44 = ic8_1c
gen most_bus_fn45 = ic8_2c
gen most_bus_fn46 = ic8_3c
gen most_bus_fn47 = ic8_4c
gen most_bus_fn48 = ic8_5c
gen most_bus_fn49 = ic9_1c
gen most_bus_fn50 = ic9_2c
gen most_bus_fn51 = ic9_3c
gen most_bus_fn52 = ic9_4c
gen most_bus_fn53 = ic9_5c
gen most_bus_fn54 = .
gen most_bus_fn55 = ic10_2c
gen most_bus_fn56 = ic10_3c
gen most_bus_fn57 = 0
gen most_bus_fn58 = .
gen most_bus_fn59 = ic11_1c
gen most_bus_fn60 = ic11_2c
gen most_bus_fn61 = ic11_3c
gen most_bus_fn62 = ic11_4c

gen most_bus_fn63 = ib12b if a5a == 3
gen most_bus_fn64 = ib12b if a5a == 4
gen most_bus_fn65 = ib12b if a5a == 5
gen most_bus_fn66 = ib12b if a5a == 6
gen most_bus_fn67 = ib12b if a5a == 11
gen most_bus_fn68 = ib12b if a5a == 101 | a5a == 13 | a5a == 14 | a5a == 15


//Generate ANUMs
//Absolute number of technologies is just the count of the technologies used by a firm in a particular BF (count them as missing) - ADD UP ALL THE ONES IN THE TECHS - MAKE SURE THAT THE FABRICATION IS SEPARATE FOR EACH INDUSTRY OF MANUFACTURING

//GENERATE NUM_MAX FIRST

foreach var of varlist bus_fn*  {
	egen num_max_`var' = max(tech) if `var' != . 
	
}

//ANUM GENERATION - Absolute number of technologies in a particular BF
foreach var of varlist bus_fn* {
	sum `var'
	bysort firmid : egen anum_`var' = total(`var') if `var' != . 
	replace anum_`var' = . if anum_`var' == 0
}

sum anum_* [aw=base_wt]


//GENERATE NUMs - NUM is the relative number of technologies. It is calculated by dividing (ANUM-1)/(NUM_max -1) * 4 + 1
foreach var of varlist bus_fn* {
	bysort firmid : gen num_r_`var' = [4*(anum_`var' - 1)/(num_max_`var' - 1) + 1] if `var' != . 
}

sum num_r_* [aw=base_wt]


//GENERATE MAX - MAX is the 

foreach var of varlist bus_fn*  {
    bysort firmid : egen r_`var' = max(tech) if `var' == 1 //generating rank of max soph tech used
	bysort firmid : egen R_`var' = max(tech) if `var' != .	//generating rank of 
	gen MAX_`var' = 1 + 4 * (r_`var' - 1)/(num_max_`var' - 1)
	
	bysort firmid : egen r_min_`var' = min(tech) if `var' == 1 
	gen MIN_`var' = 1 + 4 * (r_min_`var' - 1)/(num_max_`var' - 1)
	
}


//GENERATE MOST - 

foreach var of varlist bus_fn*  {
    bysort firmid : gen r_most_`var' = tech if most_`var' == 1
	gen MOST_`var' = 1 + 4 * (r_most_`var' - 1)/(num_max_`var' - 1)
}


//EDIT FOR THE FUNCTIONS THAT NEED CHANGES IN SOPHISTICATION - AUTOMOTIVE PROCESSES - CHANGE THE RANKS FOR THE CREATION OF MAX and MOSTS - FOR FUNCTION NUMBER 29, 30, 31.

//BP and Welding 
gen rank_body_pressing = 1 if tech < 4 & a5a == 5
replace rank_body_pressing = 2 if tech >=4 & tech < 7 & a5a == 5

drop r_bus_fn29
bysort firmid : egen r_bus_fn29 = mean(rank_body_pressing) if bus_fn29 == 1
replace R_bus_fn29 = 2 
replace MAX_bus_fn29 = 1 + 4 * (r_bus_fn29 - 1)/(R_bus_fn29 - 1)

replace r_most_bus_fn29 = 1 if r_most_bus_fn29 == 1 | r_most_bus_fn29 == 2 | r_most_bus_fn29 == 3 
replace r_most_bus_fn29 = 2 if r_most_bus_fn29 == 4 | r_most_bus_fn29 == 5 | r_most_bus_fn29 == 6
replace MOST_bus_fn29 = 1 + 4 * (r_most_bus_fn29 - 1)/(R_bus_fn29 - 1)



//PAINTING
gen rank_painting = 1 if tech <= 2 & a5a == 5
replace rank_painting = 2 if tech > 2 & tech < 5 & a5a == 5

drop r_bus_fn30
bysort firmid : egen r_bus_fn30 = mean(rank_painting) if bus_fn30 == 1
replace R_bus_fn30 = 2 
replace MAX_bus_fn30 = 1 + 4 * (r_bus_fn30 - 1)/(R_bus_fn30 - 1)

replace r_most_bus_fn30 = 1 if r_most_bus_fn30 == 1 | r_most_bus_fn30 == 2 
replace r_most_bus_fn30 = 2 if r_most_bus_fn30 == 3 | r_most_bus_fn30 == 4 
replace MOST_bus_fn30 = 1 + 4 * (r_most_bus_fn30 - 1)/(R_bus_fn30 - 1)


//PLASTIC 
gen rank_plastic = 1 if tech <= 2 & a5a == 5
replace rank_plastic = 2 if tech > 2 & tech < 5 & a5a == 5

drop r_bus_fn31
bysort firmid : egen r_bus_fn31 = mean(rank_plastic) if bus_fn31 == 1
replace R_bus_fn31 = 2 
replace MAX_bus_fn31 = 1 + 4 * (r_bus_fn31 - 1)/(R_bus_fn31 - 1)

replace r_most_bus_fn31 = 1 if r_most_bus_fn31 == 1 | r_most_bus_fn31 == 2 
replace r_most_bus_fn31 = 2 if r_most_bus_fn31 == 3 | r_most_bus_fn31 == 4 
replace MOST_bus_fn31 = 1 + 4 * (r_most_bus_fn31 - 1)/(R_bus_fn31 - 1)


//CHANGE MAX AND MOST FOR HEALTH FUNCTIONS - TO NUM OF THE BUSINESS FUNCTION
replace MAX_bus_fn54 = num_r_bus_fn54
replace MAX_bus_fn58 = num_r_bus_fn58

replace MOST_bus_fn54 = num_r_bus_fn54
replace MOST_bus_fn58 = num_r_bus_fn58

replace MOST_bus_fn57 = 0


//gen dummies - using erp and using robots 
gen use_erp = db8a if tech == 5 
gen use_erp_prod = db9a if tech == 5
gen use_robots = db12a if tech == 4

// CONVERT THE DATA AT A FIRM-FUNCTION LEVEL

collapse (mean) num_max_* anum_* num_r_* r_min_bus_fn* r_bus_fn* R_bus_fn* r_most_bus_fn* MAX_* MOST_* MIN_* use_erp use_robots use_erp_prod, by(firmid size_group a5a country base_wt s4 mnc exporter fage_group elec_comp_int e10a tot_emp e5d tot_cost e7a e7b e7c e7d e8a e8b a7* d1* d3* d4* d6* e5c e10b b7a b7b a4b age mgt_z sales mat_cost cap_cost cappw energy_cost lab_cost isic* b8c b9c b10c b11c b12c b13d b14c b15c ///
			 c1_1d c1_2d c1_3d c1_4d c1_5d c1_6d ///
			 c2_1d c2_2d c2_3d c2_4d c2_5d ///
			 c3_1d c3_2d c3_3d c3_4d c3_5d ///
			 c4_1d c4_2d c4_3d c4_4d ///
			 c5_1d c5_2d c5_3d c5_4d c5_5d ///
			 c6_1d c6_2d c6_3d c6_4d c6_5d c6_6d ///
			 c7_1d c7_2d c7_3d c7_4d c7_5d ///
			 c8_1d c8_2d c8_3d c8_4d c8_5d ///
			 c9_1d c9_2d c9_3d c9_4d c9_5d ///
			 c10_2d c10_3d c10_4d  ///
			 c11_1d c11_2d c11_3d c11_4d)

reshape long num_max_bus_fn anum_bus_fn num_r_bus_fn r_bus_fn r_min_bus_fn R_bus_fn r_most_bus_fn MAX_bus_fn MOST_bus_fn MIN_bus_fn, i(firmid) j(bus_fn)

// LABELS
gen label_fn = "Business Administration" if bus_fn ==1
replace label_fn = "Production Planning" if bus_fn ==2
replace label_fn = "Sourcing" if bus_fn ==3
replace label_fn = "Marketing" if bus_fn ==4
replace label_fn = "Sales" if bus_fn ==5
replace label_fn = "Payment" if bus_fn ==6
replace label_fn = "Quality Control " if bus_fn ==7
replace label_fn = "Land Preparation" if bus_fn ==8
replace label_fn = "Irrigation" if bus_fn ==9
replace label_fn = "Weeding" if bus_fn ==10
replace label_fn = "Harvesting" if bus_fn ==11
replace label_fn = "Storage" if bus_fn ==12
replace label_fn = "Packaging" if bus_fn ==13
replace label_fn = "Breeding" if bus_fn ==14
replace label_fn = "Feeding" if bus_fn ==15
replace label_fn = "Animal healthcare" if bus_fn ==16
replace label_fn = "Herd management" if bus_fn ==17
replace label_fn = "Transport of livestock" if bus_fn ==18
replace label_fn = "Input testing" if bus_fn ==19
replace label_fn = "Mixing/cooking" if bus_fn ==20
replace label_fn = "Anti-bacterial" if bus_fn ==21
replace label_fn = "Packaging" if bus_fn ==22
replace label_fn = "Food storage" if bus_fn ==23
replace label_fn = "Design " if bus_fn ==24
replace label_fn = "Cutting" if bus_fn ==25
replace label_fn = "Sewing" if bus_fn ==26
replace label_fn = "Finishing" if bus_fn ==27
replace label_fn = "Vehicle Assembly " if bus_fn ==28
replace label_fn = "Body pressing and welding *" if bus_fn ==29
replace label_fn = "Painting *" if bus_fn ==30
replace label_fn = "Plastic injection molding *" if bus_fn ==31
replace label_fn = "Productive assets management" if bus_fn ==32
replace label_fn = "Facilities" if bus_fn ==33
replace label_fn = "Weighing scale" if bus_fn ==34
replace label_fn = "Mixing/Compounding" if bus_fn ==35
replace label_fn = "Encapsulation" if bus_fn ==36
replace label_fn = "Quality control" if bus_fn ==37
replace label_fn = "Packaging" if bus_fn ==38
replace label_fn = "Customer service " if bus_fn ==39
replace label_fn = "Pricing" if bus_fn ==40
replace label_fn = "Merchandising" if bus_fn ==41
replace label_fn = "Inventory" if bus_fn ==42
replace label_fn = "Advertisement" if bus_fn ==43
replace label_fn = "Customer service " if bus_fn ==44
replace label_fn = "Avoid fraud" if bus_fn ==45
replace label_fn = "Loan applications" if bus_fn ==46
replace label_fn = "Credit applications" if bus_fn ==47
replace label_fn = "Operational support area" if bus_fn ==48
replace label_fn = "Planning" if bus_fn ==49
replace label_fn = "Plan execution" if bus_fn ==50
replace label_fn = "Monitoring" if bus_fn ==51
replace label_fn = "Performance measurement" if bus_fn ==52
replace label_fn = "Maintenance " if bus_fn ==53
replace label_fn = "Infrastructure and Machines *" if bus_fn ==54
replace label_fn = "Appointment and Scheduling" if bus_fn ==55
replace label_fn = "Patient records management" if bus_fn ==56
replace label_fn = "Healthcare management **" if bus_fn ==57
replace label_fn = "Procedures *" if bus_fn ==58
replace label_fn = "Design " if bus_fn ==59
replace label_fn = "Cutting" if bus_fn ==60
replace label_fn = "Sewing " if bus_fn ==61
replace label_fn = "Finishing" if bus_fn ==62
replace label_fn = "Fabrication" if bus_fn ==63 //food
replace label_fn = "Fabrication" if bus_fn ==64 //apparel
replace label_fn = "Fabrication" if bus_fn ==65 //auto
replace label_fn = "Fabrication" if bus_fn ==66 //pharm
replace label_fn = "Fabrication" if bus_fn ==67 //leath
replace label_fn = "Fabrication" if bus_fn ==68 //OM

gen gbf = 1 if bus_fn <= 8
replace gbf = 0 if gbf == .
gen ssbf = 1-gbf

gen sector = .
replace sector = 1  if inrange(bus_fn, 8, 13)
replace sector = 2  if inrange(bus_fn, 14, 18)
replace sector = 3  if inrange(bus_fn, 19, 23) | bus_fn == 63
replace sector = 4  if inrange(bus_fn, 24, 27) | bus_fn == 64
replace sector = 5  if inrange(bus_fn, 28, 32) | bus_fn == 65
replace sector = 6  if inrange(bus_fn, 33, 38) | bus_fn == 66
replace sector = 7  if inrange(bus_fn, 39, 43)
replace sector = 8  if inrange(bus_fn, 44, 48)
replace sector = 9  if inrange(bus_fn, 49, 53)
replace sector = 10 if inrange(bus_fn, 54, 58)
replace sector = 11 if inrange(bus_fn, 59, 62) | inlist(bus_fn, 67)
replace sector = 101 if bus_fn == 68

save "${path_import}/FAT0_reshaped_firm_busfn_updated_new.dta", replace



*****************************************************************************************************************
**************************************** MODULE 3: Relative Productivities **************************************
*****************************************************************************************************************
//
import excel using "${path_import}/relative_q_productivities.xlsx", firstrow clear
drop if BFcode == .
gen r_bus_fn = D
gen r_most_bus_fn = D
gen bus_fn = BFcode
gen rpf = Relativelogproductivity
destring bus_fn D r_bus_fn r_most_bus_fn rpf, replace

//
preserve 
keep bus_fn rpf r_bus_fn
rename rpf rpf_max
drop if r_bus_fn == .
save "${path_import}/time_task_max.dta", replace
restore 

//
preserve 
keep bus_fn rpf r_most_bus_fn
rename rpf rpf_most
drop if r_most_bus_fn == .
save "${path_import}/time_task_most.dta", replace
restore 


//merge 
use "${path_import}/FAT0_reshaped_firm_busfn_updated_new.dta", clear
merge m:1 bus_fn r_bus_fn using "${path_import}/time_task_max.dta"
drop if _merge == 2 
drop _merge 


//
merge m:1 bus_fn r_most_bus_fn using "${path_import}/time_task_most.dta"
drop if _merge == 2 
drop _merge 


/////////////////////// generate the z-score MAX and MOSTs

gen MAX_bus_fn_q = 1+rpf_max
gen MOST_bus_fn_q = 1+rpf_most


//generate qbar for health ssbfs
//qbar is defined as the average of maximum q in all the GBFs and the rest of the health SSBFs
//

bysort bus_fn: egen q_health_max = max(rpf_max) if a5a == 10
bysort bus_fn: egen q_health_most = max(rpf_most) if a5a == 10
egen q_bar_max = mean(q_health_max) 
egen q_bar_most = mean(q_health_most) 

//should be same ideally
gen max_q_health = [(q_bar_max-1)*(anum_bus_fn - 1)/(num_max_bus_fn - 1) + 1] if bus_fn == 54 | bus_fn == 58
gen most_q_health = [(q_bar_max-1)*(anum_bus_fn - 1)/(num_max_bus_fn - 1) + 1] if bus_fn == 54 | bus_fn == 58

replace MAX_bus_fn_q = max_q_health if bus_fn == 54 | bus_fn == 58
replace MOST_bus_fn_q = most_q_health if bus_fn == 54 | bus_fn == 58


//
gen mean_max = .
gen mean_most = .
gen sd_max = .
gen sd_most = .

//
forvalues i = 1/68 {
	
	sum MAX_bus_fn [aw=base_wt] if bus_fn == `i'
	replace mean_max = `r(mean)' if bus_fn == `i'
	
	sum MAX_bus_fn [aw=base_wt] if bus_fn == `i'
	replace sd_max = `r(sd)' if bus_fn == `i'
	
	sum MOST_bus_fn [aw=base_wt] if bus_fn == `i'
	replace mean_most = `r(mean)' if bus_fn == `i'
	
	sum MOST_bus_fn [aw=base_wt] if bus_fn == `i'
	replace sd_most = `r(sd)' if bus_fn == `i'

}


//
gen MAX_bus_fn_z = (MAX_bus_fn-mean_max)/sd_max
gen MOST_bus_fn_z = (MOST_bus_fn-mean_most)/sd_most

//
replace MOST_bus_fn_q = 0 if MOST_bus_fn == 0
replace MOST_bus_fn_z = 0 if MOST_bus_fn == 0


save "${path_import}/FAT0_reshaped_firm_busfn_consolidated.dta", replace

************************************************************************************************************
**************************************** MODULE 4: Firm-Level Dataset **************************************
************************************************************************************************************

use "${path_import}/FAT0_reshaped_firm_busfn_updated_new.dta", clear

drop if anum_bus_fn == . 
replace MOST_bus_fn = . if MOST_bus_fn == 0

//gen max_minus_most = MAX_bus_fn - MOST_bus_fn 

gen anum_non_missing = 1 if anum_bus_fn != .
gen anum_g_1 = 1 if anum_bus_fn > 1


bysort firmid: egen num_g1 = total(anum_g_1)
bysort firmid: egen num_functions = total(anum_non_missing)
gen num_fraction_1 = num_g1/num_functions


/////////////////////////////////////////////////
//generate fraction variables 
gen max_g_most = 1 if MAX_bus_fn > MOST_bus_fn & anum_g_1 == 1
replace max_g_most = 0 if MAX_bus_fn == MOST_bus_fn & anum_g_1 == 1

gen max_g_most_gbf = 1 if MAX_bus_fn > MOST_bus_fn & gbf == 1 & anum_g_1 == 1
replace max_g_most_gbf = 0 if MAX_bus_fn == MOST_bus_fn & gbf == 1 & anum_g_1 == 1

gen max_g_most_ssbf = 1 if MAX_bus_fn > MOST_bus_fn & ssbf == 1 & anum_g_1 == 1
replace max_g_most_ssbf = 0 if MAX_bus_fn == MOST_bus_fn & ssbf == 1 & anum_g_1 == 1

////////////////////////////////////////////////////////////
drop if a5a != sector & sector != .
drop sector*
//drop if MOST_bus_fn < 1 

//sector definition
gen sector = 1 if a5a == 1 | a5a == 2
replace sector = 2 if a5a == 3 | a5a == 4 | a5a == 5 | a5a == 6 | a5a == 11 | a5a == 101 | a5a == 13 | a5a == 14 | a5a == 15
replace sector = 3 if a5a == 7 | a5a == 8 | a5a == 9 | a5a == 10 | a5a == 102 | a5a == 12

//country
encode country, generate(countrycode)

//size_group

//ages
//ALREADY NUMERIC

// MODEL 1 - ALL 
rename fage_group fage 
collapse (mean) MOST_bus_fn MAX_bus_fn max_g_most* e* b* num_g num_fraction_1, by(firmid countrycode a5a sector fage d1* d3* d4* d6* size_group s4 mnc a7* mgt_z a4b age sales mat_cost cap_cost cappw tot_emp lab_cost isic*  ///
			 c1_1d c1_2d c1_3d c1_4d c1_5d c1_6d ///
			 c2_1d c2_2d c2_3d c2_4d c2_5d ///
			 c3_1d c3_2d c3_3d c3_4d c3_5d ///
			 c4_1d c4_2d c4_3d c4_4d ///
			 c5_1d c5_2d c5_3d c5_4d c5_5d ///
			 c6_1d c6_2d c6_3d c6_4d c6_5d c6_6d ///
			 c7_1d c7_2d c7_3d c7_4d c7_5d ///
			 c8_1d c8_2d c8_3d c8_4d c8_5d ///
			 c9_1d c9_2d c9_3d c9_4d c9_5d ///
			 c10_2d c10_3d c10_4d  ///
			 c11_1d c11_2d c11_3d c11_4d)

//
replace a7b = 0 if a7b == 2 
replace a7d = 0 if a7d == 2

//
label define a7c 1 "Primary school" 2 "Secondary school" 3 "Complete high-school" 4 "College degree" 5 "Post-Graduation (MBA, Master or PhD)" 6 "Vocational training" -9 "Don't know" , replace

replace a7c = . if a7c == 0 
label values a7c a7c

label define size 1 "Size : Small" 2 "\\ Size : Medium" 3 "Size : Large"
label define age 1 "< 5" 2 "Age: 6 - 10 Years" 3 "Age : 11 - 15 Years" 4 "Age : 16+ years"

label values fage age 
label values size_group size

label var mnc "Foreign Owned"
label var s4 "Multi-establishment"
label var exporter "Exporter"

label var max_g_most "\% functions with \(MAX_{f,j}\) $>$ \(MOST_{f,j}\)"

replace a5a = 101 if a5a == 13 | a5a == 14 | a5a == 15
replace a5a = 102 if a5a == 12

gen Kj = ln(cappw)
gen Hj = e5d/100
gen sales_pw = ln(sales) - ln(tot_emp)

gen ln_emp = ln(tot_emp)
gen avg_max_most = (MAX_bus_fn+MOST_bus_fn)/2
gen Sj = (MAX_bus_fn+MOST_bus_fn)/2

save "${path_import}/FAT0_firm_level.dta", replace 



