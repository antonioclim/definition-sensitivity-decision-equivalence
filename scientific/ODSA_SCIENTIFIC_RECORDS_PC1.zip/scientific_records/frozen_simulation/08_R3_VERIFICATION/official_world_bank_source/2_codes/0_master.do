//DIRECTORIES

version 18
set more off
clear *
set maxvar 12000
set varabbrev on 

	* Set project global(s)
	global project 	"C:\WBG\rep-checks\516\QJE_replication_2025_CCC"
	global path_dofile 	"${project}/2_codes"
	global path_import 	"${project}/1_data"
	global path_output	"${project}/3_output"
	
	* Set ado folder in the dofiles/code folder
	sysdir set PLUS "${path_dofile}/ado"


* output location
cd "${path_import}"

* 1: Data construction
do "${path_dofile}\1_data_construction.do"

* 2: Main tables
do "${path_dofile}\2_main_tables.do"

* 3: Appendix tables
do "${path_dofile}\3_appendix_tables.do"

* 2: Main figures
do "${path_dofile}\4_main_figures.do"

* 3: Appendix figures
do "${path_dofile}\5_appendix_figures.do"