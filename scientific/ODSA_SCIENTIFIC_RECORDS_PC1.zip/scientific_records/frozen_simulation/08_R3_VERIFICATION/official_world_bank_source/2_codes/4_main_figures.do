//DIRECTORIES

// set more off
// clear *
// set maxvar 12000


* output location
cd "${path_import}"

***************************************************************************
******************************* FIGURE 3 **********************************
***************************************************************************

use "${path_import}/FAT0_reshaped_firm_busfn_updated_new.dta", clear

// sample firms
keep if inlist(firmid, 501021, 1100470)
keep firmid bus_fn label_fn MAX_bus_fn 

// clean up labels
replace label_fn = "Quality Control" if inlist(label_fn, "Quality Control ", "Quality control") 
replace label_fn = "Customer Service" if inlist(label_fn, "Customer service ") 

// take subset of business functions
keep if ///
	inlist(label_fn, "Business Administration","Production Planning", "Sourcing", "Marketing", "Sales") | ///
	inlist(label_fn, "Payment","Quality Control", "Customer Service", "Pricing", "Merchandising") | ///
	inlist(label_fn, "Inventory","Advertisement")
drop if MAX_bus_fn ==.
	
replace bus_fn = 8 if label_fn == "Customer Service"
replace bus_fn = 9 if label_fn == "Pricing"
replace bus_fn = 10 if label_fn == "Merchandising"
replace bus_fn = 11 if label_fn == "Inventory"
replace bus_fn = 12 if label_fn == "Advertisement"

reshape wide MAX_bus_fn label_fn, i(firmid) j(bus_fn)

gen establishment = "Establishment 1" if firmid == 501021
replace establishment = "Establishment 2" if firmid == 1100470

label variable MAX_bus_fn1  " 1 Business Administration"
label variable MAX_bus_fn2  " 2 Production Planning"
label variable MAX_bus_fn3  " 3 Sourcing"
label variable MAX_bus_fn4  " 4 Marketing"
label variable MAX_bus_fn5  " 5 Sales"
label variable MAX_bus_fn6  " 6 Payment"
label variable MAX_bus_fn7  " 7 Quality Control"
label variable MAX_bus_fn8  " 8 Customer Service"
label variable MAX_bus_fn9  " 9 Pricing"
label variable MAX_bus_fn10 "10 Merchandising"
label variable MAX_bus_fn11 "11 Inventory"
label variable MAX_bus_fn12 "12 Advertisement"

spider MAX_bus_fn1 MAX_bus_fn2 MAX_bus_fn3 MAX_bus_fn4 MAX_bus_fn5 ///
    MAX_bus_fn6 MAX_bus_fn7 MAX_bus_fn8 MAX_bus_fn9 MAX_bus_fn10 ///
    MAX_bus_fn11 MAX_bus_fn12,   ///
    over(establishment) ///
    alpha(0) ///
    ra(0(1)5) ///
    palette("navy red") ///
	lp(solid dash) ///
    legend(label(1 "Establishment 1") label(2 "Establishment 2") ///
           position(12) cols(2) symxsize(*3) symysize(*0.3))
graph export "${path_output}\2_graphs\Figure_3.png", replace

***************************************************************************
******************************* FIGURE 4 **********************************
***************************************************************************
u "${path_import}/FAT0_reshaped_firm_busfn_updated_new.dta", clear
keep if label_fn == "Fabrication" & inlist(country, "Senegal", "Korea", "India")

//rescale base wt 
gen base_wt_rescaled = base_wt*1000 
gen base_wt_f = round(base_wt_rescaled) 

* Create individual histograms for each country and variable
foreach country in Senegal India Korea {
    * MAX histogram
    histogram MAX_bus_fn [fw=base_wt_f] if country == "`country'" &  bus_fn == 63, ///
        fraction discrete width(0.66667) start(1) ///
        fcolor(midblue) lcolor(eltblue) ///
        xlabel(1(1)5) ylabel(0(0.2)0.8, angle(0)) ///
        xtitle("MAX") ytitle("Fraction") ///
        title("MAX - `country'", size(medium)) ///
        name(max_`country', replace) ///
        graphregion(color(white))
    
    * MOST histogram
    histogram MOST_bus_fn [fw=base_wt_f] if country == "`country'" &  bus_fn == 63, ///
        fraction discrete width(0.66667) start(1) ///
        fcolor(midblue) lcolor(eltblue) ///
        xlabel(1(1)5) ylabel(0(0.2)0.8, angle(0)) ///
        xtitle("MOST") ytitle("Fraction") ///
        title("MOST - `country'", size(medium)) ///
        name(most_`country', replace) ///
        graphregion(color(white))
}

* Combine all 6 graphs in 2x3 layout
graph combine max_Senegal max_India max_Korea ///
              most_Senegal most_India most_Korea, ///
    cols(3) rows(2) ///
    imargin(small) ///
    graphregion(color(white)) ///
    name(combined, replace)
graph export "${path_output}\2_graphs\Figure_4.png", replace

***************************************************************************
******************************* FIGURE 5 **********************************
***************************************************************************
u "${path_import}/FAT0_firm_level.dta", clear

sum max_g_most, det
tabstat  max_g_most [aw=base_wt], stat(sd) 


preserve
collapse (p10) p10 = max_g_most (p90) p90 = max_g_most [pw=base_wt]
restore

histogram max_g_most, ///
    percent ///
    width(0.1) ///
    fcolor(midblue) ///
    lcolor(eltblue) ///
    xlabel(0(0.2)1) ///
    ylabel(0(5)25, angle(0)) ///
    xtitle("") ///
    ytitle("Percent") ///
    graphregion(color(white)) ///
    plotregion(margin(small))
graph export "${path_output}\2_graphs\Figure_5.png", replace

***************************************************************************
******************************* FIGURE 6 **********************************
***************************************************************************
u "${path_import}/FAT0_firm_level.dta", clear

sum max_g_most

collapse (mean) max_g_most  [pw=base_wt], by(countrycode)


// IMPORT gdp DATA
preserve
	import excel "${path_import}\country_stats_2080.xlsx", sheet("Sheet2") cellrange(A1:C16) firstrow clear
	tempfile gdp
	save `gdp'
restore
merge 1:1 countrycode using `gdp', keep(3) nogen


scatter max_g_most  lgdp if max_g_most >= 0, legend(off) title(" ") ///
 xtitle("Log GDP per capita") ytitle(" MAX-MOST GAP") mlabel(country) /// 
 mlabcolor(blue) msymbol(i) mlabsize(small) /// 
 msymbol(0h) mcolor(white) mlcolor(blue) || ///
 lfit  max_g_most lgdp, lcolor(blue) lpattern(dash)
 graph export "${path_output}\2_graphs\Figure_6.png", replace

 
***************************************************************************
******************************* FIGURE 7 **********************************
***************************************************************************

u "${path_import}/FAT0_firm_level.dta", clear    // new subdata from 1.data_cleaning_CC to be replaced with FAT0firm level with subsector
   		   
foreach var of varlist  b8c b9c b10c b11c b13d b14c b15c ///
			 c1_1d c1_2d c1_3d c1_4d c1_5d c1_6d ///
			 c2_1d c2_2d c2_3d c2_4d c2_5d ///
			 c3_1d c3_2d c3_3d c3_4d c3_5d ///
			 c4_1d c4_2d c4_3d c4_4d ///
			 c5_1d c5_2d c5_3d c5_4d c5_5d ///
			 c6_1d c6_2d c6_3d c6_4d c6_5d c6_6d ///
			 c7_1d c7_2d c7_3d c7_4d c7_5d ///
			 c8_1d c8_2d c8_3d c8_4d c8_5d ///
			 c9_1d c9_2d c9_3d c9_4d c9_5d ///
			  /*c10_1d*/ c10_2d c10_3d c10_4d  /*c10_5d*/ /// /*54 and 58*/
			 c11_1d c11_2d c11_3d c11_4d {   
			   	
			 local i = `i'+1  
			  gen years_adopt`i'= `var'
			  replace years_adopt`i' =. if `var'==.
			   }

			   
local sectors "3 4 5 6 11 101"

local i = 62
foreach s of local sectors{
local i = `i'+1
gen years_adopt`i'= b12c if a5a==`s'
replace years_adopt`i' =. if b12c==.|a5a!=`s'

}
keep years_adopt* firmid
reshape long years_adopt ,i(firmid) j(bus_fn)
merge 1:1 firmid bus_fn using "FAT0_reshaped_firm_busfn_updated_new.dta"

gen base_ctr_wt2 = base_wt*10000000
gen r_base_ctr_wt = round(base_ctr_wt2)

keep MOST_bus_fn MAX_bus_fn years_adopt r_base_ctr_wt bus_fn anum_bus_fn
gen max_most = 0 if anum_bus_fn> 1 & anum_bus_fn !=.
replace max_most = 1 if MOST_bus_fn== MAX_bus_fn & anum_bus_fn> 1 & anum_bus_fn !=.
replace max_most=. if MOST_bus_fn==.| MAX_bus_fn==.

twoway (hist years_adopt [fw=r_base_ctr_wt] if max_most==0&years_adopt<30, w(5) color(navy%30)) ///
(hist years_adopt [fw=r_base_ctr_wt] if max_most==1&years_adopt<30, w(5) color(maroon%30)) , ///
graphregion(color(white)) ytitle("Density")  xtitle("Years since adoption of top-tier technology")  ///
legend(label(1 "Max{sub:fj}>Most{sub:fj}") label(2 "Max{sub:fj}=Most{sub:fj}" ) col(1) pos(6))
 
 graph export "${path_output}\2_graphs\Figure_7.png",replace 

  
 /*
* black and white version - printed
twoway (hist years_adopt [fw=r_base_ctr_wt] if max_most==0&years_adopt<30, w(5) fcolor(gs6%30) lcolor(none) lwidth(medthick)) ///
(hist years_adopt [fw=r_base_ctr_wt] if max_most==1&years_adopt<30, w(5) fcolor(none) lcolor(black) lwidth(medthick) lpattern(dash))  ///
(line years_adopt years_adopt if years_adopt==., lcolor(black) lwidth(medthick) lpattern(dash)), ///
graphregion(color(white)) ytitle("Density")  xtitle("Years since adoption of top-tier technology")  ///
legend(order(1  "Max{sub:fj}>Most{sub:fj}" 3 "Max{sub:fj}=Most{sub:fj}") col(1) pos(6))	
 
graph export "${path_output}\2_graphs\Figure_7_b.png",replace 
 */



***************************************************************************
******************************* FIGURE 8 **********************************
***************************************************************************
u "${path_import}/FAT0_firm_level.dta", clear     

replace a5a = 101 if a5a == 13 | a5a == 14 | a5a == 15
replace a5a = 102 if a5a == 12

local i = 0
foreach var of varlist  b8c b9c b10c b11c   b13d b14c b15c ///
			 c1_1d c1_2d c1_3d c1_4d c1_5d c1_6d ///
			 c2_1d c2_2d c2_3d c2_4d c2_5d ///
			 c3_1d c3_2d c3_3d c3_4d c3_5d ///
			 c4_1d c4_2d c4_3d c4_4d ///
			 c5_1d c5_2d c5_3d c5_4d c5_5d ///
			 c6_1d c6_2d c6_3d c6_4d c6_5d c6_6d ///
			 c7_1d c7_2d c7_3d c7_4d c7_5d ///
			 c8_1d c8_2d c8_3d c8_4d c8_5d ///
			 c9_1d c9_2d c9_3d c9_4d c9_5d ///
			  /*c10_1d*/ c10_2d c10_3d c10_4d  /*c10_5d*/ /// /*54 and 58*/
			   c11_1d c11_2d c11_3d c11_4d {
			 local i = `i'+1  
			  sum `var' [aw=base_wt], detail
			  gen med_yr`i'=(`var'>r(p50))
			  replace med_yr`i' =. if `var'==.
			   }

local sectors "3 4 5 6 11 101"

local i = 62
foreach s of local sectors{
local i = `i'+1
sum b12c [aw=base_wt] if a5a==`s', detail
gen med_yr`i'=(b12c>r(p50))
replace med_yr`i' =. if b12c==. |a5a!=`s'

}
keep med_yr* firmid base_wt 
reshape long med_yr ,i(firmid) j(bus_fn)
merge 1:1 firmid bus_fn using "FAT0_reshaped_firm_busfn_updated_new.dta"

gen base_ctr_wt2 = base_wt*10000000
gen r_base_ctr_wt = round(base_ctr_wt2)


keep MOST_bus_fn med_yr r_base_ctr_wt anum_bus_fn

twoway ///
	(hist MOST_bus_fn [fw=r_base_ctr_wt] if med_yr==0 & anum_bus_fn> 1 & anum_bus_fn !=. , w(1) color(navy%30)) ///
	(hist MOST_bus_fn [fw=r_base_ctr_wt] if med_yr==1 & anum_bus_fn> 1 & anum_bus_fn !=. , w(1) color(maroon%30)) , ///
	graphregion(color(white)) ytitle("Density")  xtitle("Most{sub:fj}")  ///
	legend(label(1 "Recent adopters") label(2 "Early adopters" ) col(2) pos(6))

graph export "${path_output}\2_graphs\Figure_8.png",replace 

/*
* Black and white version - printed 
twoway ///
	(hist MOST_bus_fn [fw=r_base_ctr_wt] if med_yr==0 & anum_bus_fn> 1 & anum_bus_fn !=. , w(1) fcolor(gs6%30) lcolor(none) lwidth(medthick)) ///
	(hist MOST_bus_fn [fw=r_base_ctr_wt] if med_yr==1 & anum_bus_fn> 1 & anum_bus_fn !=. , w(1) fcolor(none) lcolor(black) lwidth(medthick) lpattern(dash))  ///
	(line MOST_bus_fn MOST_bus_fn if MOST_bus_fn==., lcolor(black) lwidth(medthick) lpattern(dash)), ///
	graphregion(color(white)) ytitle("Density")  xtitle("Most{sub:fj}")  ///
	legend(order(1 "Recent adopters" 3 "Early adopters") col(2) pos(6))	
	
graph export "${path_output}\2_graphs\Figure_8_b.png",replace 	
*/



***************************************************************************
******************************* FIGURE 9 **********************************
***************************************************************************

use "${path_import}/FAT0_reshaped_firm_busfn_updated_new.dta", clear
drop if anum_bus_fn == . | MOST_bus_fn == 0 | MAX_bus_fn== 0
drop if a5a != sector & sector != .
drop sector*

//sector definition
gen sector = 1 if a5a == 1 | a5a == 2
replace sector = 2 if a5a == 3 | a5a == 4 | a5a == 5 | a5a == 6 | a5a == 11 | a5a == 13 | a5a == 14 | a5a == 15 | a5a == 101
replace sector = 3 if a5a == 7 | a5a == 8 | a5a == 9 | a5a == 10 | a5a == 102 | a5a == 12

//country
encode country, generate(countrycode)

//MODEL 1 - ALL
local k = 1
gen fwt = round(10^(`k')*base_wt,1)  
 
collapse (mean) MOST_bus_fn MAX_bus_fn, by(firmid fwt base_wt countrycode a5a sector fage size_group s4 mnc exporter)


* Create the two main graphs with consistent styling
twoway (histogram MAX_bus_fn [fw=fwt], density bin(20) color(midblue)) ///
       (kdensity MAX_bus_fn, lcolor(black) lwidth(medthick)), ///
       xlabel(, nogrid) xtitle("MAXj") ytitle("Density") ///
       legend(order(1 "Density" 2 "Kernel Density") rows(1) position(6) region(lcolor(white))) ///
       name(graph1, replace)

twoway (histogram MOST_bus_fn [fw=fwt], density bin(20) color(midblue)) ///
       (kdensity MOST_bus_fn, bwidth(.2) lcolor(black) lwidth(medthick)), ///
       xlabel(, nogrid) xtitle("MOSTj") ytitle("Density") ///
       legend(off) ///
       name(graph2, replace)


grc1leg graph1 graph2, ///
       cols(2) ///
       legendfrom(graph1) ///
       position(6) rows(1) ///
       imargin(zero) 

graph export "${path_output}\2_graphs\Figure_9.png", replace width(1600) height(600)



***************************************************************************
******************************* FIGURE 10 *********************************
***************************************************************************

u "${path_import}/FAT0_firm_level.dta", clear
collapse (mean) MAX_bus_fn  MOST_bus_fn [pw=base_wt], by(country)

// IMPORT gdp DATA
preserve
	import excel "${path_import}\country_stats_2080.xlsx", sheet("Sheet2") cellrange(A1:C16) firstrow clear
	tempfile gdp
	save `gdp'
restore
merge 1:1 countrycode using `gdp', keep(3) nogen

* Create scatter plot with country labels and trend lines
twoway (scatter MAX_bus_fn lgdp, ///
            mcolor(red) msymbol(circle_hollow) msize(small) ///
            mlabel(country) mlabcolor(red) mlabsize(vsmall) mlabposition(3)) ///
		(lfit MAX_bus_fn lgdp, ///
            lcolor(red) lpattern(dash) lwidth(medium)) ///
       (scatter MOST_bus_fn lgdp, ///
            mcolor(blue) msymbol(plus) msize(small) ///
            mlabel(country) mlabcolor(blue) mlabsize(vsmall) mlabposition(3)) ///    
       (lfit MOST_bus_fn lgdp, ///
            lcolor(blue) lpattern(solid) lwidth(medium)), ///
    xlabel(7(1)11) ylabel(1(0.5)3, angle(0)) ///
    xtitle("Log GDP per capita") ///
    ytitle("Technology Sophistication") ///
	  legend(order(1 "MAX" 2 "" 3 "MOST" 4 "") ///
           position(3) cols(1) region(lcolor(white)) size(small)) ///
    graphregion(color(white)) ///
    plotregion(margin(small))
graph export "${path_output}\2_graphs\Figure_10.png", replace


***************************************************************************
******************************* FIGURE 11 *********************************
***************************************************************************


u "${path_import}/FAT0_firm_level.dta", clear

tabstat MAX_bus_fn  [aw=base_wt], stat(mean p1 p5 p10 p25 p50 p75 p90 p95 p99) by(country)
tabstat  MOST_bus_fn [aw=base_wt], stat(mean p1 p5 p10 p25 p50 p75 p90 p95 p99) by(country)

collapse (mean) mean_max = MAX_bus_fn mean_most= MOST_bus_fn ///
(p5) pc5_max = MAX_bus_fn pc5_most= MOST_bus_fn ///
(p10) pc10_max = MAX_bus_fn pc10_most= MOST_bus_fn ///
(p20) pc20_max = MAX_bus_fn pc20_most= MOST_bus_fn /// 
(p25) pc25_max = MAX_bus_fn pc25_most= MOST_bus_fn /// 
(p50) pc50_max = MAX_bus_fn pc50_most= MOST_bus_fn /// 
(p75) pc75_max = MAX_bus_fn pc75_most= MOST_bus_fn ///
(p80) pc80_max = MAX_bus_fn pc80_most= MOST_bus_fn ///
(p90) pc90_max = MAX_bus_fn pc90_most= MOST_bus_fn ///
(p95) pc95_max = MAX_bus_fn pc95_most= MOST_bus_fn ///
  [pw=base_wt], by(country)


cap drop MAX_spread MOST_spread
gen MAX_spread = pc90_max- pc10_max
gen MOST_spread = pc90_most- pc10_most

preserve
	 collapse (mean) MAX_spread MOST_spread
restore


// IMPORT gdp DATA
preserve
	import excel "${path_import}\country_stats_2080.xlsx", sheet("Sheet2") cellrange(A1:C16) firstrow clear
	tempfile gdp
	save `gdp'
restore
merge 1:1 countrycode using `gdp', keep(3) nogen

corr lgdp MAX_spread
corr lgdp MOST_spread

* Create the scatter plot
twoway (scatter MAX_spread lgdp, ///
            mcolor(red) msymbol(circle_hollow) msize(small) ///
            mlabel(country) mlabcolor(red) mlabsize(vsmall) mlabposition(3)) ///
		(lfit MAX_spread lgdp, ///
            lcolor(red) lpattern(dash) lwidth(medium)) ///
       (scatter MOST_spread lgdp, ///
            mcolor(blue) msymbol(plus) msize(small) ///
            mlabel(country) mlabcolor(blue) mlabsize(vsmall) mlabposition(3)) ///
       (lfit MOST_spread lgdp, ///
            lcolor(blue) lpattern(solid) lwidth(medium)), ///
    xlabel(7(1)11) ylabel(0.5(0.5)3, angle(0)) ///
    xtitle("Log GDP per capita") ///
    ytitle("p90-p10") ///
    legend(order(1 "MAX" 2 "" 3 "MOST" 4 "") ///
           position(3) cols(1) region(lcolor(white)) size(small)) ///
    graphregion(color(white)) ///
    plotregion(margin(small)) ///
    name(spread_plot, replace)
	
graph export "${path_output}\2_graphs\Figure_11.png", replace




