Official World Bank source subset for static provenance inspection

The seven do-files and LICENSE.txt are unchanged copies of the public package
identified in PROVENANCE_R3.json. The complete original licence is retained.
This is a source subset, not a runnable installation of the external project.
Stata was not executed. No input microdata or output tables are included.
No World Bank endorsement or verification of the TASM study is implied.
