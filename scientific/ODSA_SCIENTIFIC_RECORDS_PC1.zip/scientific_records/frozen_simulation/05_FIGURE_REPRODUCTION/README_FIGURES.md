# R2 scientific figures and editable companions

The four publication figures use the supplied `SOURCE_DATA` CSV files. The historical script and file names remain unchanged for traceability. No input numerical field was revised in R2.

## Interpretation

Figure 2 labels the 4,680/8,640 event **No strict reversal with semantic mismatch**. Its 54.2% value is unchanged. The frozen key `rank_stability_with_semantic_mismatch` tests absence of strict reversals, not identity of all pairwise orders. A tie may become a strict order without a strict reversal.

Figure 4 reports **Strictly orderable pair share**. A pair contributes only if one lower bound strictly exceeds the other's upper bound. Exact point ties do not count as strict orders. The no-unresolved benchmark may therefore be below one even though the equal value is known.

Figure 3's platform-or-higher mismatch values are conditional on the frozen synthetic mixture: platform receives 3% and standard software 97% of their combined mass. The three calibration rates do not identify that split. This explanatory clarification does not change the figure.

The underlying Figure 2 counts, denominators and fraction strings and all other scientific CSV values remain the same as R1. See `SOURCE_DATA/R2_LABEL_MAP.csv` and the package-level `06_R2_REPRODUCTION/R1_TO_R2_COMPARISON.json`.

## Contents and provenance

- `TIFF/`: four publisher figures, RGB with LZW compression. Figure 1 is 1,200 dpi; Figures 2-4 are 600 dpi.
- `PNG_QA/`, `SVG/`, `PDF_VECTOR/`: corresponding raster preview and vector publication files.
- `PPTX_EDITABLE/`: one four-slide master and four single-figure decks. The bars, labels and architecture diagram are native editable slide objects. These companions have their own slide layout; TIFF/PDF/SVG are the canonical publication designs.
- `SOURCE_CODE/`: the supplied plotting and PPTX builders, made portable in R2.
- `SOURCE_DATA/`: the supplied scientific figure data, current file inventory and observed build environments.

Publication Figure 1 and Figure 3 files are retained byte-for-byte from R1; their TIFFs are the original separate upload files. Publication Figures 2 and 4 were re-exported after the label corrections. The editable companions were regenerated from the supplied builder and data. The R2 builder additionally makes percentage ticks fit on one line, restores architecture arrowheads and provides the Figure 3B scale and legend.

`SOURCE_DATA/EINT_R5_FIGURE_FILE_MANIFEST.csv` indexes only files actually present, with relative paths, sizes and SHA-256. It makes no claim that EPS or JPEG files are supplied. `EINT_R5_FIGURE_ENVIRONMENT.json` is the unchanged historical environment record; its old format list describes the earlier build rather than this archive's inventory. Current environments are in `R2_FIGURE_BUILD_ENVIRONMENT.json` and `R2_PPTX_BUILD_ENVIRONMENT.json`.

## Dependencies and rebuilding

Use a separate Python environment. The simulator requirements in `../03_EXECUTABLE/requirements.txt` are unchanged. Figure requirements are separate and pin the versions actually observed in the R2 Linux build: matplotlib 3.10.8, pandas 2.2.3, Pillow 13.0.0 and NumPy 2.3.5. The optional editable-deck requirements add python-pptx 1.0.2. Python 3.12.14 was used for this build. These are observed versions, not claims that all other versions fail.

Both scripts default to the directory above their own `SOURCE_CODE` directory. They work independently of the current working directory. `--root` explicitly selects the directory containing `SOURCE_DATA`; it takes precedence over the historical `EINT_R5_FIGURE_ROOT` environment variable.

From PowerShell 5.1, after assigning `$Python` to the virtual environment's Python and `$FigureRoot` to this extracted folder:

```powershell
& $Python -m pip install -r (Join-Path $FigureRoot 'requirements_editable_pptx.txt')
if ($LASTEXITCODE -ne 0) { throw 'Figure dependency installation failed.' }
& $Python -B (Join-Path $FigureRoot 'SOURCE_CODE\EINT_R5_generate_final_figures.py') --root $FigureRoot --figures 2 4
if ($LASTEXITCODE -ne 0) { throw 'Figure generation failed.' }
& $Python -B (Join-Path $FigureRoot 'SOURCE_CODE\EINT_R5_build_editable_pptx.py') --root $FigureRoot
if ($LASTEXITCODE -ne 0) { throw 'Editable figure generation failed.' }
```

For bash, after setting `PYTHON` and `FIGURE_ROOT`:

```bash
"$PYTHON" -m pip install -r "$FIGURE_ROOT/requirements_editable_pptx.txt"
"$PYTHON" -B "$FIGURE_ROOT/SOURCE_CODE/EINT_R5_generate_final_figures.py" --root "$FIGURE_ROOT" --figures 2 4
"$PYTHON" -B "$FIGURE_ROOT/SOURCE_CODE/EINT_R5_build_editable_pptx.py" --root "$FIGURE_ROOT"
```

The plotting default regenerates only Figures 2 and 4. To regenerate all four, explicitly use `--figures 1 2 3 4`. Fresh renders may differ in binary metadata or renderer details; the unchanged R1 figures in the delivered set remain the preserved reference. The scripts refresh the figure inventory. Package-level checksums describe the delivered bytes and will need a new controlled package build after any regeneration.

All four TIFFs, the two affected PDF renders and all four master-deck slide renders were inspected on Linux. The native PowerPoint application and Windows 11 were not used for this verification.
