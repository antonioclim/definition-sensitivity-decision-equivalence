from __future__ import annotations
from pathlib import Path
import argparse
import os
import json
import sys
from importlib.metadata import version
from pptx import Presentation
from pptx.oxml.xmlchemy import OxmlElement
from pptx.util import Inches, Pt
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.enum.shapes import MSO_SHAPE, MSO_CONNECTOR
from pptx.dml.color import RGBColor
from pptx.enum.dml import MSO_LINE_DASH_STYLE
import pandas as pd
import copy

ROOT=Path(os.environ.get('EINT_R5_FIGURE_ROOT', Path(__file__).resolve().parents[1])).expanduser().resolve()
OUT=ROOT/'PPTX_EDITABLE'; DATA=ROOT/'SOURCE_DATA'
W,H=13.333,7.5
C={
'blue':RGBColor(71,124,179),'cyan':RGBColor(89,194,232),'gold':RGBColor(210,190,58),
'green':RGBColor(34,140,53),'red':RGBColor(239,102,115),'ink':RGBColor(34,34,34),
'grey':RGBColor(185,185,185),'grid':RGBColor(207,207,207),'white':RGBColor(255,255,255),
'pale1':RGBColor(240,240,240),'pale2':RGBColor(231,238,245),'pale3':RGBColor(231,241,239),
'pale4':RGBColor(243,239,217),'pale5':RGBColor(242,230,234)}


def new_prs():
    prs=Presentation(); prs.slide_width=Inches(W); prs.slide_height=Inches(H)
    return prs

def add_text(slide,x,y,w,h,text,size=18,bold=False,italic=False,align=PP_ALIGN.CENTER,color=None):
    box=slide.shapes.add_textbox(Inches(x),Inches(y),Inches(w),Inches(h))
    tf=box.text_frame; tf.clear(); tf.word_wrap=True; tf.vertical_anchor=MSO_ANCHOR.MIDDLE
    tf.margin_left=Inches(0.025); tf.margin_right=Inches(0.025)
    tf.margin_top=Inches(0.015); tf.margin_bottom=Inches(0.015)
    p=tf.paragraphs[0]; p.alignment=align
    r=p.add_run(); r.text=text; r.font.name='Arial'; r.font.size=Pt(size); r.font.bold=bold; r.font.italic=italic
    r.font.color.rgb=color or C['ink']
    return box

def add_title(slide,text):
    return add_text(slide,0.35,0.12,12.63,0.58,text,24,True)

def add_rect(slide,x,y,w,h,fill,line=C['ink'],radius=True):
    shape=slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE if radius else MSO_SHAPE.RECTANGLE,
                                 Inches(x),Inches(y),Inches(w),Inches(h))
    shape.fill.solid(); shape.fill.fore_color.rgb=fill
    shape.line.color.rgb=line; shape.line.width=Pt(1.2)
    return shape

def add_line(slide,x1,y1,x2,y2,color=C['grid'],dash=False,width=1):
    line=slide.shapes.add_connector(MSO_CONNECTOR.STRAIGHT,Inches(x1),Inches(y1),Inches(x2),Inches(y2))
    line.line.color.rgb=color; line.line.width=Pt(width)
    if dash: line.line.dash_style=MSO_LINE_DASH_STYLE.DASH
    return line

def add_bar(slide,x,y,w,h,fill):
    r=add_rect(slide,x,y,w,h,fill,radius=False); r.line.width=Pt(0.8); return r

def slide1(slide):
    add_title(slide,'Outcome-Definition Sensitivity Analysis (ODSA)')
    boxes=[
        (0.2,1.65,2.45,2.45,'1','Technological\nstate register','Mutually exclusive\nobserved states',C['pale1']),
        (2.82,1.65,2.15,2.45,'2','Adoption\nboundary','Subset of states',C['pale2']),
        (5.16,1.65,2.15,2.45,'3','Indicator','Level, composition\nand ordering',C['pale3']),
        (7.50,1.65,2.55,2.45,'4','Objective and\naction rule','Threshold, top-k or\nrobust ordering',C['pale4']),
        (10.24,1.65,2.82,2.45,'5','Decision\naudit','Entries, exits, loss\nand indeterminacy',C['pale5'])]
    for x,y,w,h,n,t,s,f in boxes:
        add_rect(slide,x,y,w,h,f)
        circ=slide.shapes.add_shape(MSO_SHAPE.OVAL,Inches(x+0.17),Inches(y+0.16),Inches(0.48),Inches(0.32))
        circ.fill.solid(); circ.fill.fore_color.rgb=C['ink']; circ.line.color.rgb=C['ink']
        add_text(slide,x+0.17,y+0.15,0.48,0.34,n,14,True,color=C['white'])
        add_text(slide,x+0.18,y+0.45,w-0.36,0.92,t,20,True)
        add_text(slide,x+0.15,y+1.48,w-0.30,0.72,s,14)
    for i in range(4):
        x1=boxes[i][0]+boxes[i][2]; x2=boxes[i+1][0]
        ar=slide.shapes.add_connector(MSO_CONNECTOR.STRAIGHT,Inches(x1),Inches(2.88),Inches(x2),Inches(2.88))
        ar.line.color.rgb=C['ink']; ar.line.width=Pt(2)
        arrow=OxmlElement('a:tailEnd'); arrow.set('type','triangle')
        ar._element.spPr.get_or_add_ln().append(arrow)
    add_text(slide,1.3,4.48,10.75,0.72,
             'Observation-process sensitivity is applied after the state boundary is declared:\nsampling, weighting, misclassification and unresolved states.',17)
    add_text(slide,0.7,6.18,11.95,0.58,
             'The audit is objective-relative: it does not identify a universal adoption definition or estimate welfare.',
             15,italic=True)

def slide2(slide):
    add_title(slide,'Diagnostic non-redundancy in the frozen synthetic grid')
    df=pd.read_csv(DATA/'Figure_2_ablation_event_frequencies.csv')
    left=4.05; top=0.82; plotw=7.85; rowh=0.69; maxw=7.5
    for x in range(0,101,20):
        xx=left+maxw*x/100
        add_line(slide,xx,top,xx,5.82,C['grid'],True,0.7)
        add_text(slide,xx-0.25,5.78,0.5,0.34,f'{x}%',10)
    fam={'Level':C['blue'],'Meaning':C['gold'],'Meaning/rank':C['cyan'],'Rank':C['green'],'Action':C['red']}
    for i,row in df.iterrows():
        y=top+0.20+i*rowh
        label=row['diagnostic'].replace('Action change below materiality threshold','Action change below\nmateriality threshold').replace('No strict reversal with semantic mismatch','No strict reversal with\nsemantic mismatch')
        add_text(slide,0.10,y-0.05,3.78,0.58,label,12,align=PP_ALIGN.RIGHT)
        w=maxw*row['fraction']
        add_bar(slide,left,y,w,0.45,fam[row['family']])
        add_text(slide,left+w+0.08,y-0.02,1.55,0.48,f"{100*row['fraction']:.1f}% ({int(row['events']):,}/{int(row['cases']):,})",10,align=PP_ALIGN.LEFT)
    add_text(slide,4.15,6.11,7.5,0.38,'Fraction of prespecified synthetic cases',13)
    # Legend
    legends=[('Level',C['blue']),('Meaning',C['gold']),('Meaning/rank',C['cyan']),('Rank',C['green']),('Action',C['red'])]
    lx=3.15
    for name,col in legends:
        add_bar(slide,lx,6.52,0.30,0.18,col); add_text(slide,lx+0.34,6.43,1.20,0.36,name,10,align=PP_ALIGN.LEFT); lx+=1.76
    add_text(slide,1.4,7.02,10.5,0.35,'Events overlap. Fractions describe the prespecified design, not real-world probabilities.',11,italic=True)

def slide3(slide):
    add_title(slide,'Reference-cell diagnostics: levels, ordering and objective alignment')
    a=pd.read_csv(DATA/'Figure_3_panel_A_reference_rates_mae.csv'); b=pd.read_csv(DATA/'Figure_3_panel_B_reference_ordering.csv'); c=pd.read_csv(DATA/'Figure_3_panel_C_unmatched_objective.csv')
    add_text(slide,0.55,0.72,5.3,0.45,'A. Reference calibration',16,True,align=PP_ALIGN.LEFT)
    # panel A bars
    basey=3.62; xs=[1.35,2.75,4.15]; cols=[C['blue'],C['cyan'],C['gold']]
    for xx,(_,row),col in zip(xs,a.iterrows(),cols):
        h=2.45*row['population_rate']/0.8
        add_bar(slide,xx,basey-h,0.78,h,col)
        add_text(slide,xx-0.18,basey-h-0.45,1.15,0.45,f"{100*row['population_rate']:.2f}%\nMAE {row['observed_mae']:.3f}",10)
        add_text(slide,xx-0.18,3.66,1.15,0.5,row['definition'].replace('Digitally enabled','Digitally\nenabled'),10)
    add_text(slide,0.20,1.22,1.25,0.35,'Population rate',10,align=PP_ALIGN.LEFT)
    # panel B
    add_text(slide,6.3,0.72,6.0,0.45,'B. Sampling consequences',16,True,align=PP_ALIGN.LEFT)
    labels=['Integrated ->\nspecialised','Specialised ->\ndigitally enabled','Integrated ->\ndigitally enabled']
    for i,(_,row) in enumerate(b.iterrows()):
        y=1.35+i*0.95
        add_text(slide,6.0,y-0.2,1.55,0.55,labels[i],10,align=PP_ALIGN.RIGHT)
        add_line(slide,7.65,y,12.5,y,C['grey'],False,1)
        for val,col,shape in [(row['strict_reversal_share'],C['green'],MSO_SHAPE.OVAL),(row['highest_top3_churn'],C['red'],MSO_SHAPE.RECTANGLE)]:
            x=7.65+4.65*val/0.5
            s=slide.shapes.add_shape(shape,Inches(x-0.07),Inches(y-0.07),Inches(0.14),Inches(0.14)); s.fill.solid(); s.fill.fore_color.rgb=col; s.line.color.rgb=C['ink']
    for tick in range(0, 51, 10):
        xx=7.65+4.65*tick/50
        add_text(slide,xx-0.22,3.52,0.44,0.26,f'{tick}%',9)
    add_text(slide,8.3,3.85,3.7,0.32,'Observed synthetic share',10)
    for xx, name, colour, shape in [(8.0,'Strict reversal',C['green'],MSO_SHAPE.OVAL),(10.05,'Highest top-3 churn',C['red'],MSO_SHAPE.RECTANGLE)]:
        mark=slide.shapes.add_shape(shape,Inches(xx),Inches(4.21),Inches(0.13),Inches(0.13))
        mark.fill.solid(); mark.fill.fore_color.rgb=colour; mark.line.color.rgb=C['ink']
        add_text(slide,xx+0.17,4.12,2.20,0.31,name,9,align=PP_ALIGN.LEFT)
    # panel C
    add_text(slide,0.55,4.52,6.0,0.45,'C. Objective-relative mismatch',16,True,align=PP_ALIGN.LEFT)
    ys=[5.15,5.75,6.35]
    for y,(_,row),col in zip(ys,c.iterrows(),cols):
        add_text(slide,0.25,y-0.08,1.52,0.35,row['definition'],10,align=PP_ALIGN.RIGHT)
        w=9.25*row['semantic_mismatch_mass']/0.65
        add_bar(slide,1.9,y,w,0.38,col)
        add_text(slide,1.9+w+0.08,y-0.03,2.3,0.38,f"{100*row['semantic_mismatch_mass']:.1f}% - {row['mismatch_type'].lower()}",10,align=PP_ALIGN.LEFT)
    add_text(slide,3.2,6.80,7.0,0.35,'State mass relative to the platform-or-higher objective',11)
    add_text(slide,1.0,7.08,11.4,0.30,'The cell is synthetic and calibrated to disclosure-cleared Study 2 medians; it is not a country or firm comparison.',10,italic=True)

def slide4(slide):
    add_title(slide,'Unresolved states reduce strict-order determinacy')
    df=pd.read_csv(DATA/'Figure_4_unresolved_determinacy.csv')
    defs=['Integrated','Specialised','Digitally enabled']; profiles=['No unresolved','Independent ≈5% unresolved','State-dependent unresolved']; cols=[C['blue'],C['gold'],C['red']]
    basey=5.65; maxh=4.45; gx=[1.65,5.30,8.95]
    for g,d in enumerate(defs):
        for i,(p,col) in enumerate(zip(profiles,cols)):
            val=float(df[(df.definition==d)&(df.profile==p)].determinate_pair_share.iloc[0]); x=gx[g]+i*0.82; h=maxh*val
            add_bar(slide,x,basey-h,0.74,h,col); add_text(slide,x-0.05,basey-h-0.35,0.85,0.30,f'{val:.3f}',10)
        add_text(slide,gx[g]+0.15,5.78,2.1,0.42,d,12)
    add_text(slide,0.05,1.28,1.55,0.82,'Strictly orderable pair share',10,align=PP_ALIGN.LEFT)
    lx=2.45
    for p,col in zip(profiles,cols):
        add_bar(slide,lx,6.42,0.35,0.20,col); add_text(slide,lx+0.43,6.34,2.45,0.38,p,10,align=PP_ALIGN.LEFT); lx+=3.05
    add_text(slide,0.8,6.90,11.7,0.52,'Strict interval separation is required. Exact point ties are not strict orders.\nWorst-case assignment bounds are deterministic bounds, not confidence intervals.',10,italic=True)

def make_master():
    prs=new_prs()
    funcs=[slide1,slide2,slide3,slide4]
    for func in funcs:
        slide=prs.slides.add_slide(prs.slide_layouts[6]); func(slide)
    # remove default first slide if present (Presentation has no slides initially with this template)
    path=OUT/'EINT_R5_ALL_FIGURES_EDITABLE_MASTER.pptx'; prs.save(path)
    return path

def save_individual(master_path):
    # Rebuild one slide per presentation to avoid unsupported slide-copy internals.
    funcs=[slide1,slide2,slide3,slide4]
    for i,func in enumerate(funcs,1):
        prs=new_prs(); slide=prs.slides.add_slide(prs.slide_layouts[6]); func(slide)
        prs.save(OUT/f'Figure_{i}_EDITABLE.pptx')

def main():
    global ROOT, OUT, DATA
    parser=argparse.ArgumentParser(description='Rebuild the supplied editable figure deck as native PowerPoint objects.')
    parser.add_argument('--root',type=Path,default=ROOT,help='Directory containing SOURCE_DATA.')
    args=parser.parse_args()
    ROOT=args.root.expanduser().resolve(); OUT=ROOT/'PPTX_EDITABLE'; DATA=ROOT/'SOURCE_DATA'
    if not DATA.is_dir():
        raise SystemExit(f'SOURCE_DATA not found beneath figure root: {ROOT}')
    OUT.mkdir(parents=True,exist_ok=True)
    m=make_master(); save_individual(m)
    environment={'python':sys.version.split()[0], 'python-pptx':version('python-pptx'),
                 'pandas':pd.__version__, 'source':'Supplied historical native-object builder, made portable in R2.',
                 'scope':'Editable companion drawings. TIFF/PDF/SVG are the canonical publication figures.'}
    (DATA/'R2_PPTX_BUILD_ENVIRONMENT.json').write_text(json.dumps(environment,indent=2)+'\n',encoding='utf-8')
    # Refresh the common inventory after PPTX generation without re-rendering any scientific plots.
    from EINT_R5_generate_final_figures import configure_root, update_manifest
    configure_root(ROOT)
    update_manifest(None)
    print('PASS',m)
if __name__=='__main__': main()
