from __future__ import annotations

from pathlib import Path
import argparse
import hashlib
import json
import os
import sys

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Patch
import numpy as np
import pandas as pd
from PIL import Image

# Historical script name retained; R2 paths are relative to the extracted kit.
# --root overrides this environment variable without requiring a particular cwd.
ROOT = Path(os.environ.get('EINT_R5_FIGURE_ROOT', Path(__file__).resolve().parents[1])).expanduser().resolve()
FORMATS = [('TIFF', 'tif'), ('PNG_QA', 'png'), ('SVG', 'svg'), ('PDF_VECTOR', 'pdf')]
DIRS = {name: ROOT / name for name in [*(f[0] for f in FORMATS), 'SOURCE_DATA']}


def configure_root(root: Path) -> None:
    global ROOT, DIRS
    ROOT = root.expanduser().resolve()
    DIRS = {name: ROOT / name for name in [*(f[0] for f in FORMATS), 'SOURCE_DATA']}
    if not DIRS['SOURCE_DATA'].is_dir():
        raise SystemExit(f'SOURCE_DATA not found beneath figure root: {ROOT}')
    for name, directory in DIRS.items():
        if name != 'SOURCE_DATA':
            directory.mkdir(parents=True, exist_ok=True)

COL = {
    'blue': '#477CB3',
    'cyan': '#59C2E8',
    'gold': '#D2BE3A',
    'green': '#228C35',
    'red': '#EF6673',
    'ink': '#222222',
    'grey': '#B9B9B9',
    'grid': '#CFCFCF',
    'pale1': '#F0F0F0',
    'pale2': '#E7EEF5',
    'pale3': '#E7F1EF',
    'pale4': '#F3EFD9',
    'pale5': '#F2E6EA',
}
HATCH = {'blue': '//', 'cyan': 'xx', 'gold': '..', 'green': '++', 'red': '\\'}

plt.rcParams.update({
    'font.family': 'DejaVu Sans',
    'font.size': 11,
    'axes.titlesize': 15,
    'axes.labelsize': 12,
    'xtick.labelsize': 10.5,
    'ytick.labelsize': 10.5,
    'legend.fontsize': 10,
    'axes.linewidth': 1.0,
    'savefig.facecolor': 'white',
    'figure.facecolor': 'white',
    'pdf.fonttype': 42,
    'ps.fonttype': 42,
    'svg.fonttype': 'none',
    'hatch.linewidth': 0.8,
})

STEMS = [
    'Figure_1_ODSA_Economic_Decision_Architecture',
    'Figure_2_Diagnostic_Nonredundancy',
    'Figure_3_Reference_Cell_Diagnostics',
    'Figure_4_Unresolved_State_Determinacy',
]


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def save_all(fig, stem: str, dpi: int) -> None:
    # PNG is retained as the exact QA/render source. TIFF is publisher-facing.
    png = DIRS['PNG_QA'] / f'{stem}.png'
    fig.savefig(png, dpi=dpi, bbox_inches='tight', pad_inches=0.08, facecolor='white')
    fig.savefig(DIRS['SVG'] / f'{stem}.svg', bbox_inches='tight', pad_inches=0.08, facecolor='white')
    fig.savefig(DIRS['PDF_VECTOR'] / f'{stem}.pdf', bbox_inches='tight', pad_inches=0.08, facecolor='white')
    plt.close(fig)
    with Image.open(png) as im:
        rgb = im.convert('RGB')
        rgb.save(DIRS['TIFF'] / f'{stem}.tif', compression='tiff_lzw', dpi=(dpi, dpi))


def fig1() -> None:
    data = pd.read_csv(DIRS['SOURCE_DATA'] / 'Figure_1_architecture_register.csv')
    fig, ax = plt.subplots(figsize=(15.5, 6.1))
    ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.axis('off')
    ax.text(0.5, 0.91, 'Outcome-Definition Sensitivity Analysis (ODSA)',
            ha='center', va='center', fontsize=24, fontweight='bold')
    boxes = [
        (0.018, 0.36, 0.176, 0.36, 'Technological\nstate register', 'Mutually exclusive\nobserved states', COL['pale1']),
        (0.211, 0.36, 0.176, 0.36, 'Adoption\nboundary', 'Subset of states', COL['pale2']),
        (0.404, 0.36, 0.176, 0.36, 'Indicator', 'Level, composition\nand ordering', COL['pale3']),
        (0.597, 0.36, 0.176, 0.36, 'Objective and\naction rule', 'Threshold, top-k or\nrobust ordering', COL['pale4']),
        (0.790, 0.36, 0.192, 0.36, 'Decision\naudit', 'Entries, exits, loss\nand indeterminacy', COL['pale5']),
    ]
    for idx, (x, y, w, h, title, sub, face) in enumerate(boxes, start=1):
        patch = FancyBboxPatch((x, y), w, h, boxstyle='round,pad=0.006,rounding_size=0.015',
                               linewidth=1.6, edgecolor=COL['ink'], facecolor=face)
        ax.add_patch(patch)
        circle = plt.Circle((x + 0.034, y + h - 0.048), 0.023, facecolor=COL['ink'], edgecolor=COL['ink'])
        ax.add_patch(circle)
        ax.text(x + 0.034, y + h - 0.048, str(idx), ha='center', va='center', color='white',
                fontsize=12.5, fontweight='bold')
        ax.text(x + w/2, y + h*0.68, title, ha='center', va='center', fontsize=17.5,
                fontweight='bold', linespacing=0.9)
        ax.text(x + w/2, y + h*0.31, sub, ha='center', va='center', fontsize=13.3, linespacing=0.95)
    for i in range(4):
        x1 = boxes[i][0] + boxes[i][2]
        x2 = boxes[i+1][0]
        ax.add_patch(FancyArrowPatch((x1 + 0.002, 0.54), (x2 - 0.002, 0.54),
                                     arrowstyle='-|>', mutation_scale=24, linewidth=1.6,
                                     color=COL['ink']))
    ax.text(0.5, 0.235,
            'Observation-process sensitivity is applied after the state boundary is declared:\n'
            'sampling, weighting, misclassification and unresolved states.',
            ha='center', va='center', fontsize=15)
    ax.text(0.5, 0.095,
            'The audit is objective-relative: it does not identify a universal adoption definition or estimate welfare.',
            ha='center', va='center', fontsize=14, fontstyle='italic')
    save_all(fig, STEMS[0], 1200)


def fig2() -> None:
    df = pd.read_csv(DIRS['SOURCE_DATA'] / 'Figure_2_ablation_event_frequencies.csv')
    # Preserve the evidence order in the register.
    fig, ax = plt.subplots(figsize=(12.1, 7.2))
    y = np.arange(len(df))[::-1]
    colours = {'Level': COL['blue'], 'Meaning': COL['gold'], 'Meaning/rank': COL['cyan'],
               'Rank': COL['green'], 'Action': COL['red']}
    hatch = {'Level': HATCH['blue'], 'Meaning': HATCH['gold'], 'Meaning/rank': HATCH['cyan'],
             'Rank': HATCH['green'], 'Action': HATCH['red']}
    bars = ax.barh(y, df['fraction'], color=[colours[f] for f in df['family']],
                   hatch=[hatch[f] for f in df['family']], edgecolor=COL['ink'], linewidth=0.9)
    wraps = {
        'No strict reversal with semantic mismatch': 'No strict reversal with\nsemantic mismatch',
        'Numerical difference but same action': 'Numerical difference but\nsame action',
        'Material level change but same action': 'Material level change but\nsame action',
        'Action change below materiality threshold': 'Action change below\nmateriality threshold',
    }
    labels = [wraps.get(label, label) for label in df['diagnostic']]
    ax.set_yticks(y, labels)
    ax.set_xlim(0, 1.02)
    ax.set_xlabel('Fraction of prespecified synthetic cases')
    ax.set_title('Diagnostic non-redundancy in the frozen synthetic grid', fontweight='bold', pad=14)
    ax.set_xticks(np.arange(0, 1.01, 0.2), [f'{int(x*100)}%' for x in np.arange(0,1.01,0.2)])
    ax.grid(axis='x', linestyle='--', color=COL['grid'], alpha=0.9)
    ax.set_axisbelow(True)
    for bar, frac, ev, cases in zip(bars, df['fraction'], df['events'], df['cases']):
        ax.text(frac + 0.012, bar.get_y() + bar.get_height()/2,
                f'{100*frac:.1f}% ({int(ev):,}/{int(cases):,})', va='center', fontsize=10.5)
    handles = [
        Patch(facecolor=COL['blue'], edgecolor=COL['ink'], hatch=HATCH['blue'], label='Level'),
        Patch(facecolor=COL['gold'], edgecolor=COL['ink'], hatch=HATCH['gold'], label='Meaning'),
        Patch(facecolor=COL['cyan'], edgecolor=COL['ink'], hatch=HATCH['cyan'], label='Meaning/rank'),
        Patch(facecolor=COL['green'], edgecolor=COL['ink'], hatch=HATCH['green'], label='Rank'),
        Patch(facecolor=COL['red'], edgecolor=COL['ink'], hatch=HATCH['red'], label='Action'),
    ]
    ax.legend(handles=handles, ncol=5, frameon=False, loc='upper center', bbox_to_anchor=(0.5, -0.14))
    for s in ['top','right']:
        ax.spines[s].set_visible(False)
    fig.text(0.5, 0.015,
             'Events overlap. Fractions describe the prespecified design, not real-world probabilities.',
             ha='center', fontsize=10.5, fontstyle='italic')
    fig.subplots_adjust(left=0.32, right=0.95, bottom=0.24, top=0.88)
    save_all(fig, STEMS[1], 600)


def fig3() -> None:
    a = pd.read_csv(DIRS['SOURCE_DATA'] / 'Figure_3_panel_A_reference_rates_mae.csv')
    b = pd.read_csv(DIRS['SOURCE_DATA'] / 'Figure_3_panel_B_reference_ordering.csv')
    c = pd.read_csv(DIRS['SOURCE_DATA'] / 'Figure_3_panel_C_unmatched_objective.csv')
    fig = plt.figure(figsize=(12.4, 8.9))
    gs = fig.add_gridspec(2, 2, height_ratios=[1.05, 0.85], hspace=0.55, wspace=0.38)
    ax1 = fig.add_subplot(gs[0,0]); ax2 = fig.add_subplot(gs[0,1]); ax3 = fig.add_subplot(gs[1,:])
    fig.suptitle('Reference-cell diagnostics: levels, ordering and objective alignment',
                 fontsize=17, fontweight='bold', y=0.98)
    # Panel A
    x = np.arange(3)
    colours = [COL['blue'], COL['cyan'], COL['gold']]
    hatches = [HATCH['blue'], HATCH['cyan'], HATCH['gold']]
    bars = ax1.bar(x, a['population_rate'], color=colours, hatch=hatches,
                   edgecolor=COL['ink'], linewidth=0.9)
    ax1.set_xticks(x, ['Integrated', 'Specialised', 'Digitally\nenabled'])
    ax1.set_ylabel('Population rate')
    ax1.set_ylim(0, 0.82)
    ax1.set_yticks(np.arange(0,0.81,0.1), [f'{int(v*100)}%' for v in np.arange(0,0.81,0.1)])
    ax1.set_title('A. Reference calibration', loc='left', fontweight='bold')
    ax1.grid(axis='y', linestyle='--', color=COL['grid']); ax1.set_axisbelow(True)
    for bar, rate, mae in zip(bars, a['population_rate'], a['observed_mae']):
        ax1.text(bar.get_x()+bar.get_width()/2, rate+0.018,
                 f'{100*rate:.2f}%\nMAE {mae:.3f}', ha='center', va='bottom', fontsize=9.6)
    # Panel B: lollipop paired diagnostics.
    yy = np.arange(3)
    ax2.hlines(yy, 0, b['highest_top3_churn'], color=COL['grey'], linewidth=1.2)
    ax2.scatter(b['strict_reversal_share'], yy, s=70, color=COL['green'], edgecolor=COL['ink'], zorder=3,
                label='Strict reversal')
    ax2.scatter(b['highest_top3_churn'], yy, s=70, marker='s', color=COL['red'], edgecolor=COL['ink'], zorder=3,
                label='Highest top-3 churn')
    ax2.set_yticks(yy, ['Integrated ->\nspecialised', 'Specialised ->\ndigitally enabled',
                        'Integrated ->\ndigitally enabled'])
    ax2.invert_yaxis(); ax2.set_xlim(0,0.53)
    ax2.set_xticks(np.arange(0,0.51,0.1), [f'{int(v*100)}%' for v in np.arange(0,0.51,0.1)])
    ax2.set_xlabel('Observed synthetic share')
    ax2.set_title('B. Sampling consequences', loc='left', fontweight='bold')
    ax2.grid(axis='x', linestyle='--', color=COL['grid']); ax2.set_axisbelow(True)
    ax2.legend(frameon=False, loc='lower right')
    # Panel C
    y3 = np.arange(3)
    bars3 = ax3.barh(y3, c['semantic_mismatch_mass'], color=colours, hatch=hatches,
                     edgecolor=COL['ink'], linewidth=0.9)
    ax3.set_yticks(y3, ['Integrated', 'Specialised', 'Digitally enabled'])
    ax3.invert_yaxis(); ax3.set_xlim(0,0.68)
    ax3.set_xticks(np.arange(0,0.61,0.1), [f'{int(v*100)}%' for v in np.arange(0,0.61,0.1)])
    ax3.set_xlabel('State mass relative to the platform-or-higher objective')
    ax3.set_title('C. Objective-relative mismatch', loc='left', fontweight='bold')
    ax3.grid(axis='x', linestyle='--', color=COL['grid']); ax3.set_axisbelow(True)
    for bar, mass, typ in zip(bars3, c['semantic_mismatch_mass'], c['mismatch_type']):
        ax3.text(mass + 0.012, bar.get_y()+bar.get_height()/2,
                 f'{100*mass:.1f}% - {typ.lower()}', va='center', fontsize=10.3)
    for ax in [ax1,ax2,ax3]:
        for s in ['top','right']:
            ax.spines[s].set_visible(False)
    fig.text(0.5, 0.018,
             'The cell is synthetic and calibrated to disclosure-cleared Study 2 medians; it is not a country or firm comparison.',
             ha='center', fontsize=10.3, fontstyle='italic')
    fig.subplots_adjust(left=0.11, right=0.97, top=0.91, bottom=0.10)
    save_all(fig, STEMS[2], 600)


def fig4() -> None:
    df = pd.read_csv(DIRS['SOURCE_DATA'] / 'Figure_4_unresolved_determinacy.csv')
    definitions = ['Integrated','Specialised','Digitally enabled']
    profiles = ['No unresolved','Independent ≈5% unresolved','State-dependent unresolved']
    colours = [COL['blue'], COL['gold'], COL['red']]
    hatches = [HATCH['blue'], HATCH['gold'], HATCH['red']]
    fig, ax = plt.subplots(figsize=(11.5, 6.8))
    x = np.arange(3); width = 0.235
    for i, (profile, colour, hatch) in enumerate(zip(profiles, colours, hatches)):
        vals = [float(df[(df['definition']==d) & (df['profile']==profile)]['determinate_pair_share'].iloc[0])
                for d in definitions]
        bars = ax.bar(x + (i-1)*width, vals, width=width, label=profile, color=colour,
                      hatch=hatch, edgecolor=COL['ink'], linewidth=0.9)
        for bar, val in zip(bars, vals):
            ax.text(bar.get_x()+bar.get_width()/2, val+0.02, f'{val:.3f}', ha='center', va='bottom', fontsize=10)
    ax.set_xticks(x, definitions)
    ax.set_ylim(0,1.08)
    ax.set_ylabel('Strictly orderable pair share')
    ax.set_title('Unresolved states reduce strict-order determinacy', fontsize=17, fontweight='bold', pad=12)
    ax.grid(axis='y', linestyle='--', color=COL['grid']); ax.set_axisbelow(True)
    ax.legend(frameon=False, ncol=3, loc='upper center', bbox_to_anchor=(0.5,-0.13))
    for s in ['top','right']:
        ax.spines[s].set_visible(False)
    fig.text(0.5,0.018,
             'Strict interval separation is required. Exact point ties are not strict orders.\n'
             'Worst-case assignment bounds are deterministic bounds, not confidence intervals.',
             ha='center', fontsize=10.5, fontstyle='italic')
    fig.subplots_adjust(left=0.12, right=0.97, top=0.89, bottom=0.22)
    save_all(fig, STEMS[3], 600)


def update_manifest(selected_figures: list[int] | None) -> None:
    # Index only existing deliverables. No claims about absent EPS/JPEG exports.
    records = []
    for stem in STEMS:
        for folder, ext in FORMATS:
            path = DIRS[folder] / f'{stem}.{ext}'
            if path.is_file():
                records.append({'figure': stem, 'format': folder,
                                'filename': path.name,
                                'path': path.relative_to(ROOT).as_posix(),
                                'bytes': path.stat().st_size, 'sha256': sha256(path)})
    for path in sorted((ROOT / 'PPTX_EDITABLE').glob('*.pptx')):
        records.append({'figure': path.stem, 'format': 'PPTX_EDITABLE',
                        'filename': path.name,
                        'path': path.relative_to(ROOT).as_posix(),
                        'bytes': path.stat().st_size, 'sha256': sha256(path)})
    pd.DataFrame(records).to_csv(DIRS['SOURCE_DATA'] / 'EINT_R5_FIGURE_FILE_MANIFEST.csv', index=False)
    environment = {
        'record_type': 'R2 figure rebuild environment observed at execution',
        'python': sys.version.split()[0], 'matplotlib': matplotlib.__version__,
        'pandas': pd.__version__, 'numpy': np.__version__, 'pillow': Image.__version__,
        'selected_figures_rebuilt': selected_figures,
        'unselected_figures': 'Existing files are retained without re-rendering.',
        'formats_generated': [folder for folder, _ in FORMATS],
        'indexed_existing_files': len(records),
        'historical_environment': 'EINT_R5_FIGURE_ENVIRONMENT.json is preserved as a historical record, not a current inventory.'
    }
    if selected_figures is not None:
        (DIRS['SOURCE_DATA'] / 'R2_FIGURE_BUILD_ENVIRONMENT.json').write_text(
            json.dumps(environment, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'status': 'PASS', 'selected_figures_rebuilt': selected_figures,
                      'figure_files_indexed': len(records), 'root': str(ROOT)}, indent=2))


def main() -> None:
    parser = argparse.ArgumentParser(description='Regenerate the supplied scientific figures from their registered CSV data.')
    parser.add_argument('--root', type=Path, default=ROOT,
                        help='Figure-kit directory containing SOURCE_DATA (default: parent of SOURCE_CODE).')
    parser.add_argument('--figures', type=int, choices=(1, 2, 3, 4), nargs='+', default=[2, 4],
                        help='Figures to regenerate; R2 defaults to the two corrected figures, 2 and 4.')
    args = parser.parse_args()
    configure_root(args.root)
    selected = list(dict.fromkeys(args.figures))
    functions = {1: fig1, 2: fig2, 3: fig3, 4: fig4}
    for number in selected:
        functions[number]()
    update_manifest(selected)


if __name__ == '__main__':
    main()
