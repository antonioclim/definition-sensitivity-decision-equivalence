#!/usr/bin/env node
/**
 * Exact historical HTML-script replay with a minimal DOM adapter.
 * The parser, formulae, gates and aggregation are unchanged.
 * No input rows or source-stratum results are printed or saved.
 */
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import crypto from 'node:crypto';
import { performance } from 'node:perf_hooks';

const PIN = {
  source: '72f4dea52a586f8c59c5fc60fe9834154c1ba3065d517ada930d2c83593549c8',
  csv: 'f61a2c6e09f4763818ae1d4db8b330e97bffd8bb0824c2d833b79d728152bd17',
  csvBytes: 19633172,
  csvName: 'fat0_raw_data_qje.csv',
  primary: 'f656b1049d5e21e9a950ddb6bdcfe748ce06671e84d72aa979f1b58599d1aad3',
  sensitivity: 'a78301a4d75adbb462bd7d9a596eefac8a5c6ef81d1fff99c254f32de08c845c',
  aggregate: 'b18fa495616d28bcb315634c6247e2c8c94aa10724759e82cabed19a03251fe0'
};
function digest(bytes) { return crypto.createHash('sha256').update(bytes).digest('hex'); }
function ensure(ok, message) { if (!ok) throw new Error(message); }
function readPinned(filename, expected) {
  const bytes = fs.readFileSync(filename);
  ensure(digest(bytes) === expected, 'Pinned fingerprint mismatch: ' + path.basename(filename));
  return bytes;
}
function parseArgs(args) {
  const out = {};
  for (let i = 0; i < args.length; i++) {
    if (args[i] === '--selftest') out.selftest = true;
    else if (args[i] === '--help') out.help = true;
    else {
      ensure(['--source-root', '--csv', '--out'].includes(args[i]), 'Unknown argument');
      ensure(i + 1 < args.length, 'Argument value missing');
      out[args[i].slice(2)] = args[++i];
    }
  }
  return out;
}
function compare(actual, expected, name) {
  const result = { name, status: 'PASS', leaf_comparisons: 0, numeric_comparisons: 0,
    exact_numeric_matches: 0, maximum_absolute_numeric_difference: 0, mismatches: [] };
  function walk(a, e, p) {
    if (e !== null && typeof e === 'object') {
      if (a === null || typeof a !== 'object' || Array.isArray(a) !== Array.isArray(e)) {
        result.mismatches.push({ path: p, reason: 'type' }); return;
      }
      if (JSON.stringify(Object.keys(a).sort()) !== JSON.stringify(Object.keys(e).sort()))
        result.mismatches.push({ path: p, reason: 'keys' });
      for (const k of Object.keys(e)) walk(a[k], e[k], p + '/' + k);
      return;
    }
    result.leaf_comparisons++;
    if (typeof e === 'number') {
      result.numeric_comparisons++;
      if (typeof a === 'number' && Number.isFinite(a)) {
        result.maximum_absolute_numeric_difference = Math.max(result.maximum_absolute_numeric_difference, Math.abs(a - e));
        if (Object.is(a, e)) result.exact_numeric_matches++;
      }
    }
    if (!Object.is(a, e)) result.mismatches.push({ path: p, reason: 'nonidentical_value' });
  }
  walk(actual, expected, name);
  if (result.mismatches.length) result.status = 'FAIL';
  return result;
}
function stripRankings(ordering) {
  return Object.fromEntries(Object.entries(ordering).map(([weighting, contrasts]) => [
    weighting, Object.fromEntries(Object.entries(contrasts).map(([contrast, value]) => [
      contrast, Object.fromEntries(Object.entries(value).filter(([k]) => !['left_ranking', 'right_ranking'].includes(k)))
    ]))
  ]));
}
function harness(script, bytes) {
  const elements = new Map(), handlers = new Map(), alerts = [];
  let sourceErrorCount = 0, corePublic = null;
  function element(id) {
    if (!elements.has(id)) elements.set(id, {
      hidden: false, disabled: false, checked: false, value: 0, innerHTML: '',
      textContent: '', className: '', children: [],
      appendChild(child) { this.children.push(child); return child; },
      addEventListener(event, callback) { handlers.set(id + ':' + event, callback); },
      click() { throw new Error('UI click/download disabled in this adapter'); }
    });
    return elements.get(id);
  }
  // Transparent observation at the existing aggregate fingerprint operation.
  // Encoded bytes are returned unchanged by the standard encoder.
  class ObservedTextEncoder {
    constructor() { this.encoder = new TextEncoder(); }
    encode(value) {
      const encoded = this.encoder.encode(value);
      if (typeof value === 'string' && value.startsWith('{"claim_boundaries":')) {
        const object = JSON.parse(value);
        if (object.cross_stratum_synthesis && object.ordering_diagnostics && object.source_stratum_results) {
          corePublic = {
            cross_stratum_synthesis: object.cross_stratum_synthesis,
            ordering_diagnostics: stripRankings(object.ordering_diagnostics),
            weighting_sensitivity: object.weighting_sensitivity,
            claim_boundaries: object.claim_boundaries
          };
        }
      }
      return encoded;
    }
  }
  const context = vm.createContext({
    document: { getElementById: element, createElement: tag => element('created-' + elements.size + '-' + tag) },
    TextEncoder: ObservedTextEncoder, TextDecoder, Uint8Array,
    console: { error() { sourceErrorCount++; }, log() {}, warn() {} },
    alert() { alerts.push('historical_source_alert'); }
  });
  vm.runInContext(script, context, { filename: 'unchanged_historical_weighted_sensitivity.js', timeout: 10000 });
  ensure(element('selfTest').textContent.endsWith('PASS'), 'Historical built-in self-test failed');
  if (bytes) {
    element('file').files = [{
      name: PIN.csvName, size: bytes.length,
      arrayBuffer: async () => bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength)
    }];
    // Exact original input hash and size have been verified before confirming
    // this factual file-identity statement to the original handler.
    element('confirm').checked = true;
  }
  return {
    async run() {
      ensure(bytes, 'No verified CSV available');
      const handler = handlers.get('run:click');
      ensure(typeof handler === 'function', 'Historical click handler missing');
      await handler();
      ensure(sourceErrorCount === 0 && alerts.length === 0, 'Historical handler did not complete normally');
      const serialized = vm.runInContext('JSON.stringify(report)', context, { timeout: 10000 });
      ensure(serialized && serialized !== 'null', 'Historical report unavailable');
      ensure(corePublic !== null, 'Aggregate observation was not captured');
      return { internal: JSON.parse(serialized), corePublic };
    },
    selftest() {
      const utf8 = 'a,β,"quoted",\r\n';
      ensure(digest(new ObservedTextEncoder().encode(utf8)) === digest(new TextEncoder().encode(utf8)),
        'Transparent encoder adapter changed bytes');
      const testCode = [
        '(() => { let received = [];',
        'parseCsv("country,base_wt,ib9b1,ib9b2,ib9b3,ib9b4,ib9b5\\r\\nSynthetic,1,1,0,0,0,0\\r\\n", ",", (r,n) => received.push(r));',
        'return {rows:received.length, columns:received[1].length, classification:classifyIndicatorFamily(received[1].slice(2).map(binaryValue)).status}; })()'
      ].join('\n');
      const synthetic = vm.runInContext(testCode, context);
      ensure(synthetic.rows === 2 && synthetic.columns === 7 && synthetic.classification === 'mapped',
        'Synthetic CSV/parser adapter check failed');
      ensure(!('fetch' in context) && !('XMLHttpRequest' in context) && !('require' in context),
        'Unexpected network/filesystem capability in source context');
      return { status: 'PASS', historical_built_in_selftest: 'PASS',
        transparent_text_encoder: 'PASS', synthetic_csv_parser_and_mapping: 'PASS',
        source_context_without_network_or_filesystem_APIs: true,
        microdata_processed_by_selftest: false, browser_interface_acceptance: false };
    }
  };
}

async function main() {
  const args = parseArgs(process.argv.slice(2));
  if (args.help) {
    process.stdout.write('Usage: node replay_historical_source.mjs --source-root PATH --selftest\n' +
      '   or: node replay_historical_source.mjs --source-root PATH --csv PATH --out NEW_JSON_PATH\n' +
      'source-root is the R2 folder 07_RECOVERED_EMPIRICAL_SOURCE. CSV processing is local only.\n');
    return;
  }
  ensure(args['source-root'], '--source-root is required');
  const root = path.resolve(args['source-root']);
  const htmlBytes = readPinned(path.join(root, 'historical_source', 'weighted_sensitivity.html'), PIN.source);
  const matches = [...htmlBytes.toString('utf8').matchAll(/<script>([\s\S]*?)<\/script>/g)];
  ensure(matches.length === 1, 'Exactly one historical inline script required');
  const script = matches[0][1];
  if (args.selftest) {
    ensure(!args.csv && !args.out, 'Selftest does not accept a CSV or output file');
    process.stdout.write(JSON.stringify({ ...harness(script).selftest(), source_sha256: PIN.source,
      node: process.version, platform: process.platform }, null, 2) + '\n');
    return;
  }
  ensure(args.csv && args.out, '--csv and --out are required for replay');
  const input = path.resolve(args.csv), output = path.resolve(args.out);
  ensure(path.basename(input) === PIN.csvName, 'Original CSV filename required');
  ensure(fs.statSync(input).size === PIN.csvBytes, 'Original CSV size mismatch');
  ensure(!fs.existsSync(output), 'Output file already exists');
  ensure(!output.startsWith(root + path.sep) && output !== input, 'Output must be outside pinned sources');
  const bytes = readPinned(input, PIN.csv);
  const primary = JSON.parse(readPinned(path.join(root, 'public_aggregates', 'WORLD_BANK_PUBLIC_RESULT_SUMMARY.json'), PIN.primary));
  const sensitivity = JSON.parse(readPinned(path.join(root, 'public_aggregates', 'WORLD_BANK_PUBLIC_WEIGHTED_MISSINGNESS_SUMMARY.json'), PIN.sensitivity));
  const started = performance.now();
  const adapter = harness(script, bytes);
  const selftest = adapter.selftest();
  const { internal, corePublic } = await adapter.run();
  const comparisons = [];
  for (const field of ['cross_stratum_synthesis', 'ordering_diagnostics', 'weighting_sensitivity', 'claim_boundaries'])
    comparisons.push(compare(corePublic[field], primary[field], 'primary/' + field));
  const bounds = Object.fromEntries(Object.entries(internal.cross_stratum_weighted_sensitivity.definitions)
    .map(([definition, value]) => [definition, Object.fromEntries(['lower', 'complete_case', 'upper', 'width'].map(k => [k, value[k]]))]));
  comparisons.push(compare(bounds, sensitivity.cross_stratum_weighted_bounds, 'sensitivity/bounds'));
  comparisons.push(compare(internal.cross_stratum_weighted_sensitivity.unresolved_weight_share,
    sensitivity.unresolved_weight_share_across_source_strata, 'sensitivity/unresolved_weight_share'));
  comparisons.push(compare(internal.robust_separation_diagnostics, sensitivity.robust_separation, 'sensitivity/robust_separation'));
  comparisons.push(compare(internal.interval_ordering_determinacy, sensitivity.interval_ordering_determinacy, 'sensitivity/interval_ordering'));
  const gates = internal.gates.map(({ id, status, criterion }) => ({ id, status, criterion }));
  const fingerprintPass = internal.primary_result_invariance.matches_expected &&
    internal.primary_result_invariance.observed_sha256 === PIN.aggregate;
  const allPass = comparisons.every(c => c.status === 'PASS') && gates.every(g => g.status === 'PASS') && fingerprintPass;
  const result = {
    schema_version: '1.0', phase: 'TASM R3', date_utc: new Date().toISOString(),
    status: allPass ? 'PASS_EXACT_HISTORICAL_INPUT_REPLAY' : 'FAIL',
    execution: { runtime: process.version, platform: process.platform,
      elapsed_seconds: Number(((performance.now() - started) / 1000).toFixed(6)),
      source_execution: 'Entire unchanged historical inline script, original CSV parser and original file handler; minimal DOM adapter.',
      observer: 'Standard UTF-8 TextEncoder delegation; capture of public aggregate fields at the existing fingerprint operation.',
      original_source_modified: false, actual_browser_interface_executed: false },
    identity: { historical_source_sha256: PIN.source, csv_name: PIN.csvName, csv_bytes: PIN.csvBytes,
      csv_sha256: PIN.csv, csv_crc32: internal.file.crc32,
      public_primary_sha256: PIN.primary, public_sensitivity_sha256: PIN.sensitivity },
    global_analysis_population: {
      total_rows: internal.execution_audit.total_rows,
      mapped_common_denominator: internal.execution_audit.mapped_common_denominator,
      unresolved_rows: internal.execution_audit.unresolved_total_rows,
      source_strata: internal.execution_audit.source_label_count,
      reporting_countries: internal.execution_audit.reporting_country_count
    },
    primary_aggregate_fingerprint: internal.primary_result_invariance,
    gates, comparisons,
    summary: { exact_leaf_comparisons: comparisons.reduce((n, c) => n + c.leaf_comparisons, 0),
      exact_numeric_comparisons: comparisons.reduce((n, c) => n + c.numeric_comparisons, 0),
      maximum_absolute_numeric_difference: Math.max(...comparisons.map(c => c.maximum_absolute_numeric_difference)),
      all_14_historical_gates_pass: gates.length === 14 && gates.every(g => g.status === 'PASS'),
      exact_aggregate_fingerprint_match: fingerprintPass },
    privacy: { input_rows_output_to_console: false, input_rows_written: false,
      source_stratum_rows_output_or_written: false, source_level_counts_output_or_written: false,
      full_internal_report_written: false, source_code_network_API_available: false,
      output_contains_only_identity_global_counts_and_public_aggregate_comparisons: true },
    limitations: {
      upstream_ib9b_construction_verified: false,
      unresolved_any_state_eligibility_verified: false,
      original_download_event_date_verified: false,
      historical_primary_posthoc_hostile_audit_sensitivities_recomputed: false,
      browser_UI_acceptance: false,
      source_internal_gate_labels_are_historical_not_current_publication_approvals: true
    },
    adapter_selftest: selftest
  };
  fs.mkdirSync(path.dirname(output), { recursive: true });
  fs.writeFileSync(output, JSON.stringify(result, null, 2) + '\n', { flag: 'wx', mode: 0o600 });
  process.stdout.write(JSON.stringify({ status: result.status, ...result.summary,
    source_sha256: PIN.source, csv_sha256: PIN.csv, output_file: path.basename(output),
    elapsed_seconds: result.execution.elapsed_seconds }, null, 2) + '\n');
  if (!allPass) process.exitCode = 1;
}
main().catch(error => {
  process.stderr.write(JSON.stringify({ status: 'ERROR', error: error.message }) + '\n');
  process.exitCode = 1;
});
