FAT R14.1: reconstructed execution under the unchanged R13 protocol
================================================================

Purpose and status
------------------
This component executes the registered FAT reconstruction and diagnostics using
the exact canonical CSV, recovered public historical code and unchanged R13
contracts. It is a new R14.1 execution following a numbered recovery amendment.
The lost original R14 scripts, outputs and receipts were not recovered. Previous
R14 outcomes mentioned in the conversation are not evidence for this execution.

The new producer execution, independent reconstruction and diagnostic review
passed. A second actual producer execution used only the included R13 subset.
The six deterministic private normalisation, point-result, tie and reconstruction
files matched the first execution byte for byte. This comparison exports
booleans; it does not export the private file digests or numerical results.

All four new FAT numerical blocks and the exact eligible-unit count remain
WITHHELD. Successful computation is not clearance to release those results.
The registered public historical roster, input identity and older aggregate
baselines are distinguished from the new eligible roster and numerical blocks.

What is supplied
----------------
run_fat_recovery_r14_1.py is the new producer. It first runs the recovered,
unchanged historical replay adapter and original HTML file handler. The new
capture_legacy_private_r14_1.mjs adapter captures original parser/classification
evidence and full original aggregates in protected working files. Python then
parses the canonical CSV independently, reconciles every selected token and
classification with that evidence and reconstructs exact decimal weights.
The calculation uses Fraction arithmetic and the unchanged R13 core/executor.

baselines/ contains byte-identical copies of eight registered public historical
sources, including the replay adapter. frozen_r13/ contains eight necessary
protocol, disclosure, availability and executable-contract files. Their copy
records identify their exact bytes. This is a required-file subset, not the full
R13 archive. In particular, R13_FAT_INPUT_AVAILABILITY.json is preserved as the
historical R13 availability record; it does not describe the recovered input's
availability during R14.1.

check_recovered_sources_r14_1.py verifies the 20 fixed local source-registry
records against recovered R11 and R12 material, including nested archive
members. It is a provenance check, independent of the FAT data calculation.
Its existing receipt records actual matching size/SHA-256 values and CRC checks.
The optional checker needs the recovered R11/R12 packages; the main producer
does not need those full archives.

Frozen inputs
-------------
The raw file is intentionally not included. Use the existing authorised local
copy named fat0_raw_data_qje.csv, exactly 19633172 bytes, with SHA-256:
f61a2c6e09f4763818ae1d4db8b330e97bffd8bb0824c2d833b79d728152bd17

The registered archive was WLD_2019-2023_FAT_v01_M_CSV.zip, with SHA-256:
6d77d3ffb9dcef2ca4534e1c438ddd2e0b357eb852e6c5b48aa5fa6c3cbe2f0e
Recovery used the previously supplied archive, without a new producer login or
new acquisition of FAT data. The producer never contacts a network endpoint.

The caller must also supply the frozen R14_1_AMENDMENT_01_RECOVERY.json from
the recovery package. The required SHA-256 is:
fe1cd65bf92b814575d0096b27ef99c9b2f5e25cdd5d4c99eaffdb9e58c52f7d

The amendment was frozen before the new source parsing and empirical
calculation. It preserves the R13 scientific choices and documents the original
R14 retention failure and prior conversational exposure. Do not silently change
the input, protocol, amendment or pinned source code to make a failed run pass.

Runtime and execution
---------------------
Actually executed: Python 3.12.14, jsonschema 4.26.0 and Node.js v24.22.1 on
Linux. requirements_fat_r14_1.txt pins the direct Python dependency. Python and
Node.js are required separately. The legacy HTML handler is executed with a
minimal DOM inside Node.js. This is not native browser execution. Native
Windows 11/PowerShell execution has not been performed in this environment.

Windows commands, including native-command exit-code checks for PowerShell
5.1, are in GHID_FAT_POWERSHELL51_RO.txt. On an environment with the required
Python and Node.js already available, the general command is:

  python3 -B -X utf8 run_fat_recovery_r14_1.py \
    --csv /authorised/local/fat0_raw_data_qje.csv \
    --r13 ./frozen_r13 \
    --amendment /recovery/package/05_AUDIT_AND_CONTINUITY/R14_1_AMENDMENT_01_RECOVERY.json \
    --private-out /protected/local/new_fat_run \
    --public-receipt /local/review/new_fat_execution_receipt.json

The private output directory and public receipt file must not already exist.
The private output must be outside this public component and the R13 source
tree. The public receipt must be outside the private directory. Existing output
files are not overwritten. For each additional run, choose new output paths.
If Node.js is not on PATH, add --node followed by its executable path.

Only the fixed-gate public receipt is suitable for the public evidence package.
Everything in the private output directory is protected working material.
That includes normalised inputs, source identities, parser traces, historical
handler output, intermediate reconstruction, exact counts, point results,
ties, stdout/stderr logs and hashes of private inputs. Do not upload the private
directory or package it recursively with this component.

The producer writes a success status ending in
AWAITING_INDEPENDENT_RESULT_REVIEW. That statement correctly records the
producer's own stage. The subsequent independent review and acceptance ledger
establish the later status; the historical producer receipt is not rewritten.
An ordinary user rerun does not inherit the independent review of an earlier
run. Repeat the separate verifier if accepting new output files.

The separate independent/ component contains verify_fat_r141.py and its adjacent
r141_independent_math.py. Those scripts use the Python standard library. Keep
them together. To review a new producer run, choose new public and private
report names and execute:

  python3 -B -X utf8 /component/independent/verify_fat_r141.py \
    --protocol ./frozen_r13/04_FROZEN_PROTOCOL/R13_EMPIRICAL_PROTOCOL_EN_GB.json \
    --amendment /recovery/package/05_AUDIT_AND_CONTINUITY/R14_1_AMENDMENT_01_RECOVERY.json \
    --amendment-sha256 fe1cd65bf92b814575d0096b27ef99c9b2f5e25cdd5d4c99eaffdb9e58c52f7d \
    --raw /authorised/local/fat0_raw_data_qje.csv \
    --run /protected/local/new_fat_run \
    --historical-source ./baselines/historical_source_root/historical_source/weighted_sensitivity.html \
    --public-report /local/review/new_independent_public_report.json \
    --private-report /protected/local/new_fat_run/independent_private_report.json

Scope of the registered calculation
----------------------------------
The producer preserves the frozen indicator taxonomy, original positive-weight
classification, exact finite-decimal conversion, small-cell rules and common
eligible universe. It applies the registered primary and secondary selection
rules, cost profiles and semantic comparisons. The matched-row unweighted
comparison uses the same positive-weight mapped rows and the same universe.
The tie supplement distinguishes exact boundary ties from the separately
registered 1e-12 near-tie flag and reports all-admissible point membership in
protected files. Threshold comparison cardinalities are explicit in those
private files. No new FAT unknown-state interval analysis is introduced.

The unchanged historical replay also executes its own historical missingness
sensitivity. Those recovered historical specifications and outputs are not
relabelled as new R13 interval results. No new Monte Carlo replications occur.

Evidence hierarchy
------------------
R14_1_LOCAL_RECOVERY_INVENTORY.json describes the initial restored local
workspace before the recovery downloads. Its absence findings are bounded to
that initial snapshot. They do not contradict the later recovered archives.

R14_1_RECOVERED_SOURCE_IDENTITY_CHECKS.json records current byte checks of
the 20 registered historical sources; a preserved historical report alone is
not a newly executed calculation.

R14_1_FAT_PUBLIC_EXECUTION_RECEIPT.json records the first new execution.
R14_1_FAT_PORTABLE_EXECUTION_RECEIPT.json records the second new execution.
R14_1_FAT_PORTABLE_COMPARISON.json records the exact private-file comparison
without releasing the file digests or protected contents.

The separately supplied R141_FAT_INDEPENDENT_REVIEW_PUBLIC.json and its
verifier record an independent reconstruction from the canonical CSV and
comparison of the full registered results, without importing the producer or
R13 calculation core. The FAT acceptance ledger binds these public receipts.

The legacy replay maximum numerical residual was zero. The new exact-decimal
rate and rate-summary reconciliation maxima were respectively
3.3306690738754696e-16 and 2.220446049250313e-16 against the historical
floating-point outputs, below the registered 1e-12 tolerance. The independent
comparison of the new exact calculations had zero exact residual. These are
verification residuals, not newly released FAT analytical results.

Component integrity and bounded disclosure check
------------------------------------------------
PUBLIC_COMPONENT_MANIFEST.json is the explicit public file inventory with
public-file hashes. The manifest excludes itself. verify_fat_component_r14_1.py
checks that inventory, the unchanged registered source copies, closed execution
receipt fields and the separate independent-review binding. It can also compare
the public files against protected working files for accidental byte-for-byte
copies and embedded protected-output digests. Those private digests are computed
only in memory and never emitted. Write its report outside this component:

  python3 -B -X utf8 verify_fat_component_r14_1.py \
    --component . \
    --independent-review /component/independent/R141_FAT_INDEPENDENT_REVIEW_PUBLIC.json \
    --private-root /protected/local/FAT_runs \
    --raw-csv /authorised/local/fat0_raw_data_qje.csv \
    --report /local/review/new_fat_component_check.json

The private scan is optional for recipients who do not hold the controlled
working files. Omit both --private-root and --raw-csv in that case; the report
records that check as not performed. The actual delivery audit did include the
protected working files. Such a bounded scan does not establish the absence of
every possible disclosure channel. The fixed withholding decision remains.

Limits that remain
------------------
This work does not recover the original R14 payload, erase its retention
failure, establish complete cumulative non-reconstruction or authorise a new
FAT release. It does not establish Scientometrics submission readiness, edit
the manuscript, rerun the large Monte Carlo study or perform Phase 3. Linux
execution, native Windows execution and native browser execution are separate
claims; only the first was observed here.
