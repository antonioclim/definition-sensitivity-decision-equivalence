"""Verify the public FAT component, optionally against protected working files.

Only fixed gates and public-file identities are emitted. Private-file hashes
are compared in memory and are never written to the report or stdout.
"""
from pathlib import Path
from hashlib import sha256
from datetime import datetime, timezone
import argparse
import json
import sys

HERE = Path(__file__).resolve().parent
MANIFEST = 'PUBLIC_COMPONENT_MANIFEST.json'
RECEIPTS = ['R14_1_FAT_PUBLIC_EXECUTION_RECEIPT.json',
            'R14_1_FAT_PORTABLE_EXECUTION_RECEIPT.json']
BLOCKS = ['FAT_PRIMARY', 'FAT_SECONDARY_RULES_COSTS',
          'FAT_MATCHED_ROW_WEIGHTING', 'FAT_TIES']
TOP_KEYS = {
    'schema_version', 'version', 'status', 'started_utc', 'completed_utc',
    'runtime', 'identities_of_public_sources_and_code', 'fixed_gates',
    'maximum_legacy_replay_numeric_residual', 'exact_rate_reconciliation',
    'new_FAT_calculations', 'release_decision', 'new_MC_replications',
    'network_requests', 'new_producer_login_or_access',
    'private_output_hashes_published', 'source_ids_or_vectors_published',
    'input_or_establishment_rows_published', 'data_dependent_check_counts_published',
    'original_R14_bytes_recovered', 'historical_R14', 'limits'
}
FIXED_GATES = {
    'frozen_protocol_and_recovery_amendment_identity', 'registered_CSV_identity',
    'unchanged_historical_HTML_replay', 'independent_CSV_parser_selected_tokens',
    'independent_taxonomy_and_legacy_weight_classification',
    'global_and_source_counts_and_suppression',
    'exact_decimal_rates_and_released_rate_summaries_reconcile',
    'registered_common_universe_minimum', 'weighted_input_and_output_contracts',
    'matched_row_input_and_output_contracts', 'matched_row_same_universe',
    'registered_S5_and_explicit_cardinalities_generated'
}


class GateError(Exception):
    pass


def need(value, code):
    if not value:
        raise GateError(code)


def digest(raw):
    return sha256(raw).hexdigest()


def load(path):
    return json.loads(path.read_bytes())


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--component', type=Path, default=HERE)
    p.add_argument('--independent-review', type=Path, required=True)
    p.add_argument('--private-root', type=Path)
    p.add_argument('--raw-csv', type=Path)
    p.add_argument('--report', type=Path, required=True)
    a = p.parse_args()
    component, report = a.component.resolve(), a.report.resolve()
    need(not report.exists() and not report.is_relative_to(component),
         'NEW_EXTERNAL_REPORT_PATH_REQUIRED')
    manifest_path = component / MANIFEST
    manifest = load(manifest_path)
    public_files = {}
    for record in manifest['files']:
        rel = Path(record['path'])
        need(not rel.is_absolute() and '..' not in rel.parts,
             'MANIFEST_LOCAL_PATHS_ONLY')
        path = component / rel
        need(path.is_file() and not path.is_symlink(), 'MANIFEST_FILE_PRESENT')
        raw = path.read_bytes()
        need(len(raw) == record['bytes'] and digest(raw) == record['sha256'],
             'PUBLIC_FILE_IDENTITY')
        public_files[record['path']] = raw
    actual = {path.relative_to(component).as_posix()
              for path in component.rglob('*') if path.is_file()}
    need(actual == set(public_files) | {MANIFEST}, 'EXPLICIT_PUBLIC_FILE_SET')
    public_files[MANIFEST] = manifest_path.read_bytes()
    for copy_manifest in ['R13_REQUIRED_FILE_COPIES.json',
                          'baselines/BASELINE_COPY_IDENTITIES.json']:
        for record in load(component / copy_manifest)['files']:
            raw = public_files[record['path']]
            need(len(raw) == record['bytes'] and digest(raw) == record['sha256'],
                 'UNCHANGED_REGISTERED_SOURCE_COPY')
    for name in RECEIPTS:
        data = load(component / name)
        need(set(data) == TOP_KEYS, 'FIXED_PUBLIC_RECEIPT_FIELDS')
        need(set(data['fixed_gates']) == FIXED_GATES
             and all(value is True for value in data['fixed_gates'].values()),
             'FIXED_PUBLIC_EXECUTION_GATES')
        need(data['release_decision']['blocks'] == {k: 'WITHHELD' for k in BLOCKS}
             and data['release_decision']['exact_eligible_count'] == 'WITHHELD',
             'ALL_NEW_FAT_BLOCKS_AND_N_WITHHELD')
        need(data['new_MC_replications'] == data['network_requests'] == 0,
             'NO_NEW_MC_OR_FAT_NETWORK')
        for field in ['new_producer_login_or_access', 'private_output_hashes_published',
                      'source_ids_or_vectors_published', 'input_or_establishment_rows_published',
                      'data_dependent_check_counts_published', 'original_R14_bytes_recovered']:
            need(data[field] is False, 'RECEIPT_SCOPE_LIMITS')
        need(data['identities_of_public_sources_and_code']['new_producer']
             == digest(public_files['run_fat_recovery_r14_1.py']), 'EXECUTED_PRODUCER_IDENTITY')
        need(data['identities_of_public_sources_and_code']['new_private_capture_adapter']
             == digest(public_files['capture_legacy_private_r14_1.mjs']), 'EXECUTED_CAPTURE_IDENTITY')
    acceptance = load(component / 'R14_1_FAT_ACCEPTANCE_LEDGER.json')
    need(acceptance['status'] == 'PASS_NEW_RECONSTRUCTED_FAT_EXECUTION_AND_INDEPENDENT_REVIEW',
         'ACCEPTANCE_STATUS')
    independent = load(a.independent_review)
    need(digest(a.independent_review.read_bytes())
         == acceptance['public_evidence']['independent_review']['sha256'],
         'INDEPENDENT_REVIEW_BINDING')
    need(all(value is True for value in independent['gates'].values())
         and independent['maximum_exact_numeric_residual'] == '0',
         'INDEPENDENT_FIXED_GATES')
    need(independent['new_FAT_numeric_blocks'] == independent['exact_eligible_count'] == 'WITHHELD',
         'INDEPENDENT_RELEASE_STATUS')
    scanned = False
    if a.private_root:
        private = a.private_root.resolve()
        need(private.is_dir() and not private.is_relative_to(component),
             'CONTROLLED_PRIVATE_SCAN_PATH')
        protected_digests = {digest(path.read_bytes()) for path in private.rglob('*')
                             if path.is_file()}
        need(bool(protected_digests), 'CONTROLLED_PRIVATE_FILES_PRESENT')
        if a.raw_csv:
            protected_digests_for_bytes = protected_digests | {digest(a.raw_csv.read_bytes())}
        else:
            protected_digests_for_bytes = protected_digests
        for raw in [*public_files.values(), a.independent_review.read_bytes()]:
            need(digest(raw) not in protected_digests_for_bytes,
                 'NO_PRIVATE_FILE_COPIED_BY_IDENTITY')
            need(not any(value.encode('ascii') in raw for value in protected_digests),
                 'NO_PROTECTED_OUTPUT_DIGEST_EMBEDDED')
        scanned = True
    result = {
        'schema_version': 'R14.1-FAT-public-component-check-1.0',
        'created_utc': datetime.now(timezone.utc).isoformat(),
        'status': 'PASS_PUBLIC_COMPONENT_BOUNDED_CHECKS',
        'fixed_gates': {
            'explicit_public_file_set_and_identities': True,
            'registered_source_copies_unchanged': True,
            'fixed_public_execution_receipt_shape': True,
            'executed_producer_and_capture_identified': True,
            'all_new_FAT_blocks_and_exact_n_withheld': True,
            'separate_independent_receipt_bound_and_passed': True,
            'protected_bytes_and_output_digests_absent_in_inspected_public_files': True if scanned else None
        },
        'public_manifest_sha256': digest(manifest_path.read_bytes()),
        'verifier_code_sha256': digest(Path(__file__).read_bytes()),
        'protected_output_hashes_published': False,
        'limits': [
            'Byte/digest checks are bounded to the provided protected files and the explicit public component plus independent public receipt.',
            'This is not proof of complete cumulative non-reconstruction or new authorisation to release FAT outputs.',
            'Historical public aggregate files remain historical baseline evidence.',
            'This check does not recover original R14 bytes or perform native Windows/browser execution.'
        ]
    }
    report.parent.mkdir(parents=True, exist_ok=True)
    with report.open('x', encoding='utf-8') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps({'status': result['status'], 'controlled_private_scan_completed': scanned,
                      'new_numerical_outputs_and_exact_eligible_count': 'WITHHELD'}))


if __name__ == '__main__':
    try:
        main()
    except GateError as error:
        print(json.dumps({'status': 'FAIL_PUBLIC_COMPONENT_GATE', 'gate': str(error)}), file=sys.stderr)
        raise SystemExit(1)
    except Exception:
        print(json.dumps({'status': 'FAIL_PUBLIC_COMPONENT_PROCESSING', 'private_values_printed': False}), file=sys.stderr)
        raise SystemExit(1)
