"""New R14.1 FAT reconstruction and registered diagnostics, under frozen R13.

All analytical outputs stay in a new protected directory. Only a fixed-gate
receipt is written publicly. This is a new execution, not recovery of R14 bytes.
Requires Python 3.12, jsonschema 4.26.0 and Node.js; no network is used.
"""
from pathlib import Path
from fractions import Fraction as F
from collections import Counter
from datetime import datetime, timezone
from hashlib import sha256
import argparse
import csv
import importlib
import importlib.metadata
import json
import math
import os
import re
import subprocess
import sys
import time

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
PINS = {
    'protocol': 'cde4280396ac29ba8cb840148bb019ec5a5d75da1f42b7d17cbe09f11b0358e4',
    'amendment': 'fe1cd65bf92b814575d0096b27ef99c9b2f5e25cdd5d4c99eaffdb9e58c52f7d',
    'input': 'f61a2c6e09f4763818ae1d4db8b330e97bffd8bb0824c2d833b79d728152bd17',
    'core': '221afe006b7d799b2f5044b5cbb0c61ba8b3f46304d6abb1d0003169715f0541',
    'executor': '041578bbcd531e0b8b97cd8960240c01f556f554b12029ea4e5750f0493f5bf0'
}
DECIMAL = re.compile(r'^[+-]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:[eE][+-]?[0-9]+)?$', re.ASCII)
MISSING = {'', 'na', 'n/a', 'nan', 'null', 'none', '.', 'sysmiss'}
BLOCKS = ['FAT_PRIMARY', 'FAT_SECONDARY_RULES_COSTS', 'FAT_MATCHED_ROW_WEIGHTING', 'FAT_TIES']


class GateError(Exception):
    pass


def need(condition, code):
    if not condition:
        raise GateError(code)


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def serial(value):
    if isinstance(value, F):
        return str(value)
    if isinstance(value, (set, frozenset)):
        return sorted(value)
    raise TypeError(type(value).__name__)


def save(path, data, private=False):
    raw = (json.dumps(data, ensure_ascii=False, indent=2, default=serial) + '\n').encode('utf-8')
    with path.open('xb') as stream:
        stream.write(raw)
    if private:
        os.chmod(path, 0o600)


def missing(token):
    token = token.strip().lower()
    return token in MISSING or re.fullmatch(r'\.[a-z]?', token, flags=re.ASCII) is not None


def binary(token):
    token = token.strip().lower()
    if missing(token):
        return 'missing', None
    if token in {'0', '0.0', 'false', 'no'}:
        return 'valid', 0
    if token in {'1', '1.0', 'true', 'yes'}:
        return 'valid', 1
    return 'invalid', None


def classify(tokens):
    values = [binary(token) for token in tokens]
    if any(s == 'invalid' for s, _ in values):
        return 'invalid_nonbinary', None
    positive = [i for i, (s, v) in enumerate(values) if s == 'valid' and v == 1]
    has_missing = any(s == 'missing' for s, _ in values)
    if len(positive) > 1:
        return 'multiple_positive', None
    if positive and has_missing:
        return 'ambiguous_positive_with_missing', None
    if positive:
        return 'mapped', positive[0]
    return ('unresolved_structurally_missing' if has_missing else 'unresolved_all_zero'), None


def legacy_weight(token):
    text = token.strip()
    if missing(text):
        return 'missing'
    try:
        if DECIMAL.fullmatch(text):
            number = float(text)
        elif re.fullmatch(r'0[xX][0-9a-fA-F]+|0[bB][01]+|0[oO][0-7]+', text):
            number = float(int(text, 0))
        else:
            return 'invalid'
    except (ValueError, OverflowError):
        return 'invalid'
    if not math.isfinite(number):
        return 'invalid'
    return 'positive' if number > 0 else 'nonpositive'


def empty_group():
    return {'all_mapped_counts': [0] * 5, 'positive_weight_counts': [0] * 5,
            'exact_state_weights': [F(0)] * 5, 'taxonomy': Counter(),
            'weight_status': Counter(), 'mapped_missing_weight': 0,
            'unresolved_positive_weight': 0, 'unresolved_missing_weight': 0}


def reconstruct(input_path, capture, protocol):
    parsed = capture['parser_capture']
    groups = {}
    taxonomy, weights = Counter(), Counter()
    fields = protocol['fat']['fields']
    row_count = 0
    with input_path.open(encoding='utf-8-sig', newline='') as stream:
        reader = csv.reader(stream, delimiter=parsed['delimiter'])
        headers = [x.lstrip('\ufeff').strip().lower() for x in next(reader)]
        need(headers == parsed['headers'], 'HEADER_RECONCILIATION')
        need(all(x in headers for x in fields), 'REQUIRED_FIELDS')
        index = {h: headers.index(h) for h in fields}
        for row in reader:
            if not row or (len(row) == 1 and not row[0]):
                continue
            need(len(row) == len(headers), 'ROW_WIDTH')
            tokens = [row[index[h]] for h in fields]
            ref = parsed['rows'][row_count]
            need(tokens == ref['tokens'], 'PARSER_SELECTED_TOKEN_RECONCILIATION')
            category, state = classify(tokens[2:])
            weight_status = legacy_weight(tokens[1])
            need((category, state, weight_status) == (ref['classification'], ref['state'], ref['weight_status']), 'LEGACY_CLASSIFIER_RECONCILIATION')
            label = tokens[0].strip()
            need(bool(label), 'NONEMPTY_SOURCE_LABEL')
            group = groups.setdefault(label, empty_group())
            group['taxonomy'][category] += 1
            group['weight_status'][weight_status] += 1
            taxonomy[category] += 1
            weights[weight_status] += 1
            row_count += 1
            if category.startswith('unresolved_'):
                group['unresolved_positive_weight'] += weight_status == 'positive'
                group['unresolved_missing_weight'] += weight_status == 'missing'
            if category != 'mapped':
                continue
            group['all_mapped_counts'][state] += 1
            if weight_status == 'missing':
                group['mapped_missing_weight'] += 1
            if weight_status == 'positive':
                text = tokens[1].strip()
                need(DECIMAL.fullmatch(text) is not None, 'POSITIVE_LEGACY_WEIGHT_DECIMAL_GRAMMAR')
                weight = F(text)
                need(weight > 0, 'POSITIVE_EXACT_WEIGHT')
                group['positive_weight_counts'][state] += 1
                group['exact_state_weights'][state] += weight
    need(row_count == len(parsed['rows']) and parsed['bad_width'] == 0, 'ROW_COUNT_RECONCILIATION')
    need(set(groups) == set(protocol['fat']['priority']), 'EXACT_FIXED_ROSTER')
    need(taxonomy['invalid_nonbinary'] == taxonomy['multiple_positive'] == 0, 'ROW_TAXONOMY_HARD_GATES')
    audit = capture['original_handler_report']['execution_audit']
    expected = {
        'total_rows': row_count, 'mapped_common_denominator': taxonomy['mapped'],
        'unresolved_total_rows': taxonomy['unresolved_all_zero'] + taxonomy['unresolved_structurally_missing'],
        'positive_weight_rows_all_data': weights['positive'], 'missing_weight_rows_all_data': weights['missing'],
        'source_label_count': len(groups),
        'mapped_missing_weight_rows_global': sum(g['mapped_missing_weight'] for g in groups.values()),
        'unresolved_positive_weight_rows_global': sum(g['unresolved_positive_weight'] for g in groups.values()),
        'unresolved_missing_weight_rows_global': sum(g['unresolved_missing_weight'] for g in groups.values())}
    need(all(audit[k] == value for k, value in expected.items()), 'GLOBAL_TAXONOMY_WEIGHT_COUNTS')
    need(sorted(groups) == audit['source_labels'], 'ORIGINAL_HANDLER_ROSTER')
    return groups, {'row_count': row_count, 'taxonomy': dict(taxonomy), 'weight_status': dict(weights),
                    'header_reconciled': True, 'selected_tokens_and_classifications_reconciled': True,
                    'global_counts_reconciled': True}


def is_small(count):
    return 1 <= count <= 4


def exact_summary(values):
    ordered = sorted(values)
    if not ordered:
        return None
    def quantile(p):
        h = (len(ordered) - 1) * p
        lo = h.numerator // h.denominator
        hi = -(-h.numerator // h.denominator)
        return ordered[lo] + (h - lo) * (ordered[hi] - ordered[lo])
    return {'n': len(ordered), 'median': quantile(F(1, 2)), 'q1': quantile(F(1, 4)),
            'q3': quantile(F(3, 4)), 'minimum': ordered[0], 'maximum': ordered[-1]}


def reconcile_rates(groups, capture, protocol):
    fat = protocol['fat']
    state_index = {s: i for i, s in enumerate(fat['states'])}
    definitions = {d: [state_index[s] for s in fat['definitions'][d]] for d in fat['definition_order']}
    original = {s['source_label']: s for s in capture['original_aggregate']['source_stratum_results']}
    rates = {'weighted': {d: [] for d in definitions}, 'unweighted': {d: [] for d in definitions}}
    maximum_rate = 0.0
    for label, group in groups.items():
        n = sum(group['all_mapped_counts'])
        nw = sum(group['positive_weight_counts'])
        denominator = sum(group['exact_state_weights'])
        source = original[label]
        need(source['mapped_n'] == n and source['valid_weight_n'] == nw, 'SOURCE_COUNT_RECONCILIATION')
        for definition, atoms in definitions.items():
            positive = sum(group['all_mapped_counts'][i] for i in atoms)
            suppressed = is_small(positive) or is_small(n - positive)
            old = source['definitions'][definition]
            need((old['disclosure_status'] == 'SUPPRESSED_SMALL_CELL') == suppressed, 'HISTORICAL_ENDPOINT_SUPPRESSION')
            need(old['unweighted']['denominator_n'] == n and old['weighted']['valid_weight_n'] == nw, 'ENDPOINT_COUNTS')
            if suppressed:
                need(old['unweighted']['rate'] is None and old['weighted']['rate'] is None, 'SUPPRESSED_RATES_NULL')
                continue
            need(old['unweighted']['positive_n'] == positive and old['unweighted']['negative_n'] == n-positive, 'ENDPOINT_POLAR_COUNTS')
            new = {'weighted': sum(group['exact_state_weights'][i] for i in atoms) / denominator,
                   'unweighted': F(positive, n)}
            for weighting, value in new.items():
                difference = abs(float(value) - old[weighting]['rate'])
                maximum_rate = max(maximum_rate, difference)
                need(difference <= 1e-12, 'EXACT_RATE_LEGACY_FLOAT_RECONCILIATION')
                rates[weighting][definition].append(value)
    maximum_summary = 0.0
    for weighting, definitions_rates in rates.items():
        for definition, values in definitions_rates.items():
            new = exact_summary(values)
            old = capture['original_aggregate']['cross_stratum_synthesis'][weighting]['definitions'][definition]
            need(new['n'] == old['n'], 'RELEASED_RATE_SUMMARY_DENOMINATOR')
            for key in ['median', 'q1', 'q3', 'minimum', 'maximum']:
                difference = abs(float(new[key]) - old[key])
                maximum_summary = max(maximum_summary, difference)
                need(difference <= 1e-12, 'EXACT_RATE_SUMMARY_RECONCILIATION')
    return {'maximum_exact_rate_to_legacy_float_difference': maximum_rate,
            'maximum_exact_rate_summary_to_legacy_float_difference': maximum_summary,
            'tolerance': 1e-12,
            'scope': 'Every original released definition rate and all released definition-rate summaries; original legacy replay separately checks all frozen public aggregate families.'}


def eligible_universe(groups, protocol):
    fat = protocol['fat']; indexes = {s: i for i, s in enumerate(fat['states'])}
    boundaries = list(fat['definitions'].values()) + [fat['objective']['states']]
    eligible, evidence = [], {}
    for label in fat['priority']:
        g = groups[label]; all_counts, contributors = g['all_mapped_counts'], g['positive_weight_counts']
        checks = {'mapped_minimum': sum(all_counts) >= 100,
                  'positive_contributor_minimum': sum(contributors) >= 100,
                  'positive_exact_denominator': sum(g['exact_state_weights']) > 0,
                  'all_mapped_atom_screen': all(not is_small(n) for n in all_counts),
                  'contributor_atom_screen': all(not is_small(n) for n in contributors)}
        endpoints = True
        for states in boundaries:
            for counts in [all_counts, contributors]:
                positive = sum(counts[indexes[s]] for s in states)
                endpoints &= not is_small(positive) and not is_small(sum(counts)-positive)
        checks['all_definition_and_objective_endpoint_screens'] = endpoints
        evidence[label] = checks
        if all(checks.values()):
            eligible.append(label)
    need(len(eligible) >= fat['common_eligibility']['minimum_size'], 'REGISTERED_COMMON_UNIVERSE_MINIMUM')
    return eligible, evidence


def normalised(groups, eligible, protocol, matched=False):
    fat, common = protocol['fat'], protocol['common_contract']
    rules = [common['rules']['primary']] if matched else list(common['rules'].values())
    chosen_costs = {'equal_costs': common['cost_profiles']['equal_costs']} if matched else common['cost_profiles']
    units = []
    for label in eligible:
        values = groups[label]['positive_weight_counts' if matched else 'exact_state_weights']
        units.append({'id': label, 'state_totals': {s: str(v) for s, v in zip(fat['states'], values)},
                      'known_denominator': str(sum(values)), 'unresolved_total': None,
                      'unresolved_status': 'not_identifiable'})
    return {'schema_version': 'R13.1', 'dataset_kind': 'FAT', 'input_status': 'real_extension_input',
            'provenance': {'source_label': 'FAT exact registered CSV; matched-row unweighted' if matched else 'FAT exact registered CSV; positive-weight complete cases',
                           'source_sha256': PINS['input'], 'adapter_status': 'independently_reconciled'},
            'states': fat['states'], 'units': units,
            'boundaries': [{'id': d, 'states': fat['definitions'][d]} for d in fat['definition_order']],
            'nested_boundaries': True, 'objective': {'id': fat['objective']['id'], 'states': fat['objective']['states']},
            'priority': eligible, 'rules': rules,
            'cost_profiles': [{'id': key, 'false_positive': value['false_inclusion'],
                              'false_negative': value['false_exclusion']} for key, value in chosen_costs.items()],
            'action_cost_profiles_by_rule': {r['id']: list(chosen_costs) if r['kind'] == 'threshold' else ['equal_costs'] for r in rules},
            'mixture_weighting': 'equal_eligible_units', 'primary_missing_policy': 'complete_known_states'}


def supplements(weighted, matched, core, protocol, eligible):
    ties = {}
    for rule in [protocol['common_contract']['rules'][key] for key in ['primary', 'secondary_highest']]:
        vectors = {}
        k, direction = rule['k'], rule['direction']
        for name, scores in weighted['rates'].items():
            ordered = sorted(scores.values(), reverse=direction == 'highest')
            gap = abs(ordered[k] - ordered[k-1])
            envelope = core.interval_membership({g: (x, x) for g, x in scores.items()}, k, direction)
            vectors[name] = {'boundary_exact_tie': gap == 0, 'boundary_gap_at_most_1e_12': gap <= F(1, 10**12),
                             'boundary_gap': gap,
                             'fixed_priority_selected': weighted['rules'][rule['id']]['selected_sets'][name],
                             'all_admissible_membership': envelope}
        ties[rule['id']] = vectors
    cardinalities = {}
    for kind, output in [('weighted', weighted), ('matched_row_unweighted', matched)]:
        cardinalities[kind] = {}
        for rule, data in output['rules'].items():
            selections = data['selected_sets']
            pairs = [{'left': row['left'], 'right': row['right'],
                      'left_count': len(selections[row['left']]), 'right_count': len(selections[row['right']])}
                     for row in data['pairwise_definition_comparisons']]
            cardinalities[kind][rule] = {'selection_cardinalities': {key: len(value) for key, value in selections.items()},
                                         'pairwise_cardinalities': pairs}
    return {'schema_version': 'R14.1-FAT-private-secondary-1.0', 'release_status': 'WITHHELD',
            'S5_point_ties': ties, 'explicit_cardinalities': cardinalities,
            'S4_universe_identical': weighted['unit_ids'] == matched['unit_ids'] == eligible,
            'S4_same_positive_weight_mapped_rows': True,
            'no_new_FAT_unresolved_interval': True}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--csv', type=Path, required=True)
    parser.add_argument('--r13', type=Path, required=True)
    parser.add_argument('--amendment', type=Path, required=True)
    parser.add_argument('--private-out', type=Path, required=True)
    parser.add_argument('--public-receipt', type=Path, required=True)
    parser.add_argument('--node', default='node')
    args = parser.parse_args()
    inp, r13, amendment = args.csv.resolve(), args.r13.resolve(), args.amendment.resolve()
    private, public = args.private_out.resolve(), args.public_receipt.resolve()
    need(not private.exists() and not public.exists(), 'NEW_OUTPUT_PATHS_REQUIRED')
    need(not public.is_relative_to(private), 'PUBLIC_RECEIPT_OUTSIDE_PRIVATE_OUTPUT')
    need(not private.is_relative_to(HERE) and not private.is_relative_to(r13), 'PRIVATE_OUTPUT_OUTSIDE_PUBLIC_SOURCE_TREES')
    protocol_path = r13 / '04_FROZEN_PROTOCOL/R13_EMPIRICAL_PROTOCOL_EN_GB.json'
    contracts = r13 / '05_EXECUTABLE_CONTRACTS'
    need(digest(protocol_path) == PINS['protocol'] and digest(amendment) == PINS['amendment'], 'FROZEN_SPECIFICATION_IDENTITIES')
    need(inp.name == 'fat0_raw_data_qje.csv' and inp.stat().st_size == 19633172 and digest(inp) == PINS['input'], 'FROZEN_INPUT_IDENTITY')
    need(digest(contracts / 'odsa_contract_core.py') == PINS['core'] and digest(contracts / 'execute_state_contract.py') == PINS['executor'], 'FROZEN_EXECUTABLE_IDENTITIES')
    protocol = json.loads(protocol_path.read_bytes())
    need(json.loads(amendment.read_bytes())['status'] == 'FROZEN_BEFORE_RECOVERY_ACQUISITION_AND_EMPIRICAL_CALCULATIONS', 'RECOVERY_AMENDMENT_STATUS')
    private.mkdir(parents=True, mode=0o700)
    started = datetime.now(timezone.utc).isoformat()
    def node_run(script, arguments, log_name):
        result = subprocess.run([args.node, str(script), *map(str, arguments)], capture_output=True, text=True, encoding='utf-8', timeout=120)
        save(private / log_name, {'returncode': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr}, private=True)
        need(result.returncode == 0, 'CONTROLLED_NODE_EXECUTION')
    baselines = HERE / 'baselines'
    node_run(baselines / 'replay_historical_source.mjs', ['--source-root', baselines / 'historical_source_root', '--csv', inp, '--out', private / 'historical_replay.json'], 'legacy_replay_process_log.json')
    legacy = json.loads((private / 'historical_replay.json').read_bytes())
    need(legacy['status'] == 'PASS_EXACT_HISTORICAL_INPUT_REPLAY' and legacy['summary']['all_14_historical_gates_pass'], 'UNCHANGED_HISTORICAL_REPLAY')
    node_run(HERE / 'capture_legacy_private_r14_1.mjs', ['--csv', inp, '--source', baselines / 'historical_source_root/historical_source/weighted_sensitivity.html', '--amendment', amendment, '--out', private / 'legacy_private_capture.json'], 'legacy_capture_process_log.json')
    capture = json.loads((private / 'legacy_private_capture.json').read_bytes())
    groups, reconstruction = reconstruct(inp, capture, protocol)
    reconciliation = reconcile_rates(groups, capture, protocol)
    eligible, screening = eligible_universe(groups, protocol)
    save(private / 'reconstruction_internal.json', {'status': 'PRIVATE_RECONSTRUCTION', 'groups': groups,
         'reconstruction': reconstruction, 'reconciliation': reconciliation, 'eligibility_screen': screening,
         'eligible_source_ids': eligible}, private=True)
    sys.path.insert(0, str(contracts))
    execute = importlib.import_module('execute_state_contract')
    core = importlib.import_module('odsa_contract_core')
    from jsonschema import Draft202012Validator
    output_validator = Draft202012Validator(json.loads((contracts / 'R13_STATE_OUTPUT.schema.json').read_bytes()))
    outputs = {}
    for label, matched in [('weighted', False), ('matched_row', True)]:
        data = normalised(groups, eligible, protocol, matched)
        input_file = private / ('normalised_' + ('matched_row_unweighted' if matched else 'weighted') + '.json')
        save(input_file, data, private=True)
        result = execute.execute(data)
        result['identities'] = {'input_sha256': digest(input_file), 'core_sha256': PINS['core'], 'executor_sha256': PINS['executor']}
        encoded = json.loads(json.dumps(result, default=serial))
        output_validator.validate(encoded)
        save(private / (label + '_point_results.json'), encoded, private=True)
        outputs[label] = result
    secondary = supplements(outputs['weighted'], outputs['matched_row'], core, protocol, eligible)
    need(secondary['S4_universe_identical'], 'MATCHED_ROW_COMMON_UNIVERSE')
    save(private / 'secondary_ties.json', secondary, private=True)
    source_identities = {'R13_protocol': PINS['protocol'], 'recovery_amendment': PINS['amendment'],
                         'registered_CSV': PINS['input'], 'frozen_core': PINS['core'], 'frozen_executor': PINS['executor'],
                         'new_producer': digest(Path(__file__)), 'new_private_capture_adapter': digest(HERE / 'capture_legacy_private_r14_1.mjs'),
                         'unchanged_historical_replay_adapter': digest(baselines / 'replay_historical_source.mjs')}
    gates = {name: True for name in [
        'frozen_protocol_and_recovery_amendment_identity', 'registered_CSV_identity',
        'unchanged_historical_HTML_replay', 'independent_CSV_parser_selected_tokens',
        'independent_taxonomy_and_legacy_weight_classification', 'global_and_source_counts_and_suppression',
        'exact_decimal_rates_and_released_rate_summaries_reconcile', 'registered_common_universe_minimum',
        'weighted_input_and_output_contracts', 'matched_row_input_and_output_contracts',
        'matched_row_same_universe', 'registered_S5_and_explicit_cardinalities_generated']}
    receipt = {'schema_version': 'R14.1-FAT-public-receipt-1.0', 'version': 'R14.1',
               'status': 'PASS_NEW_CONTROLLED_FAT_EXECUTION_AWAITING_INDEPENDENT_RESULT_REVIEW',
               'started_utc': started, 'completed_utc': datetime.now(timezone.utc).isoformat(),
               'runtime': {'python': sys.version.split()[0], 'platform': sys.platform,
                           'jsonschema': importlib.metadata.version('jsonschema'), 'node': legacy['execution']['runtime']},
               'identities_of_public_sources_and_code': source_identities, 'fixed_gates': gates,
               'maximum_legacy_replay_numeric_residual': legacy['summary']['maximum_absolute_numeric_difference'],
               'exact_rate_reconciliation': reconciliation,
               'new_FAT_calculations': 'Executed P1/P2 and S1-S5 with unchanged frozen R13 choices; all numerical outputs kept in protected working files.',
               'release_decision': {'blocks': {block: 'WITHHELD' for block in BLOCKS}, 'exact_eligible_count': 'WITHHELD',
                                    'reason': 'Recovery amendment preserves the unresolved cumulative-release decision; computation does not authorise release.'},
               'new_MC_replications': 0, 'network_requests': 0, 'new_producer_login_or_access': False,
               'private_output_hashes_published': False, 'source_ids_or_vectors_published': False,
               'input_or_establishment_rows_published': False, 'data_dependent_check_counts_published': False,
               'original_R14_bytes_recovered': False,
               'historical_R14': 'Previously reported in conversation; not a recovered receipt or independently reverified original R14 execution.',
               'limits': ['New independent result verification is a separate step.',
                          'No native browser, Windows or Microsoft Word execution.',
                          'No new FAT unknown-state intervals or claim of complete joint non-reconstruction.',
                          'The unchanged legacy replay includes its historical sensitivity; those results are not relabelled as new R13 interval analyses.']}
    public.parent.mkdir(parents=True, exist_ok=True)
    save(public, receipt)
    print(json.dumps({'status': receipt['status'], 'all_fixed_gates_pass': all(gates.values()),
                      'all_new_FAT_blocks_and_exact_eligible_count': 'WITHHELD'}))


if __name__ == '__main__':
    try:
        main()
    except GateError as error:
        print(json.dumps({'status': 'FAIL_FAT_RECOVERY_GATE', 'gate': str(error), 'private_values_printed': False}), file=sys.stderr)
        raise SystemExit(1)
    except Exception:
        print(json.dumps({'status': 'FAIL_FAT_RECOVERY_PROCESSING', 'private_values_printed': False}), file=sys.stderr)
        raise SystemExit(1)
