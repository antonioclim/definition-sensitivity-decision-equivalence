#!/usr/bin/env node
/** R14.1 controlled capture of unchanged historical HTML computation.
 * All captured rows, source vectors and fingerprints are PRIVATE outputs.
 * No network API is exposed to the historical script. No source is modified.
 */
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import crypto from 'node:crypto';

const PIN = {
  csv: 'f61a2c6e09f4763818ae1d4db8b330e97bffd8bb0824c2d833b79d728152bd17',
  source: '72f4dea52a586f8c59c5fc60fe9834154c1ba3065d517ada930d2c83593549c8',
  amendment: 'fe1cd65bf92b814575d0096b27ef99c9b2f5e25cdd5d4c99eaffdb9e58c52f7d'
};
const hash = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
function need(condition, code) { if (!condition) throw new Error(code); }

async function main() {
  const args = {};
  for (let i = 2; i < process.argv.length; i += 2) {
    need(['--csv', '--source', '--amendment', '--out'].includes(process.argv[i]), 'ARGUMENT_CONTRACT');
    need(process.argv[i + 1], 'ARGUMENT_VALUE');
    args[process.argv[i].slice(2)] = path.resolve(process.argv[i + 1]);
  }
  need(Object.keys(args).length === 4, 'ARGUMENTS_REQUIRED');
  const amendment = fs.readFileSync(args.amendment);
  need(hash(amendment) === PIN.amendment, 'AMENDMENT_IDENTITY');
  const html = fs.readFileSync(args.source);
  need(hash(html) === PIN.source, 'SOURCE_IDENTITY');
  const bytes = fs.readFileSync(args.csv);
  need(bytes.length === 19633172 && hash(bytes) === PIN.csv, 'CSV_IDENTITY');
  need(path.basename(args.csv) === 'fat0_raw_data_qje.csv', 'CSV_FILENAME');
  need(!fs.existsSync(args.out) && args.out !== args.csv, 'OUTPUT_MUST_BE_NEW');
  const scripts = [...html.toString('utf8').matchAll(/<script>([\s\S]*?)<\/script>/g)];
  need(scripts.length === 1, 'HISTORICAL_SCRIPT_COUNT');
  const elements = new Map(), handlers = new Map();
  let errorCount = 0, alertCount = 0, observedAggregate = null;
  function element(id) {
    if (!elements.has(id)) elements.set(id, {
      hidden: false, disabled: false, checked: false, value: 0,
      innerHTML: '', textContent: '', className: '', children: [],
      appendChild(child) { this.children.push(child); return child; },
      addEventListener(event, callback) { handlers.set(id + ':' + event, callback); },
      click() { throw new Error('UI_DOWNLOAD_DISABLED'); }
    });
    return elements.get(id);
  }
  class ObservedTextEncoder {
    constructor() { this.encoder = new TextEncoder(); }
    encode(value) {
      const encoded = this.encoder.encode(value);
      if (typeof value === 'string' && value.startsWith('{"claim_boundaries":')) {
        const candidate = JSON.parse(value);
        if (candidate.source_stratum_results && candidate.cross_stratum_synthesis)
          observedAggregate = candidate;
      }
      return encoded;
    }
  }
  const context = vm.createContext({
    document: {getElementById: element, createElement: tag => element('new-' + elements.size + '-' + tag)},
    TextEncoder: ObservedTextEncoder, TextDecoder, Uint8Array,
    console: {log() {}, warn() {}, error() { errorCount++; }},
    alert() { alertCount++; }
  });
  vm.runInContext(scripts[0][1], context, {timeout: 10000});
  need(element('selfTest').textContent.endsWith('PASS'), 'LEGACY_SELFTEST');
  need(!('fetch' in context) && !('XMLHttpRequest' in context) && !('require' in context), 'NO_NETWORK_OR_FILESYSTEM_IN_SOURCE');
  element('file').files = [{name: 'fat0_raw_data_qje.csv', size: bytes.length,
    arrayBuffer: async () => bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength)}];
  element('confirm').checked = true;
  const handler = handlers.get('run:click');
  need(typeof handler === 'function', 'LEGACY_HANDLER');
  await handler();
  need(!errorCount && !alertCount && observedAggregate !== null, 'LEGACY_COMPLETION');
  const internalReport = JSON.parse(vm.runInContext('JSON.stringify(report)', context));
  need(internalReport.gates.every(g => g.status === 'PASS'), 'LEGACY_GATES');
  context.__r14_csv_text = new TextDecoder('utf-8', {fatal: false}).decode(bytes);
  const parsed = vm.runInContext(`(() => {
    const rows = []; let headers = [], index = {}, badWidth = 0;
    const fields = ['country','base_wt','ib9b1','ib9b2','ib9b3','ib9b4','ib9b5'];
    const delimiter = detectDelimiter(__r14_csv_text);
    parseCsv(__r14_csv_text, delimiter, (row,rn) => {
      if (rn === 0) {
        headers = row.map(normHeader);
        headers.forEach((h,i) => {if (!(h in index)) index[h] = i;}); return;
      }
      if (row.length !== headers.length) badWidth++;
      const get = h => h in index ? (row[index[h]] ?? '') : '';
      const tokens = fields.map(get);
      const classification = classifyIndicatorFamily(tokens.slice(2).map(binaryValue));
      const weight = weightValue(tokens[1]);
      rows.push({tokens, classification: classification.status, state: classification.state,
                 weight_status: weight.status});
    });
    return JSON.stringify({headers, delimiter, bad_width: badWidth, rows});
  })()`, context, {timeout: 30000});
  const result = {schema_version: 'R14.1-private-legacy-capture-1.0',
    status: 'PRIVATE_WORKING_CAPTURE_NOT_FOR_RELEASE', created_utc: new Date().toISOString(),
    source_modified: false, source_sha256: PIN.source, input_sha256: PIN.csv,
    amendment_sha256: PIN.amendment, source_runtime: process.version,
    original_handler_report: internalReport, original_aggregate: observedAggregate,
    parser_capture: JSON.parse(parsed),
    scope: 'Private observation of unchanged original handler and a separate call to its unchanged parser/classifiers; no public release approval.'};
  fs.mkdirSync(path.dirname(args.out), {recursive: true, mode: 0o700});
  fs.writeFileSync(args.out, JSON.stringify(result, null, 2) + '\n', {flag: 'wx', mode: 0o600});
  process.stdout.write(JSON.stringify({status: 'PASS_PRIVATE_LEGACY_CAPTURE', source_modified: false}) + '\n');
}
main().catch(() => {
  process.stderr.write(JSON.stringify({status: 'FAIL_PRIVATE_LEGACY_CAPTURE', detail: 'Private processing failed; no source values printed.'}) + '\n');
  process.exitCode = 1;
});
