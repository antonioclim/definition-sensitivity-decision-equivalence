"""Reconcile the recovered public R11/R12/R13 source identities.

This program does not read FAT microdata or calculate empirical metrics.
It checks bytes against the unchanged R13 source registry. All paths are
explicit, so no historical workspace layout is required.
"""
from pathlib import Path
from hashlib import sha256
from datetime import datetime, timezone
import argparse
import io
import json
import sys
import zipfile

sys.dont_write_bytecode = True


def digest(raw):
    return sha256(raw).hexdigest()


def check(r11, r12, r13):
    registry_path = r13 / '04_FROZEN_PROTOCOL/R13_EMPIRICAL_SOURCE_EVIDENCE.json'
    registry_raw = registry_path.read_bytes()
    registry = json.loads(registry_raw)
    esm_path = r11 / '01_SUBMISSION/ESM_2.zip'
    esm_raw = esm_path.read_bytes()
    rows = []
    with zipfile.ZipFile(io.BytesIO(esm_raw)) as esm:
        frozen_raw = esm.read('FROZEN_ARCHIVE/S2_FROZEN_R5.zip')
        with zipfile.ZipFile(io.BytesIO(frozen_raw)) as frozen:
            for item in registry['local_sources']:
                package, locator = item['baseline_package'], item['baseline_locator']
                if package == 'R11':
                    raw = (r11 / locator).read_bytes()
                elif package == 'R12':
                    raw = (r12 / locator).read_bytes()
                elif package == 'R11 inner S2':
                    raw = frozen.read(locator)
                elif package == 'R11 ESM_2.zip':
                    raw = esm.read(locator)
                else:
                    raise ValueError('Unrecognised source package')
                actual_sha = digest(raw)
                rows.append({'source_id': item['id'], 'baseline_package': package,
                             'baseline_locator': locator, 'expected_bytes': item['bytes'],
                             'actual_bytes': len(raw), 'expected_sha256': item['sha256'],
                             'actual_sha256': actual_sha,
                             'identity_matches': len(raw) == item['bytes'] and actual_sha == item['sha256']})
            raw_candidates = []
            for name, z in [('R11 ESM_2.zip', esm), ('R11 frozen S2', frozen)]:
                for item in z.infolist():
                    if ('fat0_raw' in item.filename.lower()
                            or item.file_size == 19633172):
                        raw_candidates.append({'container': name, 'member': item.filename})
            archives = {
                'R11_ESM_2': {'bytes': len(esm_raw), 'sha256': digest(esm_raw),
                             'members_inspected': len(esm.infolist()), 'crc_check': 'PASS' if esm.testzip() is None else 'FAIL'},
                'R11_frozen_S2': {'bytes': len(frozen_raw), 'sha256': digest(frozen_raw),
                                  'members_inspected': len(frozen.infolist()),
                                  'identity_matches_R13_registry': digest(frozen_raw) == registry['frozen_inner_sha256'],
                                  'crc_check': 'PASS' if frozen.testzip() is None else 'FAIL'}
            }
    passed = (len(rows) == 20 and all(r['identity_matches'] for r in rows)
              and archives['R11_frozen_S2']['identity_matches_R13_registry']
              and all(r['crc_check'] == 'PASS' for r in archives.values()))
    return {'schema_version': 'R14.1-recovered-source-checks-1.0',
            'created_at_utc': datetime.now(timezone.utc).isoformat(),
            'status': 'PASS_RECOVERED_PUBLIC_SOURCE_IDENTITIES' if passed else 'FAIL_SOURCE_IDENTITY',
            'source_registry_sha256': digest(registry_raw),
            'fixed_registry_records_checked': len(rows), 'records': rows, 'archives': archives,
            'raw_input_candidates_in_two_canonical_archives': raw_candidates,
            'FAT_microdata_read': False, 'new_FAT_metrics_computed': False,
            'new_MC_replications': 0,
            'scope': 'Byte-identity and CRC checks of recovered public historical sources only; no FAT replay or R14 result recovery.',
            'limits': ['An intact historical report remains a historical report, not a newly executed verification.',
                       'The source CSV is not present in these two public archives; this does not prove absence from every authorised persistent source.']}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--r11', type=Path, required=True)
    parser.add_argument('--r12', type=Path, required=True)
    parser.add_argument('--r13', type=Path, required=True)
    parser.add_argument('--report', type=Path, required=True)
    args = parser.parse_args()
    if args.report.exists():
        raise SystemExit('Report path must be new; preserve the prior receipt.')
    report = check(args.r11.resolve(), args.r12.resolve(), args.r13.resolve())
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({key: report[key] for key in ['status', 'fixed_registry_records_checked',
                      'FAT_microdata_read', 'new_FAT_metrics_computed']}, ensure_ascii=False))
    raise SystemExit(0 if report['status'].startswith('PASS_') else 1)


if __name__ == '__main__':
    main()
