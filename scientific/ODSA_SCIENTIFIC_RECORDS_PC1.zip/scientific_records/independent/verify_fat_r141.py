"""Controlled independent FAT reconstruction for the explicitly amended recovery.

The private report may contain protected diagnostics. Only the separate public
report may be copied to delivery. The public report never emits eligible n,
source/selection identities, data-dependent check counts or private-output hashes.
"""
from pathlib import Path
from fractions import Fraction
from collections import Counter
from hashlib import sha256
from datetime import datetime, timezone
import argparse
import csv
import json
import math
import re
import sys
sys.dont_write_bytecode = True
from r141_independent_math import Comparison, verify_point, point_expected, point_tie_expected, select, stringify

MISSING = {'','na','n/a','nan','null','none','.','sysmiss'}
DECIMAL = re.compile(r'^[+-]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:[eE][+-]?[0-9]+)?$')
STATE_MISSING = re.compile(r'^\.[a-z]?$')
ZERO = {'0','0.0','false','no'}
ONE = {'1','1.0','true','yes'}


def trim(value):
    # ECMAScript whitespace includes BOM; normal CSV tokens here are ASCII.
    old = None
    while old != value:
        old = value
        value = value.strip().strip('\ufeff')
    return value


def is_missing(value):
    s = trim(value).lower()
    return s in MISSING or bool(STATE_MISSING.fullmatch(s))


def weight(value):
    if is_missing(value):
        return 'missing', None
    s = trim(value)
    if DECIMAL.fullmatch(s):
        number = float(s)
    elif re.fullmatch(r'0[xX][0-9a-fA-F]+|0[bB][01]+|0[oO][0-7]+', s):
        try:
            number = float(int(s, 0))
        except OverflowError:
            number = math.inf
    elif s in ('Infinity','+Infinity','-Infinity'):
        number = math.inf if not s.startswith('-') else -math.inf
    else:
        return 'invalid', None
    if not math.isfinite(number):
        return 'invalid', None
    if number <= 0:
        return 'nonpositive', None
    if not DECIMAL.fullmatch(s):
        raise ValueError('Legacy-positive finite weight outside frozen decimal grammar')
    return 'positive', Fraction(s)


def row_classification(tokens):
    values = []
    for token in tokens:
        s = trim(token).lower()
        if is_missing(s):
            values.append(None)
        elif s in ZERO:
            values.append(0)
        elif s in ONE:
            values.append(1)
        else:
            return 'invalid_nonbinary', None
    positives = [i for i, value in enumerate(values) if value == 1]
    if len(positives) > 1:
        return 'multiple_positive', None
    if positives and None in values:
        return 'ambiguous_positive_with_missing', None
    if positives:
        return 'mapped', positives[0]
    return ('unresolved_structurally_missing' if None in values else 'unresolved_all_zero'), None


def reconstruct(raw, protocol):
    fat = protocol['fat']
    if raw.stat().st_size != fat['input']['bytes'] or sha256(raw.read_bytes()).hexdigest() != fat['input']['sha256']:
        raise ValueError('Raw input identity mismatch')
    aggregates = {u: {'mapped':0, 'contributors':0, 'all_state_counts':[0]*5,
                      'contributor_state_counts':[0]*5, 'weights':[Fraction() for _ in range(5)]}
                  for u in fat['priority']}
    taxonomy, weight_statuses, traces = Counter(), Counter(), []
    rows = 0
    with raw.open('r', encoding='utf-8-sig', newline='') as stream:
        reader = csv.reader(stream)
        headers = [trim(x).lower() for x in next(reader)]
        if len(headers) != 723 or len(set(headers)) != len(headers):
            raise ValueError('Unexpected header structure')
        indices = {name: headers.index(name) for name in fat['fields']}
        for row in reader:
            if not row:
                continue
            rows += 1
            if len(row) != len(headers):
                raise ValueError('Wrong CSV row width')
            unit = trim(row[indices['country']])
            if unit not in aggregates:
                raise ValueError('Unregistered source stratum')
            kind, state = row_classification([row[indices[field]] for field in fat['state_field_order']])
            status, w = weight(row[indices['base_wt']])
            taxonomy[kind] += 1
            weight_statuses[status] += 1
            traces.append({'tokens': [row[indices[field]] for field in fat['fields']],
                           'classification': kind, 'state': state, 'weight_status': status})
            if kind in ('invalid_nonbinary','multiple_positive'):
                raise ValueError('Forbidden indicator row taxonomy')
            if kind != 'mapped':
                continue
            a = aggregates[unit]
            a['mapped'] += 1
            a['all_state_counts'][state] += 1
            if status == 'positive':
                a['contributors'] += 1
                a['contributor_state_counts'][state] += 1
                a['weights'][state] += w
    if rows != 21055 or taxonomy['mapped'] != 20069 or taxonomy['unresolved_all_zero'] + taxonomy['unresolved_structurally_missing'] != 986:
        raise ValueError('Registered global row taxonomy mismatch')
    if taxonomy['ambiguous_positive_with_missing'] or taxonomy['invalid_nonbinary'] or taxonomy['multiple_positive']:
        raise ValueError('Registered exceptional taxonomy mismatch')
    if weight_statuses['positive'] != 21054 or weight_statuses['missing'] != 1 or weight_statuses['invalid'] or weight_statuses['nonpositive']:
        raise ValueError('Registered global weight eligibility mismatch')
    member_states = [set(fat['definitions'][name]) for name in fat['definition_order']] + [set(fat['objective']['states'])]
    eligible, screens = [], {}
    for unit in fat['priority']:
        a = aggregates[unit]
        denomin = sum(a['weights'], Fraction())
        mapped_ok = a['mapped'] >= 100
        contributors_ok = a['contributors'] >= 100
        atoms_ok = all(c == 0 or c >= 5 for c in a['all_state_counts'] + a['contributor_state_counts'])
        endpoints_ok = True
        for subset in member_states:
            positive = sum(a['all_state_counts'][i] for i, state in enumerate(fat['states']) if state in subset)
            negative = a['mapped'] - positive
            endpoints_ok &= positive not in range(1,5) and negative not in range(1,5)
        screens[unit] = [mapped_ok, contributors_ok, denomin > 0, atoms_ok, endpoints_ok]
        if all(screens[unit]):
            eligible.append(unit)
    if len(eligible) < fat['common_eligibility']['minimum_size']:
        raise ValueError('Common eligible universe is below the registered minimum')
    return {'aggregates': aggregates, 'eligible': eligible, 'taxonomy': dict(taxonomy),
            'weight_statuses': dict(weight_statuses), 'traces': traces, 'screens': screens}


def verify_normalised(inp, rebuilt, protocol, matched=False):
    c = Comparison()
    fat, common = protocol['fat'], protocol['common_contract']
    eligible = rebuilt['eligible']
    c.equal('priority', inp['priority'], eligible)
    c.equal('unit_ids', [r['id'] for r in inp['units']], eligible)
    c.equal('states', inp['states'], fat['states'])
    c.equal('schema_version', inp['schema_version'], 'R13.1')
    c.equal('dataset_kind', inp['dataset_kind'], 'FAT')
    c.equal('input_status', inp['input_status'], 'real_extension_input')
    c.equal('nested_boundaries', inp['nested_boundaries'], True)
    c.equal('mixture_weighting', inp['mixture_weighting'], 'equal_eligible_units')
    c.equal('primary_missing_policy', inp['primary_missing_policy'], 'complete_known_states')
    c.equal('boundaries', inp['boundaries'], [{'id':name,'states':fat['definitions'][name]} for name in fat['definition_order']])
    c.equal('objective', inp['objective'], {'id':fat['objective']['id'],'states':fat['objective']['states']})
    expected_rules = [common['rules']['primary']] if matched else list(common['rules'].values())
    c.equal('rules', inp['rules'], expected_rules)
    expected_costs = [{'id':name, 'false_positive':values['false_inclusion'], 'false_negative':values['false_exclusion']}
                      for name,values in common['cost_profiles'].items() if not matched or name == 'equal_costs']
    c.equal('cost_profiles', inp['cost_profiles'], expected_costs)
    expected_schedule = {'lowest_3':['equal_costs']} if matched else {
        'lowest_3':['equal_costs'],'highest_3':['equal_costs'],
        'below_one_quarter':['equal_costs','exclusion_costly','inclusion_costly']}
    c.equal('action_cost_profiles_by_rule',inp['action_cost_profiles_by_rule'],expected_schedule)
    for row in inp['units']:
        unit = row['id']
        a = rebuilt['aggregates'][unit]
        values = [Fraction(v) for v in a['contributor_state_counts']] if matched else a['weights']
        c.equal('units/' + unit + '/state_totals', row['state_totals'], dict(zip(fat['states'],values)))
        c.equal('units/' + unit + '/known_denominator', row['known_denominator'], sum(values,Fraction()))
        c.equal('units/' + unit + '/unresolved_total', row['unresolved_total'], None)
        c.equal('units/' + unit + '/unresolved_status', row['unresolved_status'], 'not_identifiable')
    return c


def verify_ties(inp, secondary):
    # The FAT producer may wrap the same registered S5 vector map once.
    actual = secondary.get('S5_point_ties', secondary)
    rates = point_expected(inp)['rates']
    c = Comparison()
    expected_rules = {r['id']:r for r in inp['rules'] if r['kind']=='rank'}
    c.equal('tie_rule_ids',list(actual),list(expected_rules))
    for rid,rule in expected_rules.items():
        c.equal('tie_vector_ids/' + rid,list(actual[rid]),list(rates))
        for name,vector in rates.items():
            exp = point_tie_expected(vector,inp['priority'],rule['k'],rule['direction'])
            wanted = {'boundary_gap':exp['boundary_gap'], 'boundary_exact_tie':exp['exact_boundary_tie'],
                      'boundary_gap_at_most_1e_12':exp['near_boundary_gap_le_1e_12'],
                      'fixed_priority_selected':select(vector,inp['priority'],rule),
                      'all_admissible_membership':{k:exp[k] for k in ('guaranteed','possible','excluded')}}
            c.equal('ties/' + rid + '/' + name, actual[rid][name], wanted)
    return c


def verify_explicit_cardinalities(weighted, matched, secondary):
    c = Comparison()
    for kind,inp in [('weighted',weighted),('matched_row_unweighted',matched)]:
        point = point_expected(inp)
        wanted = {}
        for rid,rule in point['rules'].items():
            sizes = {name:len(chosen) for name,chosen in rule['selected_sets'].items()}
            pairs = [{'left':record['left'],'right':record['right'],
                      'left_count':sizes[record['left']],'right_count':sizes[record['right']]}
                     for record in rule['pairwise_definition_comparisons']]
            wanted[rid] = {'selection_cardinalities':sizes,'pairwise_cardinalities':pairs}
        c.equal('explicit_cardinalities/' + kind,secondary['explicit_cardinalities'][kind],wanted)
    c.equal('S4_universe_identical',secondary['S4_universe_identical'],weighted['priority']==matched['priority'])
    c.equal('S4_same_positive_weight_mapped_rows',secondary['S4_same_positive_weight_mapped_rows'],True)
    c.equal('no_new_FAT_unresolved_interval',secondary['no_new_FAT_unresolved_interval'],True)
    return c


def verify_legacy(rebuilt, capture, protocol, historical_source, amendment_sha):
    c = Comparison()
    c.equal('original_source_not_modified',capture['source_modified'],False)
    c.equal('original_source_identity',capture['source_sha256'],sha256(historical_source.read_bytes()).hexdigest())
    c.equal('original_input_identity',capture['input_sha256'],protocol['fat']['input']['sha256'])
    c.equal('original_amendment_identity',capture['amendment_sha256'],amendment_sha)
    c.equal('legacy_parser_classification_trace',capture['parser_capture']['rows'],rebuilt['traces'])
    rates = {'weighted':{},'unweighted':{}}
    maximum_residual = 0.0
    fat = protocol['fat']
    for name in fat['definition_order']:
        rates['weighted'][name] = []
        rates['unweighted'][name] = []
    for record in capture['original_aggregate']['source_stratum_results']:
        unit = record['source_label']
        a = rebuilt['aggregates'][unit]
        c.equal('legacy/' + unit + '/mapped_count',record['mapped_n'],a['mapped'])
        c.equal('legacy/' + unit + '/positive_weight_count',record['valid_weight_n'],a['contributors'])
        for name in fat['definition_order']:
            subset = set(fat['definitions'][name])
            selected_indices = [i for i,state in enumerate(fat['states']) if state in subset]
            positive = sum(a['all_state_counts'][i] for i in selected_indices)
            negative = a['mapped'] - positive
            suppressed = positive in range(1,5) or negative in range(1,5)
            item = record['definitions'][name]
            c.equal('legacy/' + unit + '/' + name + '/suppression',item['disclosure_status'],
                    'SUPPRESSED_SMALL_CELL' if suppressed else 'RELEASED')
            c.equal('legacy/' + unit + '/' + name + '/positive_count',item['unweighted']['positive_n'],None if suppressed else positive)
            c.equal('legacy/' + unit + '/' + name + '/negative_count',item['unweighted']['negative_n'],None if suppressed else negative)
            for kind in ('weighted','unweighted'):
                if suppressed:
                    c.equal('legacy/' + unit + '/' + name + '/' + kind,item[kind]['rate'],None)
                    continue
                expected = (sum((a['weights'][i] for i in selected_indices),Fraction()) / sum(a['weights'],Fraction())
                            if kind=='weighted' else Fraction(positive,a['mapped']))
                rates[kind][name].append(expected)
                actual = item[kind]['rate']
                if type(actual) not in (int,float) or not math.isfinite(actual):
                    c.failures.append({'path':'legacy_rate','reason':'Missing/nonfinite released rate'})
                    continue
                difference = abs(float(expected)-actual)
                maximum_residual = max(maximum_residual,difference)
                c.equal('legacy/' + unit + '/' + name + '/' + kind + '/within_tolerance',difference <= 1e-12,True)
    summary_maximum_residual = 0.0
    for kind,by_definition in rates.items():
        for name,values in by_definition.items():
            ordered = sorted(values)
            def quantile(frac):
                position = (len(ordered)-1)*frac
                lower = position.numerator//position.denominator
                upper = lower if position.denominator==1 else lower+1
                return ordered[lower]+(position-lower)*(ordered[upper]-ordered[lower])
            expected = {'minimum':ordered[0],'maximum':ordered[-1],
                        'median':quantile(Fraction(1,2)),'q1':quantile(Fraction(1,4)),'q3':quantile(Fraction(3,4))}
            actual = capture['original_aggregate']['cross_stratum_synthesis'][kind]['definitions'][name]
            c.equal('legacy_summary/' + kind + '/' + name + '/n',actual['n'],len(ordered))
            for label,wanted in expected.items():
                observed = actual[label]
                difference = abs(float(wanted)-observed)
                summary_maximum_residual = max(summary_maximum_residual,difference)
                c.equal('legacy_summary/' + kind + '/' + name + '/' + label + '/within_tolerance',difference <= 1e-12,True)
    return c,maximum_residual,summary_maximum_residual


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--protocol',required=True,type=Path)
    p.add_argument('--amendment',required=True,type=Path)
    p.add_argument('--amendment-sha256',required=True)
    p.add_argument('--raw',required=True,type=Path)
    p.add_argument('--run',required=True,type=Path)
    p.add_argument('--historical-source',required=True,type=Path)
    p.add_argument('--public-report',required=True,type=Path)
    p.add_argument('--private-report',required=True,type=Path)
    a=p.parse_args()
    if sha256(a.amendment.read_bytes()).hexdigest()!=a.amendment_sha256:
        raise SystemExit('Frozen recovery amendment identity mismatch')
    protocol=json.loads(a.protocol.read_bytes())
    rebuilt=reconstruct(a.raw,protocol)
    load=lambda name:json.loads((a.run/name).read_bytes())
    weighted=load('normalised_weighted.json')
    matched=load('normalised_matched_row_unweighted.json')
    secondary=load('secondary_ties.json')
    legacy_check,legacy_residual,summary_residual=verify_legacy(rebuilt,load('legacy_private_capture.json'),protocol,a.historical_source,a.amendment_sha256)
    checks={
        'legacy_parser_and_registered_rate_reconciliation':legacy_check,
        'weighted_normalisation':verify_normalised(weighted,rebuilt,protocol),
        'matched_row_normalisation':verify_normalised(matched,rebuilt,protocol,True),
        'weighted_point_results':verify_point(weighted,load('weighted_point_results.json')),
        'matched_row_point_results':verify_point(matched,load('matched_row_point_results.json')),
        'registered_point_tie_sensitivity':verify_ties(weighted,secondary),
        'explicit_cardinalities_and_matched_row_scope':verify_explicit_cardinalities(weighted,matched,secondary)}
    detailed={name:{'comparisons':c.checks,'maximum_exact_numeric_residual':str(c.maximum_exact_numeric_residual),
                    'failures':c.failures} for name,c in checks.items()}
    passed=all(not c.failures for c in checks.values())
    private={'status':'PASS' if passed else 'FAIL','checks':detailed,
             'raw_reconstruction':stringify(rebuilt)}
    a.private_report.parent.mkdir(parents=True,exist_ok=True)
    a.private_report.write_text(json.dumps(private,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    public={'status':'PASS_INDEPENDENT_FAT_RECONSTRUCTION_AND_REGISTERED_DIAGNOSTICS' if passed else 'FAIL_INDEPENDENT_FAT_VERIFICATION',
            'created_utc':datetime.now(timezone.utc).isoformat(),
            'gates':{'registered_input_identity':True,'registered_global_taxonomy':True,
                     'registered_weight_eligibility':True,'registered_minimum_common_universe_gate':True,
                     **{name:not c.failures for name,c in checks.items()}},
            'maximum_exact_numeric_residual':'0' if passed else None,
            'maximum_exact_rate_to_legacy_float_difference':legacy_residual,
            'maximum_exact_rate_summary_to_legacy_float_difference':summary_residual,
            'legacy_rate_reconciliation_tolerance':1e-12,
            'new_FAT_numeric_blocks':'WITHHELD','exact_eligible_count':'WITHHELD',
            'code_sha256':sha256(Path(__file__).read_bytes()).hexdigest(),
            'math_module_sha256':sha256(Path(__file__).with_name('r141_independent_math.py').read_bytes()).hexdigest(),
            'protocol_sha256':sha256(a.protocol.read_bytes()).hexdigest(),
            'amendment_sha256':a.amendment_sha256,
            'scope':'New independent CSV reconstruction and registered exact calculations in recovery; no producer/core imports',
            'limits':['Historical R14 output bytes and its original verifier were not recovered.',
                      'Historical JavaScript replay is performed by the producer; this verifier does not certify native browser or Windows execution.',
                      'No new FAT release approval; raw source rows, eligible roster, source-level metrics and all new numerical blocks remain protected.',
                      'Unused unresolved-weight totals and producer per-row digest are not reconstructed here.']}
    a.public_report.parent.mkdir(parents=True,exist_ok=True)
    a.public_report.write_text(json.dumps(public,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'status':public['status'],'public_gates':public['gates'],'maximum_exact_numeric_residual':public['maximum_exact_numeric_residual']},indent=2))
    raise SystemExit(0 if passed else 1)


if __name__=='__main__':main()
