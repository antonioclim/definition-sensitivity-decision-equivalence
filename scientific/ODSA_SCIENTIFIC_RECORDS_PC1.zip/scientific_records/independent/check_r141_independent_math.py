"""Focused exact controls for the new recovery verifier; no empirical claims."""
from pathlib import Path
from fractions import Fraction as F
from copy import deepcopy
from hashlib import sha256
from datetime import datetime, timezone
import argparse
import json
import sys
sys.dont_write_bytecode = True
from r141_independent_math import (rational, select, compare_sets, point_expected,
    enumerate_box_membership, point_tie_expected, unknown_expected, verify_point, stringify, parse_input,
    parse_oa_raw_response)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--r13', required=True, type=Path)
    p.add_argument('--report', required=True, type=Path)
    a = p.parse_args()
    checks = []
    def equal(name, actual, expected):
        if actual != expected:
            raise AssertionError(name + ': ' + repr(actual) + ' != ' + repr(expected))
        checks.append({'id': name, 'status': 'PASS'})
    def rejected(name, call):
        try:
            call()
        except (ValueError, KeyError, ZeroDivisionError, TypeError):
            checks.append({'id': name, 'status': 'PASS_REJECTED'})
        else:
            raise AssertionError('Invalid input accepted: ' + name)

    priority = ['a','b','c']
    lo = {'kind':'rank','direction':'lowest','k':1}
    hi = {'kind':'rank','direction':'highest','k':1}
    th = {'kind':'threshold','operator':'lt','threshold':'1/4'}
    equal('decimal_to_exact_fraction', rational('1.25e-2'), F(1,80))
    rejected('binary_float_rejected', lambda:rational(0.25))
    rejected('boolean_rejected', lambda:rational(True))
    equal('strict_threshold_excludes_equality',select({'a':F(1,4),'b':F(1,4)-F(1,10**14),'c':F(1,2)},priority,th),['b'])
    equal('common_priority_resolves_exact_tie',select(dict.fromkeys(priority,F(1,3)),priority,lo),['a'])
    equal('near_gap_does_not_merge_scores',select({'a':F(1,4),'b':F(1,4)-F(1,10**14),'c':F(1,2)},priority,lo),['b'])
    tie=point_tie_expected(dict.fromkeys(priority,F(1,3)),priority,1,'lowest')
    equal('exact_tie_flag',tie['exact_boundary_tie'],True)
    equal('exact_tie_all_admissible_guaranteed_empty',tie['guaranteed'],[])
    equal('exact_tie_all_admissible_possible_all',tie['possible'],priority)
    near=point_tie_expected({'a':F(1,4),'b':F(1,4)+F(1,10**13),'c':F(1,2)},priority,1,'lowest')
    equal('near_but_not_equal', (near['exact_boundary_tie'],near['near_boundary_gap_le_1e_12']), (False,True))
    full=point_tie_expected(dict.fromkeys(priority,F(1,3)),priority,3,'highest')
    equal('k_equals_n_all_guaranteed',full['guaranteed'],priority)
    equal('k_equals_n_no_boundary',full['boundary_gap'],None)
    empty=compare_sets([],[],3,th)
    equal('empty_jaccard_convention_flag',(empty['jaccard'],empty['jaccard_status']),(F(1),'both_empty_convention_one'))
    equal('empty_threshold_churn_not_applicable',empty['rank_churn'],None)
    same=compare_sets(['a'],['a'],3,th)
    equal('equal_nonempty_threshold_not_rank_churn',same['rank_churn'],None)
    rank=compare_sets(['a'],['b'],3,lo)
    equal('rank_disjoint_churn',rank['rank_churn'],F(1))
    equal('set_disagreement_divides_by_universe',rank['normalised_symmetric_difference'],F(2,3))
    separated={'a':(F(0),F(1,10)),'b':(F(2,10),F(3,10)),'c':(F(4,10),F(5,10))}
    equal('separated_box_lowest',enumerate_box_membership(separated,priority,1,'lowest')['guaranteed'],['a'])
    equal('separated_box_highest',enumerate_box_membership(separated,priority,1,'highest')['guaranteed'],['c'])
    touching={'a':(F(0),F(1,2)),'b':(F(1,2),F(1))}
    touch=enumerate_box_membership(touching,['a','b'],1,'lowest')
    equal('touching_endpoints_adverse_tie_guarantee',touch['guaranteed'],[])
    equal('touching_endpoints_favourable_tie_possible',touch['possible'],['a','b'])
    rejected('invalid_box_rejected',lambda:enumerate_box_membership({'a':(F(1),F(0))},['a'],1,'lowest'))

    base={'schema_version':'R13.1','dataset_kind':'TOY','input_status':'synthetic_fixture',
          'states':['a','b','c'],'priority':['A','B','C','D'],
          'units':[{'id':u,'state_totals':dict(zip(['a','b','c'],map(str,counts))),
                    'known_denominator':'10','unresolved_total':'0','unresolved_status':'known_nonnegative_total'}
                   for u,counts in [('A',(1,2,7)),('B',(3,1,6)),('C',(5,4,1)),('D',(1,3,6))]],
          'boundaries':[{'id':'d1','states':['a']},{'id':'d2','states':['a','b']}],
          'nested_boundaries':True,'objective':{'id':'q','states':['b','c']},
          'cost_profiles':[{'id':'equal','false_positive':'1','false_negative':'1'},
                           {'id':'exclude','false_positive':'1','false_negative':'2'},
                           {'id':'include','false_positive':'2','false_negative':'1'}],
          'rules':[{'id':'low2','kind':'rank','direction':'lowest','k':2},
                   {'id':'high2','kind':'rank','direction':'highest','k':2},
                   {'id':'ltquarter','kind':'threshold','operator':'lt','threshold':'1/4'}],
          'action_cost_profiles_by_rule':{'low2':['equal'],'high2':['equal'],'ltquarter':['equal','exclude','include']},
          'mixture_weighting':'equal_eligible_units','primary_missing_policy':'complete_known_states'}
    out=point_expected(base)
    equal('manual_semantic_fp_fn',(out['semantic']['d1']['equal']['false_inclusion_mass'],out['semantic']['d1']['equal']['false_exclusion_mass']),(F(1,4),F(3,4)))
    equal('manual_asymmetric_semantic',out['semantic']['d1']['exclude']['semantic_loss'],F(7,4))
    equal('manual_primary_selected',out['rules']['low2']['selected_sets']['d1'],['A','D'])
    equal('manual_primary_reference',out['rules']['low2']['selected_sets']['q'],['B','C'])
    equal('manual_action_normalisation',out['rules']['low2']['objective_losses']['d1']['equal']['action_loss_per_unit'],F(1))
    equal('threshold_cost_asymmetry',(out['rules']['ltquarter']['objective_losses']['d1']['exclude']['action_loss_count_scale'],out['rules']['ltquarter']['objective_losses']['d1']['include']['action_loss_count_scale']),(F(2),F(4)))
    scaled=deepcopy(base)
    scaled['units'][0]['state_totals']={k:str(int(v)*7) for k,v in scaled['units'][0]['state_totals'].items()}
    scaled['units'][0]['known_denominator']='70'
    equal('equal_unit_mixture_not_publication_pooled',point_expected(scaled),out)
    unknown=deepcopy(base);unknown['units'][0]['unresolved_total']='10'
    sensitivity=unknown_expected(unknown,'d1',{'a'})
    equal('nonzero_missing_interval',sensitivity['intervals']['A'],(F(1,20),F(11,20)))
    equal('nonzero_missing_coverage',sensitivity['coverage']['A']['unknown_share'],F(1,2))
    equal('nonzero_missing_lowest3_guaranteed',sensitivity['lowest_3']['guaranteed'],['B','D'])
    equal('nonzero_missing_lowest3_possible',sensitivity['lowest_3']['possible'],['A','B','C','D'])
    equal('nonzero_missing_threshold',sensitivity['below_one_quarter'],{'guaranteed':['D'],'ambiguous':['A'],'excluded':['B','C'],'possible':['A','D']})
    zero=unknown_expected(base,'d1',{'a'})
    equal('zero_missing_intervals_degenerate',all(l==u for l,u in zero['intervals'].values()),True)
    bad=deepcopy(base);bad['units'][0]['known_denominator']='11'
    rejected('denominator_mismatch_rejected',lambda:parse_input(bad))
    bad=deepcopy(base);bad['units'][0]['state_totals']['a']='-1';bad['units'][0]['state_totals']['b']='4'
    rejected('negative_state_rejected',lambda:parse_input(bad))
    bad=deepcopy(base);bad['priority']=['A','A','C','D']
    rejected('duplicate_unit_rejected',lambda:parse_input(bad))
    bad=deepcopy(base);bad['units'][0]['unresolved_total']=None;bad['units'][0]['unresolved_status']='not_identifiable'
    rejected('unidentified_missing_is_not_zero',lambda:unknown_expected(bad,'d1',{'a'}))
    bad=deepcopy(base);bad['units'][0]['state_totals']['extra']='0'
    rejected('extra_state_rejected',lambda:parse_input(bad))

    states=['closed','bronze','green','hybrid','gold','diamond']
    raw={'meta':{'count':10,'groups_count':2,'next_cursor':None},
         'group_by':[{'key':'gold','count':7},{'key':'unknown','count':3}], 'results':[]}
    packed=lambda r:json.dumps(r).encode('utf-8')
    extracted=parse_oa_raw_response(packed(raw),states)
    equal('raw_unknown_separate_from_known',(extracted['N'],extracted['D'],extracted['M']),(10,7,3))
    equal('raw_zero_fill_only_after_reconciliation',extracted['counts']['closed'],0)
    wrong=deepcopy(raw);wrong['group_by'][0]['count']=True
    rejected('raw_boolean_count_rejected',lambda:parse_oa_raw_response(packed(wrong),states))
    wrong=deepcopy(raw);wrong['meta']['count']=11
    rejected('raw_count_residual_not_imputed',lambda:parse_oa_raw_response(packed(wrong),states))
    wrong=deepcopy(raw);wrong['group_by'][1]['key']='new_enum'
    rejected('raw_unexpected_enum_rejected',lambda:parse_oa_raw_response(packed(wrong),states))
    wrong=deepcopy(raw);wrong['group_by'][1]['key']='gold'
    rejected('raw_duplicate_group_rejected',lambda:parse_oa_raw_response(packed(wrong),states))
    wrong=deepcopy(raw);wrong['meta']['next_cursor']='later'
    rejected('raw_unfinished_pagination_rejected',lambda:parse_oa_raw_response(packed(wrong),states))
    wrong=deepcopy(raw);wrong['meta']['groups_count']=3
    rejected('raw_wrong_group_count_rejected',lambda:parse_oa_raw_response(packed(wrong),states))
    wrong=deepcopy(raw);wrong['results']=[{'id':'unrequested_work'}]
    rejected('raw_unrequested_work_payload_rejected',lambda:parse_oa_raw_response(packed(wrong),states))
    rejected('raw_duplicate_json_key_rejected',lambda:parse_oa_raw_response(b'{"meta":{},"meta":{}}',states))

    r13inp=a.r13/'05_EXECUTABLE_CONTRACTS/R13_SYNTHETIC_INPUT.json'
    r13out=a.r13/'05_EXECUTABLE_CONTRACTS/R13_SYNTHETIC_OUTPUT.json'
    fixture=verify_point(json.loads(r13inp.read_bytes()),json.loads(r13out.read_bytes()))
    equal('recovered_R13_fixture_disagrees_nowhere',fixture.failures,[])
    report={'status':'PASS_FOCUSED_RECOVERY_VERIFIER_CONTROLS',
            'created_utc':datetime.now(timezone.utc).isoformat(),
            'focused_checks':len(checks),'checks':checks,
            'recovered_R13_synthetic_fixture_comparisons':fixture.checks,
            'maximum_exact_numeric_residual':str(fixture.maximum_exact_numeric_residual),
            'source_files':{r13inp.name:sha256(r13inp.read_bytes()).hexdigest(),r13out.name:sha256(r13out.read_bytes()).hexdigest()},
            'verifier_sha256':sha256(Path(__file__).with_name('r141_independent_math.py').read_bytes()).hexdigest(),
            'scope':'New synthetic controls and independent computation of the recovered R13 fixture. No new empirical data, blinding claim or reproduction of lost R14 verification.'}
    a.report.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:report[k] for k in ['status','focused_checks','recovered_R13_synthetic_fixture_comparisons','maximum_exact_numeric_residual']},indent=2))


if __name__=='__main__':main()
