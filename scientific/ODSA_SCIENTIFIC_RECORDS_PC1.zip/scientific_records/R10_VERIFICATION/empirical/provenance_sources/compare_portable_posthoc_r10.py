#!/usr/bin/env python3
"""Compare the one completed portable-CLI run with the preserved R10 run.

Read-only report/code comparison; does not process input records or rerun analysis.
"""
from pathlib import Path
from datetime import datetime, timezone
import ast
import hashlib
import json
import shlex
import sys

ROOT = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    old_script = ROOT / 'verify_posthoc_sensitivities_r10.py'
    new_script = ROOT / 'verify_posthoc_sensitivities_portable_r10.py'
    old_report = ROOT / 'checks/R10_POSTHOC_SENSITIVITY_REPRODUCTION.json'
    new_report = ROOT / 'checks/R10_POSTHOC_PORTABLE_REPRODUCTION.json'
    previous_index = json.loads((ROOT / 'R10_EMPIRICAL_EVIDENCE_INDEX.json').read_text())
    pins = {x['path']: x['sha256'] for x in previous_index['files']}
    assert sha(old_script) == pins[old_script.name] == '1e01f324d1b376e9d495327cfba0bd575056b469523572fa0690b92fa0527e86'
    assert sha(old_report) == pins[str(old_report.relative_to(ROOT))]
    old = json.loads(old_report.read_text())
    new = json.loads(new_report.read_text())
    assert old['status'] == new['status'] == 'PASS'
    assert old['check_count'] == new['check_count'] == 52
    semantic_fields = [
        'method', 'input_identity', 'public_summary_sha256', 'fields_read',
        'global_population', 'checks', 'check_count',
        'observed_public_practical_tie_summary',
        'observed_public_unweighted_separation_counts', 'privacy', 'limits',
    ]
    comparisons = [{'field': key, 'exactly_equal': old[key] == new[key]} for key in semantic_fields]
    assert all(x['exactly_equal'] for x in comparisons)
    a = old_script.read_text()
    b = new_script.read_text()
    block_start = '    start=time.monotonic();before=sha(INPUT)'
    block_end = "    result={'phase':'R10'"
    block_old = a[a.index(block_start):a.index(block_end)]
    block_new = b[b.index(block_start):b.index(block_end)]
    assert block_old == block_new
    helpers_old = a[a.index('def sha('):a.index('def main(')]
    helpers_new = b[b.index('def sha('):b.index('def main(')]
    assert helpers_old == helpers_new
    def constants(source):
        tree = ast.parse(source)
        result = {}
        for node in tree.body:
            if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
                name = node.targets[0].id
                if name in ['PIN', 'FIELDS', 'DEFINITIONS', 'PAIRS', 'MISSING']:
                    result[name] = ast.dump(node.value, include_attributes=False)
        return result
    assert constants(a) == constants(b)
    command = [sys.executable] + new['command_argv']
    record = {
        'phase': 'R10',
        'timestamp_utc': datetime.now(timezone.utc).isoformat(),
        'status': 'PASS',
        'scope': 'Portable CLI derivative of the new independent post-hoc verifier; one actual execution on the same exact registered input, followed by read-only equality checks. No changes to the original executed script, its report, frozen S2 or manuscript.',
        'script_original': {'path': str(old_script), 'sha256': sha(old_script), 'unchanged_from_preexisting_evidence_index': True},
        'report_original': {'path': str(old_report), 'sha256': sha(old_report), 'unchanged_from_preexisting_evidence_index': True},
        'script_portable': {'path': str(new_script), 'sha256': sha(new_script), 'arguments': ['--input-csv', '--public-summary', '--output'], 'dependencies': 'Python standard library only'},
        'computation_identity': {
            'entire_calculation_block_exactly_equal': True,
            'calculation_block_sha256': hashlib.sha256(block_old.encode()).hexdigest(),
            'helper_functions_exactly_equal': True,
            'scientific_constants_AST_equal': True,
            'changes': ['Explicit CLI paths replace fixed workspace paths', 'Argument/file checks and creation of the output parent', 'Existing output is refused to preserve prior records', 'Derivative identity is recorded in the sanitised JSON'],
        },
        'execution': {
            'command': command,
            'cwd': new['cwd'],
            'returncode': 0,
            'elapsed_seconds_reported_by_verifier': new['elapsed_seconds'],
            'python': new['python'],
            'platform': new['platform'],
            'input_identity': new['input_identity'],
            'public_summary_sha256': new['public_summary_sha256'],
            'output': {'path': str(new_report), 'sha256': sha(new_report), 'bytes': new_report.stat().st_size},
        },
        'comparison': {'checks_compared': 52, 'checks_and_all_exported_aggregates_exactly_equal': True, 'fields': comparisons},
        'privacy': new['privacy'],
        'limitations': [
            'The portable script still requires the exact registered input, which is not redistributed.',
            'This is a portable interface for the independent Python post-hoc reconstruction; it is not the recovered historical JavaScript source.',
            'No claim is made about native Windows/browser execution, upstream indicator construction or unresolved-row eligibility.',
            'No corruption probes or alternative scientific inputs were run for this interface change; the actual registered-input run and exact calculation-code comparison address the concrete portability change.',
            'Timestamps, elapsed runtime, command arguments and derivative source hash intentionally differ between the two run records.',
        ],
    }
    (ROOT / 'checks/R10_POSTHOC_PORTABLE_VERIFICATION.json').write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    text = [
        'R10 — VERIFICAREA INTERFEŢEI PORTABILE POST-HOC',
        'PASS — o execuţie reală pe inputul exact şi comparaţie cu rezultatul iniţial.',
        '',
        'Interfaţă: --input-csv --public-summary --output.',
        'Numai bibliotecă standard Python. Inputul nu este inclus în distribuţie.',
        'Blocul de calcul, funcţiile auxiliare şi constantele ştiinţifice sunt identice cu scriptul executat iniţial. Numai căile, argumentele şi metadatele de execuţie au fost adaptate.',
        '52/52 comparaţii au trecut. Toate înregistrările de comparaţie, agregatele exportate, numerele globale şi metadatele inputului sunt identice cu raportul iniţial.',
        'Scriptul şi raportul iniţiale îşi păstrează hashurile din indexul de probe anterior.',
        'Input neschimbat după execuţie. Nu au fost exportate rânduri, etichete private sau rezultate pe straturi.',
        f'Exit: 0. Durată internă: {new["elapsed_seconds"]:.6f} s.',
        '',
        'Comanda efectivă:',
        shlex.join(command),
        '',
        'SHA-256 script portabil: ' + sha(new_script),
        'SHA-256 raport nou: ' + sha(new_report),
        'SHA-256 script iniţial păstrat: ' + sha(old_script),
        'SHA-256 raport iniţial păstrat: ' + sha(old_report),
        '',
        'Limite: interfaţă executată pe Linux; nu reprezintă execuţie nativă Windows/browser, validare upstream sau justificarea eligibilităţii rândurilor nerezolvate. Este implementarea independentă R10, nu cod istoric recuperat.',
    ]
    (ROOT / 'checks/R10_POSTHOC_PORTABLE_VERIFICATION_RO.txt').write_text('\n'.join(text) + '\n', encoding='utf-8')
    print(json.dumps({'status': 'PASS', 'comparisons_exact': 52, 'all_exported_aggregates_exact': True, 'original_script_and_report_unchanged': True, 'portable_sha256': sha(new_script), 'new_report_sha256': sha(new_report)}, indent=2))


if __name__ == '__main__':
    main()
