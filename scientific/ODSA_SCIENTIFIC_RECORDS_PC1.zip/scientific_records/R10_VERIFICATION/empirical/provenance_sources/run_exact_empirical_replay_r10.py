#!/usr/bin/env python3
"""R10 invocation of the unchanged pinned R3 adapter; sanitised output only."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, platform, shutil, subprocess, sys, time

ROOT=Path(__file__).resolve().parent
SOURCE=ROOT/'work/07_RECOVERED_EMPIRICAL_SOURCE'
ADAPTER=ROOT/'work/08_R3_VERIFICATION/empirical/replay_historical_source.mjs'
INPUT=ROOT.parent/'private_input/fat0_raw_data_qje.csv'
OUT=ROOT/'checks/R10_EMPIRICAL_REPLAY_EXACT.json'
PIN='f61a2c6e09f4763818ae1d4db8b330e97bffd8bb0824c2d833b79d728152bd17'

def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(1048576),b''):h.update(b)
    return h.hexdigest()

def main():
    node=shutil.which('node')
    if not node:raise SystemExit('Node.js is unavailable')
    assert INPUT.stat().st_size==19633172 and sha(INPUT)==PIN
    assert not OUT.exists(), 'Replay output must be new'
    command=[node,str(ADAPTER),'--source-root',str(SOURCE),'--csv',str(INPUT),'--out',str(OUT)]
    before={'adapter':sha(ADAPTER),'HTML':sha(SOURCE/'historical_source/weighted_sensitivity.html'),'registered_input':sha(INPUT)}
    started_utc=datetime.now(timezone.utc).isoformat();start=time.monotonic()
    result=subprocess.run(command,cwd=ROOT,capture_output=True,text=True,timeout=60)
    elapsed=time.monotonic()-start
    (ROOT/'checks/R10_EXACT_REPLAY.stdout.txt').write_text(result.stdout,encoding='utf-8')
    (ROOT/'checks/R10_EXACT_REPLAY.stderr.txt').write_text(result.stderr,encoding='utf-8')
    report=json.loads(OUT.read_text()) if OUT.exists() else None
    after={'adapter':sha(ADAPTER),'HTML':sha(SOURCE/'historical_source/weighted_sensitivity.html'),'registered_input':sha(INPUT)}
    status='PASS' if result.returncode==0 and report and report['status']=='PASS_EXACT_HISTORICAL_INPUT_REPLAY' and before==after else 'FAIL'
    evidence={'phase':'R10','started_utc':started_utc,'completed_utc':datetime.now(timezone.utc).isoformat(),'status':status,
      'wrapper_sha256':sha(Path(__file__)),'command':command,'cwd':str(ROOT),'returncode':result.returncode,
      'elapsed_seconds_including_process_startup':elapsed,'host_platform':platform.platform(),'python_wrapper_runtime':sys.version,
      'identities_before':before,'identities_after':after,'input_and_sources_unchanged':before==after,
      'output_report':{'path':str(OUT),'sha256':sha(OUT) if OUT.exists() else None,'bytes':OUT.stat().st_size if OUT.exists() else None},
      'node_execution':report['execution'] if report else None,'summary':report['summary'] if report else None,
      'legacy_report_phase_label':report['phase'] if report else None,
      'legacy_label_explanation':'The unchanged adapter retains its historical phase label TASM R3. This wrapper identifies the actual R10 invocation, command, time, hashes and output. Neither the adapter nor its emitted report was rewritten.',
      'privacy':'No input records, identifiers, stratum rates/counts or full internal report are printed or exported. The adapter processes data within its local runtime and emits only the registered sanitised evidence.',
      'limits':['Conditional reproduction on the registered harmonised input.','Not reconstruction or independent validation of upstream ib9b construction, unresolved-state eligibility or original download-event date.','No native browser/Windows interface execution.','Separate post-hoc hostile-audit sensitivities in the primary public summary are outside this exact replay.']}
    (ROOT/'checks/R10_EXACT_REPLAY_INVOCATION.json').write_text(json.dumps(evidence,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'status':status,'returncode':result.returncode,'input_and_sources_unchanged':before==after,'runtime':report['execution']['runtime'] if report else None,'summary':report['summary'] if report else None,'sanitised_report_sha256':evidence['output_report']['sha256'],'elapsed_seconds':elapsed},indent=2))
    return 0 if status=='PASS' else 1

if __name__=='__main__':raise SystemExit(main())
