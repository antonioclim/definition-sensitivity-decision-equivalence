#!/usr/bin/env python3
"""Execute inspected distributed empirical checks; no World Bank input is loaded."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, platform, shutil, subprocess, sys, time

ROOT = Path(__file__).resolve().parent
WORK = ROOT / 'work'
CHECKS = ROOT / 'checks'
CHECKS.mkdir(exist_ok=True)
SOURCE = WORK / '07_RECOVERED_EMPIRICAL_SOURCE'
REPLAY = WORK / '08_R3_VERIFICATION/empirical/replay_historical_source.mjs'

def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    node=shutil.which('node')
    if not node:raise SystemExit('Node.js unavailable; no execution claimed')
    commands=[
      ('recovered_source_synthetic', [node,str(SOURCE/'checks/test_recovered_source.js')], 'Synthetic finite-allocation and historical pure-function tests; not empirical replay'),
      ('stored_aggregate_checks', [sys.executable,str(SOURCE/'checks/verify_recovered_aggregates.py'),'--out',str(CHECKS/'R10_BUNDLED_AGGREGATE_CHECKS.json')], 'Arithmetic and cross-file consistency of stored public summaries'),
      ('replay_adapter_selftest', [node,str(REPLAY),'--source-root',str(SOURCE),'--selftest'], 'Real adapter/source execution using its synthetic parser self-test; no empirical CSV')
    ]
    before={str(p.relative_to(WORK)):digest(p) for p in WORK.rglob('*') if p.is_file()}
    records=[]
    for name,command,scope in commands:
        started=time.monotonic()
        process=subprocess.run(command,cwd=ROOT,capture_output=True,text=True,timeout=60)
        elapsed=time.monotonic()-started
        (CHECKS/(name+'.stdout.txt')).write_text(process.stdout,encoding='utf-8')
        (CHECKS/(name+'.stderr.txt')).write_text(process.stderr,encoding='utf-8')
        try:parsed=json.loads(process.stdout)
        except json.JSONDecodeError:parsed=None
        records.append({'id':name,'command':command,'cwd':str(ROOT),'scope':scope,'returncode':process.returncode,
                        'elapsed_seconds':elapsed,'stdout_json':parsed,'stdout_path':str(CHECKS/(name+'.stdout.txt')),
                        'stderr_path':str(CHECKS/(name+'.stderr.txt'))})
    after={str(p.relative_to(WORK)):digest(p) for p in WORK.rglob('*') if p.is_file()}
    result={'phase':'R10','timestamp_utc':datetime.now(timezone.utc).isoformat(),'runner_sha256':digest(Path(__file__)),
            'python':sys.version,'platform':platform.platform(),'records':records,
            'working_sources_byte_identical_after_checks':before==after,
            'status':'PASS' if before==after and all(r['returncode']==0 for r in records) else 'FAIL',
            'empirical_microdata_replay_executed':False,'new_empirical_estimates_produced':False}
    (CHECKS/'R10_BUNDLED_EXECUTION_RECORD.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'status':result['status'],'source_unchanged':before==after,'records':[{'id':r['id'],'returncode':r['returncode'],'elapsed_seconds':r['elapsed_seconds'],'result':r['stdout_json']} for r in records]},ensure_ascii=False,indent=2))
    return 0 if result['status']=='PASS' else 1

if __name__=='__main__':raise SystemExit(main())
