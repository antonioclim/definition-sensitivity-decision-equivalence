#!/usr/bin/env python3
"""Read-only independent comparison of the prepared R4 execution view."""
from pathlib import Path
from datetime import datetime,timezone
import csv,hashlib,json,sys

ROOT=Path(__file__).resolve().parent
TASK=ROOT.parent
SOURCE=TASK/'fresh_s2/Supplementary_Material_S2_Code_and_Aggregate_Results'
VIEW=TASK/'r4_working_view'
REPORT=TASK/'computation/R10_R4_COMPATIBILITY_VIEW.json'

def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(1048576),b''):h.update(b)
    return h.hexdigest()

def main():
    preparer=TASK/'prepare_r4_compatibility_view.py';record=json.loads(REPORT.read_text())
    with (SOURCE/'MANIFEST.csv').open(encoding='utf-8-sig',newline='') as f:rows=list(csv.DictReader(f))
    expected={r['path']:r for r in rows}
    for name in ['MANIFEST.csv','SHA256SUMS.txt']:expected[name]={'path':name,'bytes':(SOURCE/name).stat().st_size,'sha256':record['pinned_manifest_sha256'][name]}
    source_set={p.relative_to(SOURCE).as_posix() for p in SOURCE.rglob('*') if p.is_file()}
    view_set={p.relative_to(VIEW).as_posix() for p in VIEW.rglob('*') if p.is_file()}
    ignored={n for n in view_set if '__pycache__' in Path(n).parts or n.endswith('.pyc')}
    differences=[];checked=[]
    for name,row in sorted(expected.items()):
        a=SOURCE/name;b=VIEW/name
        ok=b.is_file() and a.stat().st_size==int(row['bytes']) and b.stat().st_size==int(row['bytes']) and sha(a)==row['sha256'] and sha(b)==row['sha256']
        checked.append({'path':name,'bytes':int(row['bytes']),'expected_sha256':row['sha256'],'source_and_view_match':ok})
        if not ok:differences.append(name)
    addition_manifest=SOURCE/'10_R5_EDITORIAL_FIGURE_SOURCES/CURRENT_ADDITION_MANIFEST_SHA256.json'
    additions=json.loads(addition_manifest.read_text())['files'];r5=set()
    r5checks=[]
    for row in additions:
        name='10_R5_EDITORIAL_FIGURE_SOURCES/'+row['path'];r5.add(name);p=SOURCE/name
        ok=p.is_file() and p.stat().st_size==row['bytes'] and sha(p)==row['sha256'];r5checks.append({'path':name,'source_matches_manifest':ok})
    r5.add('10_R5_EDITORIAL_FIGURE_SOURCES/CURRENT_ADDITION_MANIFEST_SHA256.json')
    r5_manifest_ok=sha(addition_manifest)==record['pinned_manifest_sha256']['10_R5_EDITORIAL_FIGURE_SOURCES/CURRENT_ADDITION_MANIFEST_SHA256.json']
    sets_ok=source_set==set(expected)|r5 and view_set-ignored==set(expected)
    helper_ok=sha(preparer)==record['preparer_sha256']
    launcher='08_R3_VERIFICATION/computation/run_full_verified_r3.py'
    original_failure_confirmed={r['path'] for r in rows}!=source_set-{'MANIFEST.csv','SHA256SUMS.txt'}
    fixed_condition={r['path'] for r in rows}==(view_set-ignored)-{'MANIFEST.csv','SHA256SUMS.txt'}
    passed=not differences and all(x['source_matches_manifest'] for x in r5checks) and r5_manifest_ok and sets_ok and helper_ok and original_failure_confirmed and fixed_condition
    result={'phase':'R10','timestamp_utc':datetime.now(timezone.utc).isoformat(),'status':'PASS' if passed else 'FAIL',
      'reviewer_script_sha256':sha(Path(__file__)),'preparer_sha256':sha(preparer),'preparer_record_identity_match':helper_ok,
      'source_regular_files':len(source_set),'R4_declared_payloads':len(rows),'R4_view_files_checked':len(checked),'R5_source_members_retained':len(r5),
      'view_generated_cache_files_ignored':sorted(ignored),'exact_source_and_view_inventory_relationship':sets_ok,'source_view_file_comparisons':checked,'R5_file_comparisons':r5checks,
      'original_launcher_guard_fails_on_R5_inventory':original_failure_confirmed,'same_guard_satisfied_on_R4_view_inventory':fixed_condition,
      'launcher_sha256_source':sha(SOURCE/launcher),'launcher_sha256_view':sha(VIEW/launcher),
      'concrete_defects':differences,
      'static_code_review':['Pins both historical manifests and the R5 addition manifest.','Requires the exact non-overlapping 213+2 R4 and 23+1 R5 inventories and verifies file sizes/hashes.','Uses copies, not hardlinks; requires a new view outside the source, preserves existing outputs and checks the copied member inventory.','No scientific code or authorisation gate is altered; the view exposes the exact manifest domain expected by the historical launcher.'],
      'limits':['This review independently hashed the source and view members and inspected the preparer/launcher code.','It did not rerun the preparer, preflight, seven probes or any simulation; those executions are performed and recorded separately by root.','The original R5 source remains the complete distribution; the R4 view is an execution compatibility copy, not a replacement release.']}
    target=ROOT/'checks/R10_R4_COMPATIBILITY_INDEPENDENT_REVIEW.json';target.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'status':result['status'],'source_files':len(source_set),'R4_checked':len(checked),'R5_retained':len(r5),'ignored_cache_files':len(ignored),'defects':differences},indent=2))
    return 0 if passed else 1

if __name__=='__main__':raise SystemExit(main())
