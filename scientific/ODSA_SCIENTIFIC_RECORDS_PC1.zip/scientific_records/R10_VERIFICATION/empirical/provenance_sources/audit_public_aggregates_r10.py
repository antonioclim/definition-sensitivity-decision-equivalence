#!/usr/bin/env python3
"""Independently audit distributed public empirical summaries without microdata.

Checks cover internal arithmetic, feasible ranges, cross-summary relationships,
protocol/file identity and the recorded replay comparison schema. They do not
reconstruct unobserved stratum values or validate an upstream survey pipeline.
"""
from pathlib import Path
from datetime import datetime, timezone
from collections import Counter
import hashlib, json, math, re, sys

ROOT=Path(__file__).resolve().parent
SOURCE=ROOT/'work/07_RECOVERED_EMPIRICAL_SOURCE'
R3=ROOT/'work/08_R3_VERIFICATION/empirical'
FRESH=ROOT.parent/'fresh_s2/Supplementary_Material_S2_Code_and_Aggregate_Results'
PUBLIC=SOURCE/'public_aggregates'
P_PATH=PUBLIC/'WORLD_BANK_PUBLIC_RESULT_SUMMARY.json'
M_PATH=PUBLIC/'WORLD_BANK_PUBLIC_WEIGHTED_MISSINGNESS_SUMMARY.json'
P=json.loads(P_PATH.read_text()); M=json.loads(M_PATH.read_text())
REPLAY=json.loads((R3/'R3_EMPIRICAL_REPLAY_EXACT.json').read_text())
CHECKS=[]; COVERED=set(); SUMMARIES=[]
ORDER=['minimum','q1','median','q3','maximum']

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def close(a,b):return math.isclose(a,b,rel_tol=1e-12,abs_tol=1e-12)
def check(name,ok,actual=None,expected=None,paths=(),scope='stored_aggregate_consistency'):
    CHECKS.append({'id':f'EA{len(CHECKS)+1:04d}','name':name,'passed':bool(ok),'actual':actual,'expected':expected,'paths':list(paths),'scope':scope})
    COVERED.update(paths)
def walk(obj,prefix):
    if isinstance(obj,dict):
        for k,v in obj.items():yield from walk(v,prefix+'/'+k)
    elif isinstance(obj,list):
        for i,v in enumerate(obj):yield from walk(v,prefix+'/'+str(i))
    else:yield prefix,obj
def visit_summaries(obj,prefix):
    if not isinstance(obj,dict):return
    if set(['n']+ORDER).issubset(obj):
        paths=[prefix+'/'+k for k in ['n']+ORDER]
        n=obj['n'];vals=[obj[k] for k in ORDER]
        signed='/difference_summary' in prefix and '/absolute_difference_summary' not in prefix
        check(prefix+'/eligible_n',isinstance(n,int) and 1<=n<=16,n,'integer 1..16',paths[:1])
        check(prefix+'/quantile_order',all(isinstance(v,(int,float)) and math.isfinite(v) for v in vals) and all(a<=b+1e-12 for a,b in zip(vals,vals[1:])),vals,'minimum <= q1 <= median <= q3 <= maximum',paths[1:])
        check(prefix+'/range',all((-1 if signed else 0)-1e-12<=v<=1+1e-12 for v in vals),vals,[-1 if signed else 0,1],paths[1:])
        SUMMARIES.append(prefix)
    for k,v in obj.items():visit_summaries(v,prefix+'/'+k)
def pair_check(obj,prefix):
    n=obj['comparable_strata'];pairs=obj['total_pairs'];c=obj['concordant_pairs'];t=obj['tie_changes'];r=obj['strict_reversals']
    check(prefix+'/pair_denominator',pairs==math.comb(n,2),pairs,math.comb(n,2),[prefix+'/comparable_strata',prefix+'/total_pairs'])
    check(prefix+'/partition',all(isinstance(x,int) and x>=0 for x in [c,t,r]) and c+t+r==pairs,[c,t,r],pairs,[prefix+'/'+k for k in ['concordant_pairs','tie_changes','strict_reversals']])
    check(prefix+'/strict_share',close(obj['strict_reversal_share'],r/pairs),obj['strict_reversal_share'],r/pairs,[prefix+'/strict_reversal_share'])
    check(prefix+'/instability_share',close(obj['total_instability_share'],(r+t)/pairs),obj['total_instability_share'],(r+t)/pairs,[prefix+'/total_instability_share'])
def leaf_counts(obj):
    leaves=list(walk(obj,''));return len(leaves),sum(type(v) in (int,float) for _,v in leaves)

def main():
    for label,obj in [('primary',P),('sensitivity',M)]:
        visit_summaries(obj,label)
        nums=[(p,v) for p,v in walk(obj,label) if type(v) in (int,float)]
        check(label+'/finite_numeric_payload',all(math.isfinite(v) for _,v in nums),len(nums),'all finite',[p for p,_ in nums],scope='stored_numeric_schema')
    pop=P['analysis_population'];scope=M['analysis_scope']
    check('population_partition',pop['mapped_common_denominator']+pop['unresolved_total_rows']==pop['total_rows'],[pop['mapped_common_denominator'],pop['unresolved_total_rows']],pop['total_rows'],['primary/analysis_population/'+k for k in ['mapped_common_denominator','unresolved_total_rows','total_rows']])
    check('unresolved_share',close(pop['unresolved_share'],pop['unresolved_total_rows']/pop['total_rows']),pop['unresolved_share'],pop['unresolved_total_rows']/pop['total_rows'],['primary/analysis_population/unresolved_share'])
    for k,j in [('total_rows','total_rows'),('mapped_common_denominator','mapped_common_denominator'),('unresolved_total_rows','unresolved_rows'),('analytical_source_strata','analytical_source_strata'),('documented_reporting_countries','documented_reporting_countries')]:
        check('cross_population/'+k,pop[k]==scope[j],scope[j],pop[k],['primary/analysis_population/'+k,'sensitivity/analysis_scope/'+j])
    for weighting,blocks in P['cross_stratum_synthesis'].items():
        defs=blocks['definitions'];comps=blocks['composition']
        for key,con in blocks['contrasts'].items():
            a,b=key.split('__to__');check(weighting+'/'+key+'/eligible_contrast_bound',con['n']<=min(defs[a]['n'],defs[b]['n']),con['n'],[defs[a]['n'],defs[b]['n']],['primary/cross_stratum_synthesis/'+weighting+'/contrasts/'+key+'/n'])
        for key,comp in comps.items():
            ns={v['n'] for v in comp.values()};check(weighting+'/'+key+'/composition_n',len(ns)==1 and next(iter(ns))<=defs[key]['n'],sorted(ns),'<='+str(defs[key]['n']))
        for metric in ORDER:
            check(weighting+'/ERP_only_composition/'+metric,close(comps['integrated_planning']['erp'][metric],1),comps['integrated_planning']['erp'][metric],1)
        a=comps['specialised_planning']['specialised_software'];b=comps['specialised_planning']['erp']
        for k,j in [('minimum','maximum'),('q1','q3'),('median','median'),('q3','q1'),('maximum','minimum')]:
            check(weighting+'/two_component_complement/'+k,close(a[k]+b[j],1),a[k]+b[j],1)
        for key,tv in blocks['composition_tv'].items():
            a,b=key.split('__to__');cap=min(next(iter(comps[a].values()))['n'],next(iter(comps[b].values()))['n'])
            check(weighting+'/'+key+'/TV_common_eligibility',tv['n']<=cap,tv['n'],'<='+str(cap))
    for weighting,contrasts in P['ordering_diagnostics'].items():
        for key,obj in contrasts.items():
            prefix='primary/ordering_diagnostics/'+weighting+'/'+key;pair_check(obj,prefix)
            a,b=key.split('__to__');defs=P['cross_stratum_synthesis'][weighting]['definitions']
            check(prefix+'/common_eligibility',obj['comparable_strata']<=min(defs[a]['n'],defs[b]['n']),obj['comparable_strata'],[defs[a]['n'],defs[b]['n']])
    for key,obj in P['weighting_sensitivity']['definitions'].items():
        pref='primary/weighting_sensitivity/definitions/'+key
        n=obj['difference_summary']['n'];counts=[obj[x] for x in ['weighted_higher_count','unweighted_higher_count','near_zero_count']]
        check(pref+'/partition',sum(counts)==n,counts,n,[pref+'/'+k for k in ['weighted_higher_count','unweighted_higher_count','near_zero_count']])
        check(pref+'/absolute_n',obj['absolute_difference_summary']['n']==n,obj['absolute_difference_summary']['n'],n)
        expected=max(abs(obj['difference_summary']['minimum']),abs(obj['difference_summary']['maximum']))
        check(pref+'/absolute_max',close(obj['absolute_difference_summary']['maximum'],expected),obj['absolute_difference_summary']['maximum'],expected)
        check(pref+'/near_zero_threshold',obj['near_zero_threshold']==0.01,obj['near_zero_threshold'],0.01,[pref+'/near_zero_threshold'])
    hostile=P['posthoc_hostile_audit_sensitivities']
    for weighting,contrasts in hostile['practical_pairwise_tie_sensitivity_at_one_percentage_point'].items():
        for key,obj in contrasts.items():
            prefix='primary/posthoc_hostile_audit_sensitivities/practical_pairwise_tie_sensitivity_at_one_percentage_point/'+weighting+'/'+key
            pair_check(obj,prefix);base=P['ordering_diagnostics'][weighting][key]
            check(prefix+'/same_population',obj['comparable_strata']==base['comparable_strata'],obj['comparable_strata'],base['comparable_strata'])
            check(prefix+'/strict_reversal_subset',obj['strict_reversals']<=base['strict_reversals'],obj['strict_reversals'],'<='+str(base['strict_reversals']))
            check(prefix+'/tolerance',obj['practical_tie_tolerance']==0.01,obj['practical_tie_tolerance'],0.01,[prefix+'/practical_tie_tolerance'])
    cons=hostile['conservative_unweighted_unresolved_assignment']
    check('posthoc_unweighted/total_strata',cons['total_source_strata']==pop['analytical_source_strata'],cons['total_source_strata'],pop['analytical_source_strata'])
    for k,v in cons.items():
        if k.endswith('_source_strata') and k!='total_source_strata':check('posthoc_unweighted/'+k,isinstance(v,int) and 0<=v<=cons['total_source_strata'],v,[0,cons['total_source_strata']],scope='stored_count_feasibility_not_replay')
    for key,bd in M['cross_stratum_weighted_bounds'].items():
        orig=P['cross_stratum_synthesis']['weighted']['definitions'][key]
        check(key+'/complete_case_summary_identical',bd['complete_case']==orig,bd['complete_case'],orig)
        check(key+'/same_bound_eligibility',len({x['n'] for x in bd.values()})==1,sorted({x['n'] for x in bd.values()}),'one common count')
        for q in ORDER:
            check(key+'/bound_quantile_nesting/'+q,bd['lower'][q]<=bd['complete_case'][q]+1e-12<=bd['upper'][q]+2e-12,[bd[x][q] for x in ['lower','complete_case','upper']],'lower <= complete-case <= upper')
        if bd['width']['n']==pop['analytical_source_strata']:
            check(key+'/width_all_strata',bd['width']==M['unresolved_weight_share_across_source_strata'],bd['width'],M['unresolved_weight_share_across_source_strata'])
    for key,obj in M['robust_separation'].items():
        n=obj['eligible_common_strata'];r=obj['robust_separation_strata'];prefix='sensitivity/robust_separation/'+key
        check(prefix+'/count_feasible',0<=r<=n and isinstance(r,int),r,[0,n])
        check(prefix+'/share',close(obj['robust_share'],r/n),obj['robust_share'],r/n)
    for key,obj in M['interval_ordering_determinacy'].items():
        n=obj['eligible_strata'];pairs=obj['total_pairs'];r=obj['determinate_pairs'];o=obj['overlapping_pairs'];prefix='sensitivity/interval_ordering_determinacy/'+key
        check(prefix+'/n',n==M['cross_stratum_weighted_bounds'][key]['complete_case']['n'],n,M['cross_stratum_weighted_bounds'][key]['complete_case']['n'])
        check(prefix+'/pair_denominator',pairs==math.comb(n,2),pairs,math.comb(n,2))
        check(prefix+'/partition',r+o==pairs and min(r,o)>=0,[r,o],pairs)
        check(prefix+'/share',close(obj['determinate_share'],r/pairs),obj['determinate_share'],r/pairs)
    selected={**{'primary/'+key:P[key] for key in ['cross_stratum_synthesis','ordering_diagnostics','weighting_sensitivity','claim_boundaries']},
              'sensitivity/bounds':M['cross_stratum_weighted_bounds'],'sensitivity/unresolved_weight_share':M['unresolved_weight_share_across_source_strata'],
              'sensitivity/robust_separation':M['robust_separation'],'sensitivity/interval_ordering':M['interval_ordering_determinacy']}
    comparisons={x['name']:x for x in REPLAY['comparisons']}
    check('R3_record/comparison_block_names',set(selected)==set(comparisons),sorted(comparisons),sorted(selected),scope='historical_record_schema_consistency')
    leaf_total=numeric_total=0
    for name,obj in selected.items():
        leaves,nums=leaf_counts(obj);leaf_total+=leaves;numeric_total+=nums;stored=comparisons[name]
        check('R3_record/'+name+'/leaf_counts',leaves==stored['leaf_comparisons'] and nums==stored['numeric_comparisons'],[leaves,nums],[stored['leaf_comparisons'],stored['numeric_comparisons']],scope='historical_record_schema_consistency')
        check('R3_record/'+name+'/declared_exactness',stored['status']=='PASS' and stored['exact_numeric_matches']==nums and stored['maximum_absolute_numeric_difference']==0 and stored['mismatches']==[],stored,'PASS/exact/no mismatches as recorded',scope='historical_record_consistency_not_new_empirical_execution')
    check('R3_record/400_384',leaf_total==400 and numeric_total==384,[leaf_total,numeric_total],[400,384],scope='public_block_leaf_count_recalculation')
    check('R3_record/14_gates',len(REPLAY['gates'])==14 and {x['id'] for x in REPLAY['gates']}=={f'M{i}' for i in range(1,15)} and all(x['status']=='PASS' for x in REPLAY['gates']),len(REPLAY['gates']),14,scope='historical_record_consistency_not_new_empirical_execution')
    pins={'historical_source_sha256':SOURCE/'historical_source/weighted_sensitivity.html','public_primary_sha256':P_PATH,'public_sensitivity_sha256':M_PATH}
    for key,path in pins.items():check('R3_record/'+key,sha(path)==REPLAY['identity'][key],sha(path),REPLAY['identity'][key],scope='executed_file_identity')
    html=(SOURCE/'historical_source/weighted_sensitivity.html').read_text()
    for const,file in [('IM_R7C_FREEZE_SHA','weighted_unresolved_row_sensitivity_freeze.yml'),('ORIGINAL_FREEZE_SHA','outcome_analysis_freeze.yml'),('AMENDMENT_SHA','outcome_analysis_implementation_amendment_01.yml'),('DEFINITIONS_SHA','definitions.yml')]:
        pin=re.search(r'const '+const+r'="([a-f0-9]+)"',html).group(1)
        check('protocol/'+const,sha(SOURCE/'historical_protocols'/file)==pin,sha(SOURCE/'historical_protocols'/file),pin,scope='executed_file_identity')
    original_files=[p for p in SOURCE.rglob('*') if p.is_file()]
    duplicate=R3/'07_RECOVERED_EMPIRICAL_SOURCE'
    exact=all((duplicate/p.relative_to(SOURCE)).is_file() and sha(p)==sha(duplicate/p.relative_to(SOURCE)) for p in original_files)
    check('duplicated_R2_bundle_byte_identity',exact,len(original_files),'all corresponding files equal',scope='executed_file_identity')
    candidate_names=[str(p.relative_to(FRESH)) for p in FRESH.rglob('*') if p.is_file() and p.name.casefold()==REPLAY['identity']['csv_name'].casefold()]
    distribution={'root':str(FRESH),'registered_input_name':REPLAY['identity']['csv_name'],'registered_bytes':REPLAY['identity']['csv_bytes'],'registered_sha256':REPLAY['identity']['csv_sha256'],'matching_filename_members':candidate_names,
                  'conclusion':'Registered harmonised input absent from the distributed S2; no conclusion about unrelated or historical workspace locations. Root separately controls any exact project-input recovery.'}
    payload={'phase':'R10','timestamp_utc':datetime.now(timezone.utc).isoformat(),'status':'PASS' if all(c['passed'] for c in CHECKS) else 'FAIL',
      'script_sha256':sha(Path(__file__)),'source_files':{str(p.relative_to(ROOT)):sha(p) for p in [P_PATH,M_PATH,R3/'R3_EMPIRICAL_REPLAY_EXACT.json']},
      'checks':CHECKS,'check_count':len(CHECKS),'scope_counts':dict(Counter(c['scope'] for c in CHECKS)),'distribution_summaries_checked':SUMMARIES,
      'numeric_schema_coverage':'Every numeric leaf of both public JSONs checked for finite numeric representation; arithmetic/relationship checks apply where identified. This is not independent reconstruction of all numeric leaves.',
      'replay_public_block_leaf_counts':{'leaves':leaf_total,'numeric_leaves':numeric_total},'distributed_input_availability':distribution,
      'limitations':['Stratum-level rates, weights, numerators and individual observations are not reconstructed from summaries.','Stored medians, quartiles and reversal/separation numerators cannot be independently re-estimated without the registered input or disclosable sufficient statistics.','Post-hoc primary-summary sensitivities are checked for arithmetic consistency, not treated as part of the R3 replay.','Marginal medians are not subtracted to reconstruct median contrasts, nor are component medians forced to sum to one.','Historical status labels are not current author approval, provider disclosure authorisation or editorial acceptance.']}
    target=ROOT/'checks/R10_PUBLIC_AGGREGATE_AUDIT.json';target.write_text(json.dumps(payload,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'status':payload['status'],'checks':len(CHECKS),'summary_blocks':len(SUMMARIES),'historical_replay_fields':[leaf_total,numeric_total],'issues':[c for c in CHECKS if not c['passed']],'input_found_in_distributed_S2':bool(candidate_names)},ensure_ascii=False,indent=2))
    return 0 if payload['status']=='PASS' else 1

if __name__=='__main__':raise SystemExit(main())
