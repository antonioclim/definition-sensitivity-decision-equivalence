#!/usr/bin/env python3
"""Independent R10 reproduction of the two stored post-hoc sensitivities.

Only the seven registered columns are used. Rows and private stratum statistics
remain in process memory; only already-published aggregate fields are exported.
This is a separate Python reconstruction, not the unchanged R3 JS replay.
"""
from pathlib import Path
from datetime import datetime,timezone
from itertools import combinations
import csv,hashlib,json,math,platform,re,sys,time

ROOT=Path(__file__).resolve().parent
INPUT=ROOT.parent/'private_input/fat0_raw_data_qje.csv'
PUBLIC=ROOT/'work/07_RECOVERED_EMPIRICAL_SOURCE/public_aggregates/WORLD_BANK_PUBLIC_RESULT_SUMMARY.json'
PIN='f61a2c6e09f4763818ae1d4db8b330e97bffd8bb0824c2d833b79d728152bd17'
FIELDS=['country','base_wt','ib9b1','ib9b2','ib9b3','ib9b4','ib9b5']
DEFINITIONS={'integrated_planning':(4,),'specialised_planning':(3,4),'digitally_enabled_planning':(1,2,3,4)}
PAIRS=[('integrated_planning','specialised_planning'),('specialised_planning','digitally_enabled_planning'),('integrated_planning','digitally_enabled_planning')]
MISSING={'','na','n/a','nan','null','none','.','sysmiss'}

def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda:f.read(1048576),b''):h.update(block)
    return h.hexdigest()
def missing(x):return x.strip().lower() in MISSING or re.fullmatch(r'\.[a-z]?',x.strip().lower()) is not None
def binary(x):
    s=x.strip().lower()
    if missing(x):return None
    if s in ['0','0.0','false','no']:return 0
    if s in ['1','1.0','true','yes']:return 1
    return 'invalid'
def sign(delta,tol):return 0 if abs(delta)<=tol else (1 if delta>0 else -1)

def main():
    start=time.monotonic();before=sha(INPUT)
    assert before==PIN and INPUT.stat().st_size==19633172
    public=json.loads(PUBLIC.read_text());expected=public['posthoc_hostile_audit_sensitivities']
    groups={};total=mapped=unresolved=0;invalid=ambiguous=multiple=0
    with INPUT.open(newline='',encoding='utf-8-sig') as f:
        reader=csv.DictReader(f)
        assert all(k in reader.fieldnames for k in FIELDS)
        for row in reader:
            total+=1;label=row['country'].strip()
            assert label, 'Missing stratum label; no row is exported'
            g=groups.setdefault(label,{'counts':[0]*5,'weights':[0.0]*5,'mapped':0,'unresolved':0,'weight':0.0})
            state=[binary(row[k]) for k in FIELDS[2:]]
            if 'invalid' in state:invalid+=1;continue
            positives=[i for i,v in enumerate(state) if v==1]
            if len(positives)>1:multiple+=1;continue
            if positives and None in state:ambiguous+=1;continue
            if not positives:unresolved+=1;g['unresolved']+=1;continue
            i=positives[0];mapped+=1;g['mapped']+=1;g['counts'][i]+=1
            raw=row['base_wt']
            if not missing(raw):
                try:w=float(raw)
                except ValueError:w=math.nan
                if math.isfinite(w) and w>0:g['weights'][i]+=w;g['weight']+=w
    assert (total,mapped,unresolved,len(groups),invalid,ambiguous,multiple)==(21055,20069,986,16,0,0,0)
    rates={w:{d:{} for d in DEFINITIONS} for w in ['weighted','unweighted']}
    for label,g in groups.items():
        for d,states in DEFINITIONS.items():
            n=sum(g['counts'][i] for i in states);negative=g['mapped']-n
            if n in range(1,5) or negative in range(1,5):continue
            rates['unweighted'][d][label]=n/g['mapped']
            if g['weight']>0:rates['weighted'][d][label]=sum(g['weights'][i] for i in states)/g['weight']
    observed={};checks=[]
    for weighting in rates:
        observed[weighting]={}
        for left,right in PAIRS:
            a=rates[weighting][left];b=rates[weighting][right];labels=sorted(set(a)&set(b))
            c=t=r=0
            for x,y in combinations(labels,2):
                sa=sign(a[x]-a[y],0.01);sb=sign(b[x]-b[y],0.01)
                if sa==sb:c+=1
                elif sa==0 or sb==0:t+=1
                else:r+=1
            pairs=math.comb(len(labels),2)
            o={'comparable_strata':len(labels),'total_pairs':pairs,'concordant_pairs':c,'tie_changes':t,'strict_reversals':r,
               'strict_reversal_share':r/pairs,'total_instability_share':(r+t)/pairs,'practical_tie_tolerance':0.01}
            key=left+'__to__'+right;observed[weighting][key]=o
            e=expected['practical_pairwise_tie_sensitivity_at_one_percentage_point'][weighting][key]
            for field in e:
                good=math.isclose(o[field],e[field],rel_tol=1e-12,abs_tol=1e-12) if isinstance(e[field],float) else o[field]==e[field]
                checks.append({'field':'practical_pairwise_tie_sensitivity_at_one_percentage_point/'+weighting+'/'+key+'/'+field,'expected':e[field],'observed':o[field],'passed':good})
    names=['middle_lower_exceeds_strict_upper_source_strata','broad_lower_exceeds_middle_upper_source_strata','broad_lower_exceeds_strict_upper_source_strata']
    conservative={'total_source_strata':len(groups)}
    for (left,right),name in zip(PAIRS,names):
        count=0
        for g in groups.values():
            denominator=g['mapped']+g['unresolved']
            left_positive=sum(g['counts'][i] for i in DEFINITIONS[left]);right_positive=sum(g['counts'][i] for i in DEFINITIONS[right])
            if right_positive/denominator>(left_positive+g['unresolved'])/denominator+1e-12:count+=1
        conservative[name]=count
    for field,value in conservative.items():
        expected_value=expected['conservative_unweighted_unresolved_assignment'][field]
        checks.append({'field':'conservative_unweighted_unresolved_assignment/'+field,'expected':expected_value,'observed':value,'passed':value==expected_value})
    unchanged=sha(INPUT)==before
    result={'phase':'R10','timestamp_utc':datetime.now(timezone.utc).isoformat(),'status':'PASS' if unchanged and all(c['passed'] for c in checks) else 'FAIL',
      'method':'Independent Python CSV parsing and registered-state aggregation; 1 percentage point pairwise tolerance and coherent all-unresolved endpoint assignments. Original JS source and frozen files are not edited.',
      'script_sha256':sha(Path(__file__)),'command_argv':sys.argv,'cwd':str(Path.cwd()),'python':sys.version,'platform':platform.platform(),'elapsed_seconds':time.monotonic()-start,
      'input_identity':{'filename':INPUT.name,'bytes':INPUT.stat().st_size,'sha256':before,'unchanged_after_run':unchanged},'public_summary_sha256':sha(PUBLIC),
      'fields_read':FIELDS,'global_population':{'total_rows':total,'mapped_rows':mapped,'unresolved_rows':unresolved,'strata':len(groups)},
      'checks':checks,'check_count':len(checks),'observed_public_practical_tie_summary':observed,'observed_public_unweighted_separation_counts':conservative,
      'privacy':{'input_rows_exported':False,'source_stratum_statistics_exported':False,'private_labels_exported':False,'full_internal_report_exported':False},
      'limits':['Separate verification of already-published post-hoc sensitivities; not a new prespecified study or a replacement for the frozen primary estimates.','The 0.01 tolerance is the historical post-hoc practical-tie definition; the primary ordering tolerance remains 1e-12.','Unweighted endpoint counts cover all 16 registered strata and are distinct from the disclosure-eligible weighted marginal certificates in main Table 4.','The construction/eligibility of upstream ib9b indicators and validity of treating every unresolved row as eligible remain unverified.']}
    (ROOT/'checks/R10_POSTHOC_SENSITIVITY_REPRODUCTION.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'status':result['status'],'checks':len(checks),'failures':[c for c in checks if not c['passed']],'input_unchanged':unchanged,'elapsed_seconds':result['elapsed_seconds']},indent=2))
    return 0 if result['status']=='PASS' else 1

if __name__=='__main__':raise SystemExit(main())
