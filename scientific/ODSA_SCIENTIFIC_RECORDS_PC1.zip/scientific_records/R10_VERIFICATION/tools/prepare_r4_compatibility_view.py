#!/usr/bin/env python3
"""Prepare the unmodified R4 execution layer from the frozen R5 S2 distribution.

The R5 figure extension has its own manifest. The historical R3 launcher expects
the R4 manifest to describe the whole directory, so it rejects the extended R5
tree. This tool verifies both manifest domains and copies only the exact R4
members to a new, separate working directory. It neither edits sources nor runs
the simulator, and it does not grant full-run authorisation.

Python 3.11 or later; standard library only.
"""
from __future__ import annotations
import argparse
import csv
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path, PurePosixPath
import shutil
import sys

PINS = {
    'MANIFEST.csv': '8314d7776aa2d34e40e9f71cd42baf188675b4bfaa636cd13c49224fbb0bb2f0',
    'SHA256SUMS.txt': 'cde7d8dc6812cec952f4429f6924160401670bf295394e3cf661d391a0507809',
    '10_R5_EDITORIAL_FIGURE_SOURCES/CURRENT_ADDITION_MANIFEST_SHA256.json': 'e41c660af83a5d5dc2132631a9c6b7ac8895b2219bea5e9bc5a25ce767991cdf',
}
R5_DIRECTORY = '10_R5_EDITORIAL_FIGURE_SOURCES'
R5_MANIFEST = R5_DIRECTORY + '/CURRENT_ADDITION_MANIFEST_SHA256.json'


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def safe_file(root, relative):
    q = PurePosixPath(relative)
    require(bool(relative) and not q.is_absolute() and '..' not in q.parts
            and '\\' not in relative and ':' not in relative,
            'Unsafe manifest path: ' + relative)
    path = root.joinpath(*q.parts)
    require(not path.is_symlink() and root in path.resolve().parents and path.is_file(),
            'Invalid or missing regular source file: ' + relative)
    return path


def verify_source(root):
    for name, expected in PINS.items():
        require(digest(safe_file(root, name)) == expected, 'Unexpected frozen manifest: ' + name)
    with (root / 'MANIFEST.csv').open(encoding='utf-8-sig', newline='') as stream:
        reader = csv.DictReader(stream)
        require(reader.fieldnames == ['path', 'bytes', 'sha256'], 'Unexpected R4 manifest schema')
        rows = list(reader)
    r4 = {row['path']: {'bytes': int(row['bytes']), 'sha256': row['sha256']} for row in rows}
    require(len(rows) == len(r4) == 213, 'Unexpected or duplicate R4 inventory')
    for name in ['MANIFEST.csv', 'SHA256SUMS.txt']:
        r4[name] = {'bytes': (root / name).stat().st_size, 'sha256': PINS[name]}
    checksums = {}
    for line in (root / 'SHA256SUMS.txt').read_text(encoding='utf-8-sig').splitlines():
        expected, name = line.split('  ', 1)
        require(name not in checksums, 'Duplicate historical checksum: ' + name)
        checksums[name] = expected
    require(set(checksums) == set(r4) - {'SHA256SUMS.txt'}, 'R4 checksum inventory mismatch')
    require(all(checksums[n] == r4[n]['sha256'] for n in checksums), 'R4 checksum registers disagree')
    addition = json.loads((root / R5_MANIFEST).read_text(encoding='utf-8'))['files']
    r5 = {R5_DIRECTORY + '/' + row['path']: {'bytes': int(row['bytes']), 'sha256': row['sha256']} for row in addition}
    require(len(addition) == len(r5) == 23, 'Unexpected or duplicate R5 inventory')
    r5[R5_MANIFEST] = {'bytes': (root / R5_MANIFEST).stat().st_size, 'sha256': PINS[R5_MANIFEST]}
    require(not set(r4) & set(r5), 'Overlapping manifest domains')
    expected = {**r4, **r5}
    actual = {p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file() or p.is_symlink()}
    require(actual == set(expected), 'S2 inventory mismatch: missing=' + str(sorted(set(expected) - actual))
            + '; unexpected=' + str(sorted(actual - set(expected))))
    for name, entry in expected.items():
        path = safe_file(root, name)
        require(path.stat().st_size == entry['bytes'] and digest(path) == entry['sha256'],
                'Source size or hash mismatch: ' + name)
    return r4, r5


def prepare(root, output, report):
    require(root.is_dir(), 'S2 source directory not found')
    require(output != root and root not in output.parents and output not in root.parents,
            'Output must be separate from the S2 source tree')
    require(not output.exists(), 'Output must be a new directory; existing outputs are preserved')
    require(not report.exists() and report != root and root not in report.parents
            and report != output and output not in report.parents,
            'Report must be a new file outside source and working-view trees')
    r4, r5 = verify_source(root)
    output.parent.mkdir(parents=True, exist_ok=True)
    required = sum(x['bytes'] for x in r4.values())
    require(shutil.disk_usage(output.parent).free >= required + 32 * 1024 * 1024,
            'Insufficient free space for the verified R4 working copy')
    output.mkdir()
    # Copies, rather than hardlinks, keep subsequent user work independent.
    for name, entry in sorted(r4.items()):
        target = output / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(root / name, target)
        require(target.stat().st_size == entry['bytes'] and digest(target) == entry['sha256'],
                'Working-copy verification failed: ' + name)
    require({p.relative_to(output).as_posix() for p in output.rglob('*') if p.is_file()} == set(r4),
            'Working-copy inventory mismatch')
    result = {
        'status': 'PASS', 'timestamp_utc': datetime.now(timezone.utc).isoformat(),
        'source': str(root), 'working_view': str(output), 'python': sys.version,
        'preparer_sha256': digest(Path(__file__)), 'pinned_manifest_sha256': PINS,
        'source_members_verified': len(r4) + len(r5), 'r4_members_copied_and_verified': len(r4),
        'r5_members_verified_and_retained_in_original': len(r5), 'copied_bytes': required,
        'simulator_executed': False, 'full_run_authorisation_granted': False,
        'source_files_modified': False, 'original_launcher_and_full_run_gate_unchanged': True,
        'files': [{'path': name, **entry} for name, entry in sorted(r4.items())],
        'interpretation': 'An exact R4 execution-layer copy, not a new scientific protocol or dataset. R5 figures remain intact in the original S2. Historical launcher checks can now inspect their matching manifest domain.',
    }
    report.parent.mkdir(parents=True, exist_ok=True)
    report.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--s2-root', required=True, type=Path)
    parser.add_argument('--output-dir', required=True, type=Path)
    parser.add_argument('--report', required=True, type=Path)
    args = parser.parse_args()
    try:
        result = prepare(args.s2_root.resolve(), args.output_dir.resolve(), args.report.resolve())
    except (OSError, ValueError, KeyError, csv.Error) as error:
        print(json.dumps({'status': 'FAIL', 'error': str(error),
                          'simulation_executed': False,
                          'note': 'No existing output is overwritten. A partial new working copy may remain if copying was interrupted.'}))
        return 1
    print(json.dumps({k: result[k] for k in ['status', 'source_members_verified', 'r4_members_copied_and_verified', 'r5_members_verified_and_retained_in_original', 'simulator_executed']}))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
