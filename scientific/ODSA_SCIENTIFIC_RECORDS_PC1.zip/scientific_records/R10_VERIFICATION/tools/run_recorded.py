#!/usr/bin/env python3
"""Run one explicitly supplied audit command and preserve its actual execution."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import time

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--record-dir', required=True, type=Path)
p.add_argument('--cwd', required=True, type=Path)
p.add_argument('--pythonpath', default='')
p.add_argument('command', nargs=argparse.REMAINDER)
a = p.parse_args()
command = a.command[1:] if a.command[:1] == ['--'] else a.command
if not command:
    p.error('a command is required after --')
out = a.record_dir.resolve()
out.mkdir(parents=True, exist_ok=False)
env = os.environ.copy()
env['PYTHONDONTWRITEBYTECODE'] = '1'
env['PYTEST_DISABLE_PLUGIN_AUTOLOAD'] = '1'
if a.pythonpath:
    env['PYTHONPATH'] = a.pythonpath
started = datetime.now(timezone.utc).isoformat()
clock = time.perf_counter()
with (out / 'stdout.log').open('w', encoding='utf-8') as stdout, (out / 'stderr.log').open('w', encoding='utf-8') as stderr:
    r = subprocess.run(command, cwd=a.cwd, env=env, stdout=stdout, stderr=stderr)
record = {
    'argv': command, 'cwd': str(a.cwd.resolve()), 'started_utc': started,
    'ended_utc': datetime.now(timezone.utc).isoformat(),
    'elapsed_seconds': time.perf_counter() - clock, 'exit_code': r.returncode,
    'python_supervisor': sys.version, 'platform': platform.platform(),
    'environment_overrides': {k: env.get(k) for k in ['PYTHONPATH', 'PYTHONDONTWRITEBYTECODE', 'PYTEST_DISABLE_PLUGIN_AUTOLOAD']},
    'runner_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'logs': {},
}
for name in ['stdout.log', 'stderr.log']:
    f = out / name
    record['logs'][name] = {'bytes': f.stat().st_size, 'sha256': hashlib.sha256(f.read_bytes()).hexdigest()}
(out / 'EXECUTION.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'record_dir': str(out), 'exit_code': r.returncode, 'elapsed_seconds': record['elapsed_seconds']}))
raise SystemExit(r.returncode)
