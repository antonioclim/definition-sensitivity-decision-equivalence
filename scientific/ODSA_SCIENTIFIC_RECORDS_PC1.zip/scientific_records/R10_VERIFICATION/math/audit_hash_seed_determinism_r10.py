#!/usr/bin/env python3
"""Probe semantic-summary determinism across Python set-hash seeds only.

Three deterministic populations, 36 semantic rows each. No random generator,
Monte Carlo replicate, worker grid or full-output reconciliation is executed.
"""
from __future__ import annotations
import argparse
import hashlib
import itertools
import json
import os
from pathlib import Path
import subprocess
import sys
sys.dont_write_bytecode=True


def worker(s2):
    sys.path.insert(0,str((s2/'03_EXECUTABLE').resolve()))
    import yaml
    from odsa_econ.dgp import generate_state_probabilities
    from odsa_econ.diagnostics import semantic_loss
    protocol=yaml.safe_load((s2/'02_FROZEN_PROTOCOL/eint_r2_decision_protocol.yml').read_text())
    rows=[]
    for scenario in ['aligned_diffusion','middle_compensation','mixed_nonmonotone']:
        population=generate_state_probabilities(protocol,scenario=scenario,separation_level='high',added_state_heterogeneity_level='high',unit_count=16)
        for objective,definition,cost in itertools.product(protocol['objectives'],protocol['definitions'],protocol['cost_profiles']):
            profile=protocol['cost_profiles'][cost]
            r=semantic_loss(population,protocol['states'],protocol['definitions'][definition]['states'],protocol['objectives'][objective]['relevant_states'],profile['false_inclusion'],profile['false_exclusion'])
            rows.append({'scenario':scenario,'objective':objective,'definition':definition,'cost':cost,**r})
    print(json.dumps(rows,sort_keys=True,separators=(',',':')))


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--s2',type=Path,required=True);ap.add_argument('--out',type=Path);ap.add_argument('--worker',action='store_true')
    args=ap.parse_args()
    if args.worker:return worker(args.s2)
    args.out.mkdir(parents=True,exist_ok=True)
    records=[];baseline=None;differences=[]
    for seed in ['0','1','2','42','12345','999']:
        env=dict(os.environ,PYTHONHASHSEED=seed,PYTHONDONTWRITEBYTECODE='1')
        proc=subprocess.run([sys.executable,str(Path(__file__).resolve()),'--s2',str(args.s2.resolve()),'--worker'],env=env,capture_output=True,text=True,check=True)
        rows=json.loads(proc.stdout);digest=hashlib.sha256(proc.stdout.encode()).hexdigest()
        records.append({'PYTHONHASHSEED':seed,'rows':len(rows),'json_sha256':digest,'exit_code':proc.returncode})
        if baseline is None:baseline=rows
        else:
            for i,(a,b) in enumerate(zip(baseline,rows,strict=True)):
                for field in ['false_inclusion_mass','false_exclusion_mass','cost_weighted_semantic_loss']:
                    if a[field]!=b[field]:differences.append({'PYTHONHASHSEED':seed,'row':i,'scenario':a['scenario'],'definition':a['definition'],'objective':a['objective'],'cost':a['cost'],'field':field,'seed0_value':a[field],'value':b[field],'absolute_difference':abs(a[field]-b[field])})
    result={'status':'BYTE_IDENTITY_IN_CHECKED_HASH_SEEDS' if not differences else 'LAST_BIT_DIFFERENCES_FROM_HASH_ORDER',
            'scope':'Three deterministic populations; semantic diagnostics only; no stochastic simulation.',
            'processes':records,'differences':differences,'different_numeric_fields':len(differences),
            'maximum_absolute_difference':max((r['absolute_difference'] for r in differences),default=0.0),
            'zero_vs_positive_flags_changed':sum((r['seed0_value']>0)!=(r['value']>0) for r in differences),
            'limits':['The seed probe does not establish universal byte reproducibility.','Any observed discrepancy does not attribute the earlier pooled-output SHA-256 mismatch to this cause.','Python hash seed changes set iteration order; no random-number root seed or scientific setting is changed.']}
    (args.out/'R10_HASH_SEED_DETERMINISM.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ['differences']},indent=2))


if __name__=='__main__':main()
