#!/usr/bin/env python3
"""Locate already-generated R10 reference CSV deltas; never runs the engine."""
import argparse
import csv
import hashlib
import json
from pathlib import Path


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--r10',type=Path,required=True);args=ap.parse_args()
    base=args.r10;out=base/'math'
    historical=base/'fresh_s2/Supplementary_Material_S2_Code_and_Aggregate_Results/06_R2_REPRODUCTION/REFERENCE_AUDIT_20261111/REFERENCE_RERUN_CELL_METRIC_SUMMARY.csv'
    current=base/'computation/reference_rerun/REFERENCE_RERUN_CELL_METRIC_SUMMARY.csv'
    old=list(csv.DictReader(historical.open(encoding='utf-8-sig',newline='')))
    new=list(csv.DictReader(current.open(encoding='utf-8-sig',newline='')))
    probe=json.loads((out/'R10_HASH_SEED_DETERMINISM.json').read_text())
    keycols=['cell_id','stream_id','metric_scope','metric_family','metric_name','definition','objective','rule','parameter','cost_profile','n_defined','n_undefined']
    rows=[]
    for i,(x,y) in enumerate(zip(old,new,strict=True),1):
        differences={k:{'historical':x[k],'R10':y[k],'abs_difference':abs(float(x[k])-float(y[k]))} for k in x if x[k]!=y[k]}
        if not differences:continue
        assert all(x[k]==y[k] for k in keycols)
        field=x['metric_name']
        matching=[r for r in probe['differences'] if r['scenario']=='aligned_diffusion' and r['definition']==x['definition'] and r['objective']==x['objective'] and r['field']==field and (x['cost_profile']=='NA' or x['cost_profile']==r['cost'])]
        match=lambda r:{r['value'],r['seed0_value']}=={float(x['mean']),float(y['mean'])}
        rows.append({'csv_record_number_1based':i,'identity':{k:x[k] for k in keycols},'differences':differences,
                     'exact_value_pair_also_observed_in_hash_seed_probe':any(match(r) for r in matching),
                     'matching_probe_hash_seeds':sorted({r['PYTHONHASHSEED'] for r in matching if match(r)})})
    result={
        'status':'ALL_REFERENCE_DELTAS_LOCALISED_TO_DETERMINISTIC_SEMANTIC_SUMMARIES' if len(rows)==8 and all(r['exact_value_pair_also_observed_in_hash_seed_probe'] for r in rows) else 'REVIEW_REQUIRED',
        'rows_compared':len(old),'rows_changed':len(rows),'fields_changed':sum(len(r['differences']) for r in rows),
        'all_changed_rows_deterministic_semantic':all(r['identity']['metric_scope']=='deterministic_population' and r['identity']['metric_family']=='semantic' for r in rows),
        'all_changed_fields_mean_minimum_maximum':all(set(r['differences'])=={'mean','minimum','maximum'} for r in rows),
        'maximum_absolute_difference':max((v['abs_difference'] for r in rows for v in r['differences'].values()),default=0.),
        'all_changed_value_pairs_reproduced_by_hash_seed_probe':all(r['exact_value_pair_also_observed_in_hash_seed_probe'] for r in rows),
        'rows':rows,
        'sources':[{'path':str(p.resolve()),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in [historical,current,out/'R10_HASH_SEED_DETERMINISM.json',base/'computation/reference_rerun/REFERENCE_REPRODUCTION_CHECK.json']],
        'scope':'Comparison performed by mathematics reviewer; 4000-replication execution performed separately by root. The observed value pairs are reproduced by changing Python hash seed alone. The original processes hash seeds were not recorded here, so their actual historical seed values and the cause of the R4 full pooled-file mismatch are not identified.'}
    (out/'R10_REFERENCE_DELTA_CLASSIFICATION.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ['rows','sources']},indent=2))


if __name__=='__main__':main()
