#!/usr/bin/env python3
"""Independent bounded reconstruction of the 48-population ODSA register.

No stochastic replicate, engine grid runner or full-output validator is invoked.
The 70-digit scalar DGP is independent of the NumPy implementation. The frozen
DGP is called separately only to measure the effect of its floating convention.
All outputs are written outside the supplied archive.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import csv
from decimal import Decimal, localcontext
import hashlib
import itertools
import json
import math
from pathlib import Path
import platform
import sys

sys.dont_write_bytecode = True
import numpy as np
import yaml

D = Decimal
PI = D('3.141592653589793238462643383279502884197169399375105820974944592307816406')
POP_FIELDS = ('scenario', 'separation_level', 'added_state_heterogeneity_level', 'unit_count')
MARGINAL = ('generic_level_materiality_detected', 'rank_reversal_detected', 'semantic_mismatch_detected')
JOINT = ('action_disagreement_without_material_level_change',
         'material_level_change_without_action_disagreement',
         'decision_equivalence_despite_numerical_difference',
         'rank_stability_with_semantic_mismatch')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def decimal_sin_pi(z):
    """Taylor sin(pi*z), z in [-1,1]; exact known zeros handled explicitly."""
    if z in (D(-1), D(0), D(1)):
        return D(0)
    x = PI*z
    term = x
    total = x
    n = 1
    while abs(term) > D('1e-67'):
        term *= -(x*x)/D((2*n)*(2*n+1))
        total += term
        n += 1
        if n > 120:
            raise AssertionError('Taylor expansion did not converge')
    return total


def independent_population(protocol, key):
    scenario, separation_key, heterogeneity_key, n = key
    b = {s:D(str(v)) for s,v in protocol['base_state_probabilities'].items()}
    a = D(str(protocol['scenario_parameters']['separation_levels'][separation_key]))
    h = D(str(protocol['scenario_parameters']['added_state_heterogeneity_levels'][heterogeneity_key]))
    z = [D(-1)+D(2*i)/D(n-1) for i in range(n)]
    mean_z2 = sum(x*x for x in z)/D(n)
    fraction = b['platform']/(b['standard_software']+b['platform'])
    answer = []
    for x in z:
        da = du = dv = D(0)
        if scenario == 'aligned_diffusion':
            da,du,dv = a*x,D('.75')*h*x,D('1.25')*h*x
        elif scenario == 'broad_margin_only':
            dv = h*x
        elif scenario == 'middle_compensation':
            da,du,dv = a*x,-a*x,D('.50')*h*x
        elif scenario == 'strict_to_broad_reversal':
            da,du,dv = a*x,-D('.25')*a*x,-(a+D('.75')*h)*x
        elif scenario == 'mixed_nonmonotone':
            da = a*x
            du = -D('.80')*a*x+D('.50')*h*(x*x-mean_z2)
            dv = -D('.35')*a*x+h*decimal_sin_pi(x)
        elif scenario != 'null_common':
            raise AssertionError(scenario)
        integrated = b['integrated_system']+da
        specialised = b['specialised_software']+du
        added = b['standard_software']+b['platform']+dv
        platform_mass = added*fraction
        row = {'manual':D(1)-integrated-specialised-added,
               'standard_software':added-platform_mass,'platform':platform_mass,
               'specialised_software':specialised,'integrated_system':integrated}
        assert min(row.values()) >= 0 and max(row.values()) <= 1
        assert abs(sum(row.values())-1) < D('1e-65')
        answer.append(row)
    return answer


def rates(pop, groups, field):
    return {name:[sum(row[s] for s in spec[field]) for row in pop] for name,spec in groups.items()}


def sign(value, tolerance):
    return 0 if abs(value) <= tolerance else (1 if value > 0 else -1)


def reversal_pairs(left, right, tolerance):
    out=[]
    for i,j in itertools.combinations(range(len(left)),2):
        if sign(left[i]-left[j],tolerance)*sign(right[i]-right[j],tolerance)==-1:
            out.append((i,j))
    return out


def boundary(values, k, direction, tolerance):
    vals=sorted(values,reverse=direction=='highest')
    return abs(vals[k-1]-vals[k])<=tolerance if k<len(vals) else False


def compute_population_cases(protocol,key,pop,definition_rates,objective_rates,tol,is_decimal=False):
    counts={name:[0,0] for name in MARGINAL+JOINT}
    bits={}
    detail=[]
    contrast_rows=[]
    conv=lambda x:D(str(x)) if is_decimal else float(x)
    for contrast in protocol['nested_contrasts']:
        left_name,right_name=contrast['left'],contrast['right']
        name=left_name+'__to__'+right_name
        left,right=definition_rates[left_name],definition_rates[right_name]
        delta=abs(sum(y-x for x,y in zip(left,right))/len(left))
        reversed_pairs=reversal_pairs(left,right,tol)
        contrast_rows.append({'population':list(key),'contrast':name,'mean_delta':str(delta),
                              'reversed_pairs':len(reversed_pairs),'eligible_pairs':math.comb(len(left),2)})
        for q,spec in protocol['objectives'].items():
            mismatch_states=set(protocol['definitions'][right_name]['states'])^set(spec['relevant_states'])
            semantic=any(any(row[s]>0 for s in mismatch_states) for row in pop)
            for epsilon in protocol['decision_rules']['level_materiality_values']:
                material=delta>=conv(epsilon)
                margin_events=dict(zip(MARGINAL,(material,bool(reversed_pairs),semantic)))
                for metric,value in margin_events.items():
                    counts[metric][0]+=1;counts[metric][1]+=int(value)
                    bits[(name,q,str(epsilon),'NA',metric)]=bool(value)
                for threshold in protocol['decision_rules']['threshold_values']:
                    tau=conv(threshold)
                    lset={i for i,x in enumerate(left) if x>=tau}
                    rset={i for i,x in enumerate(right) if x>=tau}
                    changed=lset!=rset
                    joint_events=dict(zip(JOINT,(changed and not material,
                        material and not changed,delta>0 and not changed,
                        not reversed_pairs and semantic)))
                    for metric,value in joint_events.items():
                        counts[metric][0]+=1;counts[metric][1]+=int(value)
                        bits[(name,q,str(epsilon),str(threshold),metric)]=bool(value)
                    detail.append({'scenario':key[0],'separation':key[1],'heterogeneity':key[2],
                                   'units':key[3],'contrast':name,'objective':q,
                                   'epsilon':epsilon,'threshold':threshold,
                                   **{k:int(v) for k,v in margin_events.items()},
                                   **{k:int(v) for k,v in joint_events.items()}})
    ties=defaultdict(lambda:[0,0])
    tie_bits={}
    for k,direction in itertools.product(protocol['decision_rules']['top_k_values'],protocol['decision_rules']['top_k_directions']):
        for contrast in protocol['nested_contrasts']:
            left,right=contrast['left'],contrast['right']
            flag=boundary(definition_rates[left],k,direction,tol) or boundary(definition_rates[right],k,direction,tol)
            name='population_cross_definition_boundary_tie'
            ties[name][0]+=1;ties[name][1]+=int(flag)
            tie_bits[(name,left+'__to__'+right,'NA',k,direction)]=flag
        for objective,definition in itertools.product(objective_rates,definition_rates):
            flag=boundary(objective_rates[objective],k,direction,tol) or boundary(definition_rates[definition],k,direction,tol)
            name='population_objective_or_definition_boundary_tie'
            ties[name][0]+=1;ties[name][1]+=int(flag)
            tie_bits[(name,definition,objective,k,direction)]=flag
    return counts,bits,detail,contrast_rows,ties,tie_bits


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--s2',required=True,type=Path);ap.add_argument('--out',required=True,type=Path)
    args=ap.parse_args();args.out.mkdir(parents=True,exist_ok=True)
    source=args.s2/'03_EXECUTABLE';sys.path.insert(0,str(source.resolve()))
    from odsa_econ.dgp import generate_state_probabilities
    protocol_path=args.s2/'02_FROZEN_PROTOCOL/eint_r2_decision_protocol.yml'
    protocol=yaml.safe_load(protocol_path.read_text())
    registry_path=args.s2/'02_FROZEN_PROTOCOL/EINT_R2_FULL_GRID_REGISTRY.csv'
    registry=list(csv.DictReader(registry_path.open(encoding='utf-8-sig',newline='')))
    keys=sorted({tuple(int(r[f]) if f=='unit_count' else r[f] for f in POP_FIELDS) for r in registry})
    assert len(keys)==48
    sample_population_sets=defaultdict(set)
    for row in registry:
        if 'sample_size' in row['modules'].split(';'):
            sample_population_sets[int(row['base_sample_size'])].add(tuple(int(row[f]) if f=='unit_count' else row[f] for f in POP_FIELDS))
    same_sample_populations=all(v==next(iter(sample_population_sets.values())) for v in sample_population_sets.values())
    assert same_sample_populations and len(sample_population_sets)==5 and len(next(iter(sample_population_sets.values())))==6
    regimes=('independent_decimal_70','frozen_float_tolerance','raw_float_strict')
    totals={r:{name:[0,0] for name in MARGINAL+JOINT} for r in regimes}
    disagreements={r:Counter() for r in regimes[1:]}
    changed_populations={r:set() for r in regimes[1:]}
    tie_disagreements={r:Counter() for r in regimes[1:]}
    ties_by_scenario={r:defaultdict(lambda:[0,0]) for r in regimes}
    pair_sign_disagreements=Counter()
    pair_sign_examples=[]
    pair_sign_comparisons=0
    max_state_discrepancy=D(0);min_nonzero_gap=None
    frozen_records=[];contrast_details=[];examples=[]
    sample_size_ties=defaultdict(lambda:[0,0])
    reference_calibration=None
    with localcontext() as ctx:
        ctx.prec=70
        for key in keys:
            dec_pop=independent_population(protocol,key)
            dec_def=rates(dec_pop,protocol['definitions'],'states')
            dec_obj=rates(dec_pop,protocol['objectives'],'relevant_states')
            matrix=generate_state_probabilities(protocol,scenario=key[0],separation_level=key[1],added_state_heterogeneity_level=key[2],unit_count=key[3])
            states=protocol['states'];indices={s:i for i,s in enumerate(states)}
            float_pop=[{s:float(matrix[i,j]) for j,s in enumerate(states)} for i in range(len(matrix))]
            # Match the frozen summation input to isolate its tolerance convention.
            float_def={name:[float(row[[indices[s] for s in spec['states']]].sum()) for row in matrix] for name,spec in protocol['definitions'].items()}
            float_obj={name:[float(row[[indices[s] for s in spec['relevant_states']]].sum()) for row in matrix] for name,spec in protocol['objectives'].items()}
            for a,b in zip(dec_pop,float_pop):
                for s in states:max_state_discrepancy=max(max_state_discrepancy,abs(a[s]-D.from_float(b[s])))
            outputs={
                regimes[0]:compute_population_cases(protocol,key,dec_pop,dec_def,dec_obj,D('1e-55'),True),
                regimes[1]:compute_population_cases(protocol,key,float_pop,float_def,float_obj,1e-15),
                regimes[2]:compute_population_cases(protocol,key,float_pop,float_def,float_obj,0.0),
            }
            for regime,(counts,bits,detail,contrasts,ties,tie_bits) in outputs.items():
                for metric,(n,e) in counts.items():totals[regime][metric][0]+=n;totals[regime][metric][1]+=e
                for metric,(n,e) in ties.items():
                    ties_by_scenario[regime][(key[0],metric)][0]+=n;ties_by_scenario[regime][(key[0],metric)][1]+=e
                if regime!=regimes[0]:
                    for bit,value in bits.items():
                        if value!=outputs[regimes[0]][1][bit]:
                            disagreements[regime][bit[-1]]+=1;changed_populations[regime].add(key)
                            if len(examples)<12:examples.append({'regime':regime,'population':key,'case':bit,'oracle':outputs[regimes[0]][1][bit],'computed':value})
                    for bit,value in tie_bits.items():
                        if value!=outputs[regimes[0]][5][bit]:tie_disagreements[regime][bit[0]]+=1
            frozen_records.extend(outputs[regimes[1]][2]);contrast_details.extend(outputs[regimes[1]][3])
            if key[1:] == ('high','high',16):
                for metric,(n,e) in outputs[regimes[1]][4].items():
                    sample_size_ties[metric][0]+=n;sample_size_ties[metric][1]+=e
            if key == ('aligned_diffusion','high','high',16):
                qset=set(protocol['objectives']['dedicated_or_integrated_objective']['relevant_states'])
                reference_calibration={'mean_rates':{name:str(sum(v)/len(v)) for name,v in dec_def.items()},'q3':{}}
                for name,spec in protocol['definitions'].items():
                    dset=set(spec['states'])
                    fp=sum(sum(row[s] for s in dset-qset) for row in dec_pop)/len(dec_pop)
                    fn=sum(sum(row[s] for s in qset-dset) for row in dec_pop)/len(dec_pop)
                    reference_calibration['q3'][name]={'false_inclusion_mass':str(fp),'false_exclusion_mass':str(fn),'denominator':'equally weighted mixture of total state mass across 16 synthetic units'}
            for definition in dec_def:
                for i,j in itertools.combinations(range(key[3]),2):
                    pair_sign_comparisons+=1
                    gap=dec_def[definition][i]-dec_def[definition][j]
                    if abs(gap)>D('1e-55'):
                        min_nonzero_gap=abs(gap) if min_nonzero_gap is None else min(min_nonzero_gap,abs(gap))
                    for label,tol in [('frozen_tolerance',1e-15),('raw_float',0.0)]:
                        actual_gap=float_def[definition][i]-float_def[definition][j]
                        changed=sign(actual_gap,tol)!=sign(gap,D('1e-55'))
                        pair_sign_disagreements[label]+=int(changed)
                        if changed:
                            pair_sign_examples.append({'regime':label,'population':list(key),'definition':definition,
                                                       'unit_pair_1based':[i+1,j+1],'float_gap':actual_gap,
                                                       'decimal_gap':str(gap),'float_sign':sign(actual_gap,tol),
                                                       'decimal_sign':sign(gap,D('1e-55'))})

    expected_path=args.s2/'04_AGGREGATE_RESULTS/Deterministic_Ablation_Events.csv'
    expected=list(csv.DictReader(expected_path.open(encoding='utf-8-sig',newline='')))
    matches=[]
    for row in expected:
        name=row['metric_name'];n,e=totals[regimes[1]][name]
        matches.append({'metric':name,'cases':n,'events':e,'fraction':e/n,
                        'expected_cases':int(row['prespecified_cases']),'expected_events':int(row['event_count']),
                        'pass':(n,e)==(int(row['prespecified_cases']),int(row['event_count']))})
    expected_ties_path=args.s2/'04_AGGREGATE_RESULTS/Top_K_Tie_Diagnostics.csv'
    tie_matches=[]
    for row in csv.DictReader(expected_ties_path.open(encoding='utf-8-sig',newline='')):
        n,e=ties_by_scenario[regimes[1]][(row['scenario'],row['tie_metric'])]
        tie_matches.append({'scenario':row['scenario'],'metric':row['tie_metric'],'cases':n,'events':e,
                            'pass':n==int(row['prespecified_rows']) and abs(e/n-float(row['tie_event_fraction']))<1e-15})
    out_csv=args.out/'R10_DETERMINISTIC_CASE_REGISTER.csv'
    with out_csv.open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(frozen_records[0]));writer.writeheader();writer.writerows(frozen_records)
    result={
        'status':'PASS_FROZEN_REGISTER_RECONSTRUCTION' if all(x['pass'] for x in matches+tie_matches) and not disagreements[regimes[1]] else 'REVIEW_REQUIRED',
        'runtime':{'python':platform.python_version(),'numpy':np.__version__,'yaml':yaml.__version__},
        'scope':'48 deterministic populations only; no Monte Carlo replicates; no call to engine run_cell/run_protocol or supplied tests.',
        'method':'Independent 70-digit scalar DGP (Taylor sine; exact known endpoint zeros), independently enumerated events, and separate comparison to frozen NumPy DGP/tolerance. An abs 1e-55 guard separates numerical residues in the Decimal oracle, not a claim of symbolic proof.',
        'distinct_populations':len(keys),'source_grid_cells':len(registry),
        'denominators':{'population_factors':[6,2,2,2],'base_case_factors':[48,3,4,3],'base_cases':1728,'threshold_case_factors':[1728,5],'threshold_cases':8640},
        'registered_counts_comparison':matches,'registered_tie_comparison':tie_matches,
        'event_totals_by_regime':{r:{name:{'cases':n,'events':e,'fraction':e/n} for name,(n,e) in v.items()} for r,v in totals.items()},
        'event_disagreements_against_independent_decimal':{r:dict(c) for r,c in disagreements.items()},
        'populations_with_event_disagreement':{r:[list(x) for x in sorted(v)] for r,v in changed_populations.items()},
        'tie_flags_disagreeing_with_independent_decimal':{r:dict(c) for r,c in tie_disagreements.items()},
        'pairwise_sign_disagreements_against_independent_decimal':dict(pair_sign_disagreements),
        'pairwise_sign_comparisons':pair_sign_comparisons,
        'pairwise_sign_disagreement_examples':pair_sign_examples,
        'maximum_state_probability_difference_float_vs_decimal':str(max_state_discrepancy),
        'minimum_nonzero_decimal_definition_pair_gap':str(min_nonzero_gap),
        'contrast_detail':contrast_details,'disagreement_examples':examples,
        'inputs':[{'path':str(p.resolve()),'sha256':sha(p)} for p in [protocol_path,registry_path,expected_path,expected_ties_path,source/'odsa_econ/dgp.py',source/'odsa_econ/diagnostics.py']],
        'case_register':{'path':str(out_csv.resolve()),'rows':len(frozen_records),'sha256':sha(out_csv)},
        'sample_size_population_tie_reconstruction':{
            'same_population_inputs_for_each_of_five_sample_sizes':same_sample_populations,
            'sample_sizes':sorted(sample_population_sets),
            'churn_cases':sample_size_ties['population_cross_definition_boundary_tie'][0],
            'churn_tied':sample_size_ties['population_cross_definition_boundary_tie'][1],
            'churn_tie_free':sample_size_ties['population_cross_definition_boundary_tie'][0]-sample_size_ties['population_cross_definition_boundary_tie'][1],
            'action_top_k_cases':sample_size_ties['population_objective_or_definition_boundary_tie'][0],
            'action_top_k_tied':sample_size_ties['population_objective_or_definition_boundary_tie'][1],
            'action_threshold_cases':6*4*3*5*2,
            'action_total_cases':sample_size_ties['population_objective_or_definition_boundary_tie'][0]+6*4*3*5*2,
        },
        'independent_reference_calibration':reference_calibration,
        'limitations':['Finite design reconstruction is not external validation.','The no-tolerance calculation is a sensitivity probe, not a replacement result or amended frozen protocol.','The input protocol retains its historical status strings; no new scientific execution permission is inferred from them.']}
    dest=args.out/'R10_DETERMINISTIC_RECONSTRUCTION.json';dest.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k in ['status','distinct_populations','registered_counts_comparison','event_disagreements_against_independent_decimal','tie_flags_disagreeing_with_independent_decimal','pairwise_sign_disagreements_against_independent_decimal','minimum_nonzero_decimal_definition_pair_gap']},indent=2))


if __name__=='__main__':main()
