#!/usr/bin/env python3
"""Adversarial finite checks of R9 P4/P10, ties and loss conventions.

The selection oracle enumerates every k-subset, rather than reusing the
interval count formula. Rational inputs avoid numerical tie ambiguity.
No simulation is performed and no frozen source is modified.
"""
from __future__ import annotations
import argparse
from collections import Counter
from fractions import Fraction as F
import hashlib
import itertools
import json
import math
from pathlib import Path
import platform
import random
import sys
sys.dont_write_bytecode=True
import numpy as np


def admissible_selections(vector,k,direction):
    """All subsets whose selected values weakly dominate excluded values."""
    units=tuple(vector)
    for chosen in itertools.combinations(units,k):
        chosen=frozenset(chosen);excluded=set(units)-chosen
        if direction=='highest':
            valid=all(vector[i]>=vector[j] for i in chosen for j in excluded)
        else:
            valid=all(vector[i]<=vector[j] for i in chosen for j in excluded)
        if valid:yield chosen


def memberships_from_points(points,k,direction):
    guaranteed=set(points[0]);possible=set();selections=0
    for point in points:
        for chosen in admissible_selections(point,k,direction):
            guaranteed.intersection_update(chosen);possible.update(chosen);selections+=1
    return {'guaranteed':guaranteed,'possible':possible,'ambiguous':possible-guaranteed},selections


def serial(value):
    if isinstance(value,(set,frozenset)):return sorted(value)
    if isinstance(value,F):return str(value)
    if isinstance(value,np.generic):return value.item()
    raise TypeError(type(value).__name__)


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--s2',type=Path,required=True);ap.add_argument('--out',type=Path,required=True)
    args=ap.parse_args();args.out.mkdir(parents=True,exist_ok=True)
    sys.path.insert(0,str((args.s2/'03_EXECUTABLE').resolve()))
    from odsa_econ import diagnostics as impl
    results=[]
    def add(name,condition,evidence,scope='executed bounded check'):
        results.append({'check':name,'pass':bool(condition),'scope':scope,'evidence':evidence})

    # P4: equality D=Delta* can preserve or change a lexicographic selection.
    for label,p,added,expected_changed in [
        ('equality_preserves_under_labels',{'a':F(3,4),'b':F(1,2)},{'a':F(0),'b':F(1,4)},False),
        ('equality_changes_under_labels',{'a':F(1,2),'b':F(3,4)},{'a':F(1,4),'b':F(0)},True),
    ]:
        q={u:p[u]+added[u] for u in p}
        first,_=impl.top_k_action(p,1,'highest');last,flag=impl.top_k_action(q,1,'highest')
        inside=min(first);outside=next(u for u in p if u not in first)
        delta=p[inside]-p[outside];worst=added[outside]-added[inside]
        add('P4_'+label,delta==worst and (first!=last)==expected_changed and flag,
            {'initial':p,'added':added,'final':q,'Delta_star':delta,'D':worst,
             'initial_set':first,'frozen_final_set':last,'all_ties_final_sets':list(admissible_selections(q,1,'highest'))})
    p={'a':F(3,4),'b':F(1,2),'c':F(3,8),'d':F(1,8)}
    added={'a':F(0),'b':F(1,4),'c':F(0),'d':F(1,4)}
    q={u:p[u]+added[u] for u in p};initial={'a','b'}
    delta=min(p[g] for g in initial)-max(p[g] for g in p if g not in initial)
    worst=max(added[h]-added[g] for g in initial for h in p if h not in initial)
    all_final=list(admissible_selections(q,2,'highest'))
    add('P4_certificate_not_necessary',worst>delta and all_final==[frozenset(initial)],
        {'initial':p,'added':added,'final':q,'Delta_star':delta,'D':worst,'all_final_sets':all_final})

    # Enumeration beyond the historical 3-unit examples: finite 4-unit domains.
    grid=tuple(F(i,4) for i in range(5))
    intervals=list(itertools.combinations_with_replacement(grid,2))
    configs={tuple([(F(1,2),F(1,2))]*4),tuple([(F(0),F(1))]*4),
             ((F(0),F(1,4)),(F(1,4),F(1,2)),(F(1,2),F(3,4)),(F(3,4),F(1))),
             ((F(3,4),F(1)),(F(1,2),F(3,4)),(F(1,2),F(1,2)),(F(0),F(1,4)))}
    rng=random.Random(20261111)
    while len(configs)<68:configs.add(tuple(rng.choice(intervals) for _ in range(4)))
    comparisons=point_visits=set_visits=0;failed=[]
    for configuration in sorted(configs):
        bounds=dict(zip('abcd',configuration))
        points=[dict(zip('abcd',point)) for point in itertools.product(*[tuple(x for x in grid if lo<=x<=hi) for lo,hi in configuration])]
        for k,direction in itertools.product(range(1,5),('highest','lowest')):
            oracle,n_sets=memberships_from_points(points,k,direction)
            actual=impl.interval_top_k_membership(bounds,k,direction)
            comparisons+=1;point_visits+=len(points);set_visits+=n_sets
            if actual!=oracle:failed.append({'bounds':bounds,'k':k,'direction':direction,'oracle':oracle,'actual':actual})
    add('P10_independent_four_unit_subset_oracle',not failed,{
        'interval_configurations':len(configs),'endpoints':[str(x) for x in grid],
        'directions':2,'k_values':[1,2,3,4],'comparisons':comparisons,
        'point_visits_across_k_and_directions':point_visits,'admissible_selected_set_visits':set_visits,
        'failures':failed,'qualification':'Finite corroboration, not a replacement for the analytic theorem. All valid tie selections were enumerated at every admitted finite point.'})

    # Joint restrictions expose why the rectangular statements are conditional.
    coupled=[{'g':F(3,5),'h':F(1,2)},{'g':F(2,5),'h':F(3,10)}]
    envelope={'g':(F(2,5),F(3,5)),'h':(F(3,10),F(1,2))}
    actual,_=memberships_from_points(coupled,1,'highest');outer=impl.interval_top_k_membership(envelope,1,'highest')
    add('P8_P10_joint_feasibility_gate',actual['guaranteed']=={'g'} and outer['guaranteed']==set() and outer['possible']=={'g','h'},
        {'actual_feasible_vectors':coupled,'rectangular_envelope':envelope,'actual_membership':actual,'envelope_membership':outer})
    # The three points are generated by assigning one common unresolved mass.
    nested_points=[{'narrow':F(3,5),'broad':F(7,10)},
                   {'narrow':F(2,5),'broad':F(7,10)},
                   {'narrow':F(2,5),'broad':F(1,2)}]
    add('P8_nested_definition_common_assignments',all(p['broad']>p['narrow'] for p in nested_points),
        {'known_mass':{'narrow_state':F(2,5),'added_state':F(1,10),'manual':F(3,10)},'unresolved_mass':F(1,5),
         'common_assignments':nested_points,'marginal_intervals':{'narrow':[F(2,5),F(3,5)],'broad':[F(1,2),F(7,10)]},
         'marginal_separation_holds':False,'strict_order_under_every_common_assignment':True})

    tau=F(1,2)
    bounds={'at':(tau,tau),'cross':(F(1,4),tau),'under':(F(0),F(1,4)),'over':(F(3,4),F(1))}
    above=impl.threshold_interval_classification(bounds,tau,'above_or_equal')
    below=impl.threshold_interval_classification(bounds,tau,'below')
    add('P2_P9_inclusive_boundary_and_complement',above=={'definite':{'at','over'},'definite_not':{'under'},'ambiguous':{'cross'}} and above['definite']==below['definite_not'] and above['ambiguous']==below['ambiguous'],
        {'bounds':bounds,'tau':tau,'above':above,'below':below})

    # Numerical conventions must be kept separate from exact theorems.
    x=0.5;y=math.nextafter(x,1.0);z=math.nextafter(y,1.0)
    left={'a':y,'b':x};right={'a':y,'b':z}
    frozen=impl.pairwise_reversal_share(left,right)
    strict=impl.pairwise_reversal_share(left,right,tolerance=0.0)
    selected,tie_flag=impl.top_k_action({'a':x,'b':y},1,'highest')
    add('numerical_near_tie_is_flagged_but_not_lexicographically_grouped',selected=={'b'} and tie_flag and frozen['strict_reversal_share']==0 and strict['strict_reversal_share']==1,
        {'ulp':y-x,'values':{'a':x,'b':y},'selected':selected,'boundary_flag':tie_flag,
         'nested_reversal_left':left,'nested_reversal_right':right,'frozen_reversal':frozen,'raw_float_reversal':strict,
         'interpretation':'Flag tolerance 1e-15 does not replace raw-value sorting or exact interval inequalities; it is not a theorem counterexample.'})
    membership=impl.interval_top_k_membership({'a':(x,x),'b':(y,y)},1,'highest')
    add('P10_exact_endpoint_comparison_not_near_tie_grouping',membership['guaranteed']=={'b'} and membership['possible']=={'b'},membership)
    threshold_probe={'below':math.nextafter(x,0.0),'equal':x,'above':y}
    add('threshold_point_comparison_has_no_1e15_tolerance',impl.threshold_action(threshold_probe,x,'above_or_equal')=={'equal','above'},threshold_probe)

    # Definitions differing only in zero-mass states have zero semantic loss.
    pop=np.array([[1.,0.,0.],[.25,.75,0.]])
    zero=impl.semantic_loss(pop,['x','y','z'],['x','z'],['x'],1.,2.)
    free=impl.semantic_loss(pop,['x','y','z'],['x','y'],['x'],0.,2.)
    add('P5_zero_support_and_positive_cost_conditions',zero['cost_weighted_semantic_loss']==0 and free['false_inclusion_mass']>0 and free['cost_weighted_semantic_loss']==0,
        {'zero_support':zero,'zero_false_inclusion_cost':free,'probability_rows':pop.tolist()})
    target={'a','b'};empty=set()
    loss=impl.action_loss(empty,target,1.,2.,denominator=2)
    free_action=impl.action_loss({'a'},set(),0.,1.,denominator=2)
    add('P6_zero_cost_exception_and_loss_scale',loss['cost_weighted_loss']==2 and free_action['cost_weighted_loss']==0,
        {'normalised_cost_loss_can_exceed_one':loss,'unequal_actions_zero_cost_loss':free_action})
    objective={'a'};structural={'b'};observed={'a'}
    first=impl.action_loss(structural,objective,1.,1.,denominator=2)['cost_weighted_loss']
    second=impl.action_loss(observed,structural,1.,1.,denominator=2)['cost_weighted_loss']
    observed_loss=impl.action_loss(observed,objective,1.,1.,denominator=2)['cost_weighted_loss']
    add('nonadditivity_cancellation',first==second==1 and observed_loss==0,{
        'G':2,'structural_normalised_loss':first,'observed_vs_structural_normalised_loss':second,'observed_objective_normalised_loss':observed_loss,
        'count_scale':[2,2,0]})
    empty_j=impl.action_loss(set(),set(),1.,1.,denominator=2)['jaccard_overlap']
    churn=impl.set_churn({'a','b'},{'b','c'},k=2)
    add('Jaccard_empty_and_fixed_k_churn',empty_j==1 and churn['churn']==.5 and churn['jaccard_overlap']==1/3,
        {'empty_union_J':empty_j,'fixed_k':2,'metrics':churn})

    # Mapping iteration order must not change a lexicographic fixed rule.
    tied={'d':.5,'c':.25,'b':.5,'a':.5}
    permutations=list(itertools.permutations(tied.items()));signatures=set()
    for items in permutations:
        signatures.add(tuple(sorted(impl.top_k_action(dict(items),2,'highest')[0])))
    add('point_rule_mapping_iteration_invariance',signatures=={('a','b')},{'mapping_orders':len(permutations),'selected_sets':[list(x) for x in sorted(signatures)]})

    result={'status':'PASS_BOUNDED_ADVERSARIAL_FORMAL_CHECKS' if all(r['pass'] for r in results) else 'FAIL',
            'runtime':{'python':platform.python_version(),'numpy':np.__version__},
            'checks':results,'checks_passed':sum(r['pass'] for r in results),'checks_total':len(results),
            'source':{'diagnostics':str((args.s2/'03_EXECUTABLE/odsa_econ/diagnostics.py').resolve()),'sha256':hashlib.sha256((args.s2/'03_EXECUTABLE/odsa_econ/diagnostics.py').read_bytes()).hexdigest()},
            'limits':['No Monte Carlo or empirical replay.','Finite exact-rational corroboration does not prove a universal theorem.','The actual joint feasible-set examples deliberately violate rectangularity and therefore illustrate its necessity for the stated equivalences, rather than refute P10.','No source, protocol or result file was changed.']}
    (args.out/'R10_FORMAL_ADVERSARIAL_CHECKS.json').write_text(json.dumps(result,ensure_ascii=False,indent=2,default=serial)+'\n')
    print(json.dumps({'status':result['status'],'passed':result['checks_passed'],'total':len(results),
                      'P10_oracle':next(r['evidence'] for r in results if r['check']=='P10_independent_four_unit_subset_oracle')},indent=2,default=serial))


if __name__=='__main__':main()
